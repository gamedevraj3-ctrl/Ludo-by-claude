import 'dart:math';

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../game/models.dart';
import 'avatar.dart';
import 'dice_widget.dart';

/// The colored player panel occupying a 6x6 base corner of the board,
/// showing avatar, name, live score, hearts (lives) and dice badge —
/// matching the reference art.
///
/// In PASS & PLAY the dice badge doubles as that seat's own roll button, so
/// every friend rolls from beside their own start box (Ludo King style)
/// instead of sharing one button at the bottom of the screen.
class PlayerCard extends StatelessWidget {
  const PlayerCard({
    super.key,
    required this.player,
    required this.isTurn,
    required this.dice,
    required this.turnProgress,
    required this.compact,
    this.showScore = true,
    this.tokensHomeLabel,
    this.showDice = true,
    this.canRoll = false,
    this.rolling = false,
    this.glowPhase = 0,
    this.onRoll,
  });

  final Player player;
  final bool isTurn;
  final int? dice;
  final double turnProgress; // 1.0 -> full time left, 0.0 -> out of time
  final bool compact;

  /// Rush mode shows the running score; classic mode shows tokens home.
  final bool showScore;
  final String? tokensHomeLabel;

  /// Bots mode keeps the single shared roll button at the bottom, so the
  /// corner panels show no dice at all — only the turn-timer ring.
  final bool showDice;

  /// Pass & play: this seat may roll right now, so the dice badge is live.
  final bool canRoll;
  final bool rolling;

  /// 0..1 pulse driven by the parent so the live dice breathes.
  final double glowPhase;
  final VoidCallback? onRoll;

  @override
  Widget build(BuildContext context) {
    final dim = player.eliminated;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(compact ? 10 : 14),
        gradient: player.color.cardGradient,
        border: Border.all(
          color: isTurn ? Colors.white : Colors.white24,
          width: isTurn ? 2.2 : 1.0,
        ),
        boxShadow: isTurn
            ? [
                BoxShadow(
                  color: AppColors.glow.withValues(alpha: 0.55),
                  blurRadius: 16,
                  spreadRadius: 1,
                ),
              ]
            : null,
      ),
      child: Opacity(
        opacity: dim ? 0.45 : 1,
        child: LayoutBuilder(
          builder: (context, cts) {
            final w = cts.maxWidth;
            final h = cts.maxHeight;
            return Stack(
              // Deliberately NOT clipped: Update #2 item 1 ("characters pngs
              // ko ludo ke board par thoda bada dikho") makes the character
              // render a little bigger by letting the artwork's box extend
              // slightly above the panel's own top edge — like a collectible
              // figure standing a bit taller than its base — while its feet
              // stay pinned to the panel floor. Nothing is ever clipped, so
              // the enlarged art is never chopped off.
              clipBehavior: Clip.none,
              children: [
                // Character portrait, blended straight into the seat's coloured
                // block. The artwork carries its own feathered alpha, so it is
                // drawn WITHOUT a frame or dark plate behind it — no black box.
                Positioned(
                  left: 0,
                  right: 0,
                  // Pulling the top edge up (and bumping widthFactor below)
                  // gives CharacterBlend's BoxFit.contain more room, so the
                  // whole figure renders visibly larger while staying
                  // anchored to the panel's own floor line.
                  top: -h * 0.075,
                  bottom: 0,
                  child: IgnorePointer(
                    child: CharacterBlend(
                      character: player.character,
                      fallbackSeed: player.avatarSeed,
                      widthFactor: 1.14,
                    ),
                  ),
                ),

                // dice badge + score, stacked vertically on the right
                Positioned(
                  right: w * 0.05,
                  top: w * 0.045,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _diceBadge(w),
                      SizedBox(height: w * 0.015),
                      Text(
                        showScore ? 'Score' : 'Home',
                        style: TextStyle(
                          fontSize: w * 0.078,
                          fontWeight: FontWeight.w700,
                          color: Colors.white.withValues(alpha: 0.92),
                          height: 1.0,
                        ),
                      ),
                      Text(
                        showScore
                            ? '${player.score}'
                            : (tokensHomeLabel ?? '${player.tokensHome}/4'),
                        style: TextStyle(
                          fontSize: w * (showScore ? 0.21 : 0.17),
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          height: 1.08,
                          shadows: const [
                            Shadow(
                              color: Colors.black38,
                              blurRadius: 4,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // name + hearts strip at bottom
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: w * 0.05,
                      vertical: w * 0.035,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.34),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(compact ? 10 : 13),
                        bottomRight: Radius.circular(compact ? 10 : 13),
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                // Bots show their character name (which is also
                                // their name); the human shows their real
                                // profile name.
                                player.displayName,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: w * 0.105,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                  height: 1.05,
                                ),
                              ),
                              // …and, for the human only, the character they
                              // are actually playing as.
                              if (player.subName != null)
                                Text(
                                  player.subName!,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: w * 0.078,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.gold,
                                    height: 1.1,
                                  ),
                                ),
                            ],
                          ),
                        ),
                        ...List.generate(
                          3,
                          (i) => Padding(
                            padding: EdgeInsets.only(left: w * 0.012),
                            child: Icon(
                              Icons.favorite,
                              size: w * 0.10,
                              color: i < player.livesLeft
                                  ? Colors.white
                                  : Colors.white.withValues(alpha: 0.28),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                if (player.eliminated)
                  Positioned.fill(
                    child: Center(
                      child: Transform.rotate(
                        angle: -0.22,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: w * 0.07,
                            vertical: w * 0.025,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.72),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.white38),
                          ),
                          child: Text(
                            'OUT',
                            style: TextStyle(
                              fontSize: w * 0.15,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// Turn-timer ring + dice face. In pass & play this is also the seat's own
  /// roll button, so it pulses and becomes tappable on that friend's turn.
  Widget _diceBadge(double w) {
    final live = canRoll && !rolling;
    final pulse = live ? glowPhase : 0.0;
    final box = w * 0.30;

    // Bots mode: no dice in the corners at all. Keep the turn-timer ring so
    // you can still see whose clock is ticking.
    if (!showDice) {
      return SizedBox(
        width: box,
        height: box,
        child: isTurn
            ? CircularProgressIndicator(
                value: turnProgress.clamp(0.0, 1.0),
                strokeWidth: w * 0.035,
                backgroundColor: Colors.black26,
                valueColor: AlwaysStoppedAnimation(
                  turnProgress < 0.3 ? AppColors.pRed : AppColors.online,
                ),
              )
            : null,
      );
    }

    // While it is my turn the live dice is shown; afterwards the badge keeps
    // displaying the number I actually rolled (never a fake default 6).
    final face = dice ?? player.lastDice;

    final badge = SizedBox(
      width: box,
      height: box,
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (isTurn)
            SizedBox(
              width: box,
              height: box,
              child: CircularProgressIndicator(
                value: turnProgress.clamp(0.0, 1.0),
                strokeWidth: w * 0.035,
                backgroundColor: Colors.black26,
                valueColor: AlwaysStoppedAnimation(
                  turnProgress < 0.3 ? AppColors.pRed : AppColors.online,
                ),
              ),
            ),
          Container(
            width: w * 0.235,
            height: w * 0.235,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withValues(alpha: isTurn ? 0.18 : 0.28),
              border: live
                  ? Border.all(
                      color: Colors.white.withValues(
                        alpha: 0.55 + 0.45 * pulse,
                      ),
                      width: w * 0.014,
                    )
                  : null,
              boxShadow: live
                  ? [
                      BoxShadow(
                        color: Colors.white.withValues(
                          alpha: 0.30 + 0.3 * pulse,
                        ),
                        blurRadius: w * 0.09 + w * 0.06 * pulse,
                        spreadRadius: w * 0.004,
                      ),
                    ]
                  : null,
            ),
            child: Center(
              child: AnimatedScale(
                scale: rolling ? 1.14 : (live ? 1.0 + 0.06 * pulse : 1.0),
                duration: const Duration(milliseconds: 220),
                child: Transform.rotate(
                  angle: rolling ? glowPhase * 2 * pi : 0,
                  child: face == null
                      // Nothing rolled yet this match — show a neutral blank
                      // face rather than pretending a 6 was thrown.
                      ? Container(
                          width: w * 0.17,
                          height: w * 0.17,
                          decoration: BoxDecoration(
                            color: const Color(
                              0xFFD9D4EC,
                            ).withValues(alpha: 0.55),
                            borderRadius: BorderRadius.circular(w * 0.035),
                          ),
                        )
                      : DiceFace(
                          value: face,
                          size: w * 0.17,
                          faceColor: isTurn
                              ? Colors.white
                              : const Color(0xFFD9D4EC),
                        ),
                ),
              ),
            ),
          ),
        ],
      ),
    );

    if (!live || onRoll == null) return badge;
    return GestureDetector(
      onTap: onRoll,
      behavior: HitTestBehavior.opaque,
      child: badge,
    );
  }
}

/// Plain colored panel used for seats that have no player (2-player match).
class EmptySeatPanel extends StatelessWidget {
  const EmptySeatPanel({super.key, required this.color, required this.compact});
  final PColor color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(compact ? 10 : 14),
        gradient: color.cardGradient,
        border: Border.all(color: Colors.white24),
      ),
    );
  }
}
