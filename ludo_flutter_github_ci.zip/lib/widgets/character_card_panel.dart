import 'package:flutter/material.dart';

import 'avatar.dart';

/// ---------------------------------------------------------------------------
/// Update #2 (item 6) — the "player / character card".
///
/// The user's own clarification, verbatim (Hinglish): a character's PNG shown
/// inside a SQUARE, BORDERED panel with bold ("bolding") corners, on a
/// coloured background — "white, blue, purple, black etc" — exactly like the
/// seat panels already look on the live ludo board (`PlayerCard`), just usable
/// standalone anywhere in the app. This single widget is now shared by:
///   • the Lobby (showcasing the currently-selected character, centre stage)
///   • the rebuilt Booyah/MVP victory screen (one card per podium finisher,
///     tinted with that seat's own board colour)
///   • the rebuilt Characters grid (one card per roster entry)
/// ---------------------------------------------------------------------------
class CharacterCardPanel extends StatelessWidget {
  const CharacterCardPanel({
    super.key,
    required this.character,
    required this.color,
    this.name,
    this.width = 120,
    this.aspectRatio = 0.80,
    this.borderWidth,
    this.cornerRadius = 18,
    this.fallbackSeed = 0,
    this.dark = false,
    this.glow,
    this.nameBelow = false,
    this.characterWidthFactor = 1.08,
    this.characterAlignment = Alignment.bottomCenter,
  });

  final String character;

  /// Border / background tint. On the victory screen this is the seat's own
  /// board colour (yellow/blue/red/green); in the lobby and characters grid
  /// it is drawn from a rotating "rarity" showcase palette instead, exactly
  /// matching the user's own "white, blue, purple, black etc" example.
  final Color color;
  final String? name;
  final double width;
  final double aspectRatio; // width / height
  final double? borderWidth;
  final double cornerRadius;
  final int fallbackSeed;

  /// Deeper shadow + thicker rim for the winner/MVP card.
  final bool dark;
  final Color? glow;

  /// Name plate below the frame instead of overlaid on it (characters grid).
  final bool nameBelow;
  final double characterWidthFactor;
  final Alignment characterAlignment;

  @override
  Widget build(BuildContext context) {
    final height = width / aspectRatio;
    final bw = borderWidth ?? width * 0.052;
    final r = cornerRadius;

    final frame = Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(r),
        // Bold coloured corners/rim — the "square bordered with corner
        // bolding" the user described — drawn as a saturated outer frame.
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color.lerp(color, Colors.white, 0.22)!,
            color,
            Color.lerp(color, Colors.black, 0.45)!,
          ],
        ),
        boxShadow: [
          if (glow != null)
            BoxShadow(
              color: glow!.withValues(alpha: 0.75),
              blurRadius: width * 0.30,
              spreadRadius: width * 0.02,
            ),
          BoxShadow(
            color: Colors.black.withValues(alpha: dark ? 0.55 : 0.38),
            blurRadius: width * 0.16,
            offset: Offset(0, width * 0.05),
          ),
        ],
      ),
      padding: EdgeInsets.all(bw),
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(r - bw * 0.6),
          color: const Color(0xFF14192A),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(r - bw * 0.6),
          child: Stack(
            children: [
              // Coloured wash behind the cutout so the panel never looks
              // like a plain dark box even before the PNG loads.
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        color.withValues(alpha: 0.55),
                        color.withValues(alpha: 0.18),
                        Colors.black.withValues(alpha: 0.30),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: CharacterBlend(
                    character: character,
                    fallbackSeed: fallbackSeed,
                    widthFactor: characterWidthFactor,
                    alignment: characterAlignment,
                  ),
                ),
              ),
              // top sheen for a glossy collectible-card read
              Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.white.withValues(alpha: 0.16),
                          Colors.white.withValues(alpha: 0.0),
                        ],
                        stops: const [0.0, 0.35],
                      ),
                    ),
                  ),
                ),
              ),
              if (name != null && !nameBelow)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: height * 0.040),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.46),
                      border: Border(
                        top: BorderSide(
                          color: color.withValues(alpha: 0.8),
                          width: 1.2,
                        ),
                      ),
                    ),
                    child: Text(
                      name!,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: width * 0.125,
                        shadows: const [
                          Shadow(color: Colors.black87, blurRadius: 4),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );

    if (name == null || !nameBelow) return frame;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        frame,
        SizedBox(height: height * 0.045),
        Text(
          name!,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: width * 0.135,
          ),
        ),
      ],
    );
  }
}

/// A small rotating "showcase" palette used wherever a character card needs a
/// colour but has no real board seat yet (lobby preview, characters grid) —
/// exactly the "white, blue, purple, black etc" variety the user asked for.
class ShowcasePalette {
  ShowcasePalette._();

  static const List<Color> colors = [
    Color(0xFFE7EAF0), // white/silver
    Color(0xFF2F8CE0), // blue
    Color(0xFF8B5CF6), // purple
    Color(0xFF20242E), // black/charcoal
    Color(0xFFE0B34A), // gold
    Color(0xFF3EBE52), // green
    Color(0xFFEF5B57), // red
    Color(0xFF34C6C6), // teal
  ];

  static Color forSeed(int seed) => colors[seed % colors.length];

  static Color forName(String name) => forSeed(name.codeUnits.fold(0, (a, b) => a + b));
}
