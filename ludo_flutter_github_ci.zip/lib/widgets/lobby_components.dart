import 'dart:math';

import 'package:flutter/material.dart';

import '../core/game_theme.dart';
import '../game/characters.dart' as roster;
import '../game/models.dart';
import 'avatar.dart';
import 'game_ui.dart';

/// ---------------------------------------------------------------------------
/// GameHud — the top bar: player profile, level, gold, diamonds, settings,
/// sound. Built as a metallic blue panel with gold edging, on top of the
/// supplied HUD artwork.
/// ---------------------------------------------------------------------------
class GameHud extends StatelessWidget {
  const GameHud({
    super.key,
    required this.name,
    required this.character,
    required this.soundOn,
    required this.scale,
    required this.onProfileTap,
    required this.onSettings,
    required this.onSound,
  });

  final String name;
  final String character;
  final bool soundOn;
  final double scale;

  final VoidCallback onProfileTap;
  final VoidCallback onSettings;
  final VoidCallback onSound;

  @override
  Widget build(BuildContext context) {
    final h = 52.0 * scale;
    final btn = 32.0 * scale;

    return Padding(
      padding: EdgeInsets.fromLTRB(8 * scale, 6 * scale, 8 * scale, 2 * scale),
      child: SizedBox(
        height: h,
        child: Stack(
          children: [
            // The supplied HUD plate artwork, stretched behind the widgets.
            Positioned.fill(
              child: ClipRRect(
                borderRadius: GameRadius.all(GameRadius.lg * scale),
                child: Image.asset(
                  GameArt.hudProfile,
                  fit: BoxFit.fill,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            ),
            MetalPanel(
              radius: GameRadius.lg * scale,
              rimWidth: 2.0 * scale,
              // Let the artwork behind show through the panel body.
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  GameColors.steelLight.withValues(alpha: 0.72),
                  GameColors.steel.withValues(alpha: 0.62),
                  GameColors.steelDeep.withValues(alpha: 0.78),
                ],
              ),
              padding: EdgeInsets.symmetric(horizontal: 6 * scale),
              child: Row(
                children: [
                  Expanded(
                    child: PlayerProfile(
                      name: name,
                      character: character,
                      scale: scale,
                      onTap: onProfileTap,
                    ),
                  ),
                  SizedBox(width: 6 * scale),
                  MetalIconButton(
                    asset: GameArt.iconSettings,
                    icon: Icons.settings,
                    size: btn,
                    onTap: onSettings,
                  ),
                  SizedBox(width: 5 * scale),
                  MetalIconButton(
                    asset: soundOn ? GameArt.iconVolume : null,
                    icon: soundOn ? Icons.volume_up : Icons.volume_off,
                    size: btn,
                    onTap: onSound,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Profile chip: circular gold-framed portrait, quoted name and the chosen
/// character underneath it.
class PlayerProfile extends StatelessWidget {
  const PlayerProfile({
    super.key,
    required this.name,
    required this.character,
    required this.scale,
    required this.onTap,
  });

  final String name;
  final String character;
  final double scale;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final av = 40.0 * scale;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleFrame(
            size: av,
            child: Image.asset(
              roster.Characters.assetFor(character),
              fit: BoxFit.cover,
              alignment: const Alignment(0, -0.35),
              filterQuality: FilterQuality.medium,
              errorBuilder: (_, __, ___) => GameAvatar(seed: 0, size: av),
            ),
          ),
          SizedBox(width: 7 * scale),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Flexible(
                      child: Text(
                        "'$name'",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GameTypography.name(13.5 * scale),
                      ),
                    ),
                    SizedBox(width: 3 * scale),
                    Icon(Icons.edit, size: 10 * scale, color: Colors.white60),
                  ],
                ),
                SizedBox(height: 2 * scale),
                Text(
                  character,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GameTypography.label(
                    10.5 * scale,
                    color: GameColors.goldLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// ModeSelection — the two large illustrated mode cards.
/// ---------------------------------------------------------------------------
class ModeSelection extends StatelessWidget {
  const ModeSelection({
    super.key,
    required this.selected,
    required this.scale,
    required this.onSelect,
    required this.onPlay,
  });

  final MatchMode selected;
  final double scale;
  final void Function(MatchMode) onSelect;
  final void Function(MatchMode) onPlay;

  @override
  Widget build(BuildContext context) {
    // CrossAxisAlignment.stretch makes each card fill exactly the height
    // handed down by the parent (which is itself bounded, never scrolling),
    // and ModeCard adapts every internal size to that height via its own
    // LayoutBuilder — so this always fits, in landscape or portrait, on a
    // small phone or a tablet, with zero overflow.
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: ModeCard(
            mode: MatchMode.classic,
            titleTop: 'CLASSIC',
            titleBottom: 'LUDO',
            subtitle: 'Play Classic with Friends!',
            selected: selected == MatchMode.classic,
            scale: scale,
            onSelect: () => onSelect(MatchMode.classic),
            onPlay: () => onPlay(MatchMode.classic),
          ),
        ),
        SizedBox(width: 10 * scale),
        Expanded(
          child: ModeCard(
            mode: MatchMode.rush,
            titleTop: 'RUSH',
            titleBottom: 'MODE',
            subtitle: 'Fast-Paced Action!\nQuick Games',
            selected: selected == MatchMode.rush,
            scale: scale,
            onSelect: () => onSelect(MatchMode.rush),
            onPlay: () => onPlay(MatchMode.rush),
          ),
        ),
      ],
    );
  }
}

/// One large illustrated mode card with a dimensional frame, board artwork,
/// big title, subtitle and its own glossy green PLAY button.
class ModeCard extends StatelessWidget {
  const ModeCard({
    super.key,
    required this.mode,
    required this.titleTop,
    required this.titleBottom,
    required this.subtitle,
    required this.selected,
    required this.scale,
    required this.onSelect,
    required this.onPlay,
  });

  final MatchMode mode;
  final String titleTop;
  final String titleBottom;
  final String subtitle;
  final bool selected;
  final double scale;
  final VoidCallback onSelect;
  final VoidCallback onPlay;

  bool get _rush => mode.isRush;

  @override
  Widget build(BuildContext context) {
    final ink = _rush ? GameColors.rushInk : GameColors.classicInk;
    final radius = GameRadius.md * scale;

    return GestureDetector(
      onTap: onSelect,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          gradient: GameGradients.goldRim,
          borderRadius: GameRadius.all(radius),
          boxShadow: selected
              ? GameShadows.glow(
                  _rush ? GameColors.rushTop : GameColors.gold,
                  strength: 0.8,
                )
              : GameShadows.panel,
        ),
        padding: EdgeInsets.all((selected ? 2.8 : 1.8) * scale),
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: _rush
                ? GameGradients.rushCard
                : GameGradients.classicCard,
            borderRadius: GameRadius.all(radius * 0.88),
            border: GameBorders.innerLight(1.0),
          ),
          child: ClipRRect(
            borderRadius: GameRadius.all(radius * 0.88),
            child: Stack(
              children: [
                // Rush gets speed streaks behind the artwork.
                if (_rush)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(painter: _SpeedStreaks()),
                    ),
                  ),
                // top-light sheen for the glossy read
                Positioned.fill(
                  child: IgnorePointer(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: GameGradients.sheen(0.26),
                      ),
                    ),
                  ),
                ),
                // LayoutBuilder derives a *local* scale from the height this
                // card actually receives, on top of the caller's [scale] —
                // that way the card always fits inside whatever height the
                // (never-scrolling) lobby layout hands it, on any device.
                Positioned.fill(
                  child: LayoutBuilder(
                    builder: (context, box) {
                      final ls =
                          (box.maxHeight / 170.0).clamp(0.55, 1.35) * scale;
                      return Padding(
                        padding: EdgeInsets.fromLTRB(
                          8 * ls,
                          8 * ls,
                          8 * ls,
                          6 * ls,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // 3D ludo board + pawns artwork
                            SizedBox(
                              height: 40 * ls,
                              child: Image.asset(
                                _rush
                                    ? GameArt.boardRush
                                    : GameArt.boardClassic,
                                fit: BoxFit.contain,
                                filterQuality: FilterQuality.medium,
                                errorBuilder: (_, __, ___) => CustomPaint(
                                  painter: MiniBoardPainter(rush: _rush),
                                ),
                              ),
                            ),
                            SizedBox(height: 4 * ls),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Text(
                                titleTop,
                                maxLines: 1,
                                style: GameTypography.title(18 * ls, ink),
                              ),
                            ),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Text(
                                titleBottom,
                                maxLines: 1,
                                style: GameTypography.title(20 * ls, ink),
                              ),
                            ),
                            SizedBox(height: 2 * ls),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Text(
                                subtitle,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 9 * ls,
                                  height: 1.2,
                                  fontWeight: FontWeight.w800,
                                  color: _rush
                                      ? Colors.white
                                      : GameColors.classicInk.withValues(
                                          alpha: 0.85,
                                        ),
                                ),
                              ),
                            ),
                            SizedBox(height: 6 * ls),
                            GlossyButton(
                              label: 'PLAY',
                              height: 28 * ls,
                              fontSize: 12 * ls,
                              useArtwork: true,
                              onTap: onPlay,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                // selected tick
                if (selected)
                  Positioned(
                    right: 5 * scale,
                    top: 5 * scale,
                    child: Icon(
                      Icons.check_circle,
                      size: 18 * scale,
                      color: GameColors.green,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Motion streaks behind the Rush board artwork.
class _SpeedStreaks extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..strokeCap = StrokeCap.round;
    for (var i = 0; i < 7; i++) {
      final t = i / 6.0;
      p
        ..color = Colors.white.withValues(alpha: 0.16 - t * 0.02)
        ..strokeWidth = size.height * (0.030 - t * 0.002);
      final y = size.height * (0.10 + t * 0.80);
      canvas.drawLine(
        Offset(-size.width * 0.05, y),
        Offset(size.width * (0.30 + t * 0.40), y - size.height * 0.06),
        p,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _SpeedStreaks oldDelegate) => false;
}

/// Fallback mini ludo board (used only if the board artwork fails to load).
class MiniBoardPainter extends CustomPainter {
  MiniBoardPainter({required this.rush});
  final bool rush;

  @override
  void paint(Canvas canvas, Size size) {
    final side = min(size.height, size.width) * 0.94;
    final board = Rect.fromCenter(
      center: size.center(Offset.zero),
      width: side,
      height: side,
    );
    final u = side / 3;

    canvas.save();
    canvas.translate(board.center.dx, board.center.dy);
    canvas.rotate(rush ? 0.10 : -0.10);
    canvas.translate(-board.center.dx, -board.center.dy);

    final rr = RRect.fromRectAndRadius(board, Radius.circular(side * 0.10));
    canvas.drawRRect(rr, Paint()..color = Colors.black.withValues(alpha: 0.28));
    canvas.drawRRect(rr.deflate(side * 0.03), Paint()..color = Colors.white);

    const quad = [
      Color(0xFFF5B301),
      Color(0xFF2FA6F0),
      Color(0xFF3EBE52),
      Color(0xFFEF5B57),
    ];
    for (var i = 0; i < 4; i++) {
      final dx = (i % 2) * u * 1.12;
      final dy = (i ~/ 2) * u * 1.12;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(
            board.left + side * 0.06 + dx,
            board.top + side * 0.06 + dy,
            u * 0.82,
            u * 0.82,
          ),
          Radius.circular(u * 0.14),
        ),
        Paint()..color = quad[i],
      );
    }
    canvas.drawCircle(
      board.center,
      side * 0.10,
      Paint()..color = const Color(0xFF6A55C8),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant MiniBoardPainter old) => old.rush != rush;
}

/// ---------------------------------------------------------------------------
/// GameModeToggle — pick "Play with Bots" or "Play and Pass" (pass the
/// device around a table) before opening the match setup sheet.
/// ---------------------------------------------------------------------------
class GameModeToggle extends StatelessWidget {
  const GameModeToggle({
    super.key,
    required this.selected,
    required this.scale,
    required this.onSelect,
  });

  final GameMode selected;
  final double scale;
  final void Function(GameMode) onSelect;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _pill(
            icon: Icons.smart_toy_rounded,
            label: 'Classic (Bots)',
            active: selected == GameMode.bots,
            onTap: () => onSelect(GameMode.bots),
          ),
        ),
        SizedBox(width: 8 * scale),
        Expanded(
          child: _pill(
            icon: Icons.swap_horiz_rounded,
            label: 'Play and Pass',
            active: selected == GameMode.passAndPlay,
            onTap: () => onSelect(GameMode.passAndPlay),
          ),
        ),
      ],
    );
  }

  Widget _pill({
    required IconData icon,
    required String label,
    required bool active,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: EdgeInsets.symmetric(vertical: 9 * scale),
        decoration: BoxDecoration(
          gradient: active ? GameGradients.goldRim : null,
          color: active ? null : Colors.black.withValues(alpha: 0.28),
          borderRadius: GameRadius.all(GameRadius.md * scale),
          border: Border.all(
            color: active
                ? GameColors.gold.withValues(alpha: 0.9)
                : Colors.white24,
            width: active ? 1.6 : 1,
          ),
          boxShadow: active ? GameShadows.button : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 15 * scale,
              color: active ? GameColors.ink : Colors.white70,
            ),
            SizedBox(width: 6 * scale),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11.5 * scale,
                  fontWeight: FontWeight.w800,
                  color: active ? GameColors.ink : Colors.white70,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// CharacterSection — "Characters" heading plus a 4-columns-wide grid of
/// collectible cards that scrolls vertically for the remaining rows.
/// ---------------------------------------------------------------------------
class CharacterSection extends StatelessWidget {
  const CharacterSection({
    super.key,
    required this.selected,
    required this.scale,
    required this.onPick,
  });

  final String selected;
  final double scale;
  final void Function(String) onPick;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SectionHeading(text: 'Characters', fontSize: 15 * scale),
        SizedBox(height: 8 * scale),
        // Recessed well behind the grid, like the reference.
        Expanded(
          child: MetalPanel(
            radius: GameRadius.md * scale,
            rimWidth: 1.6 * scale,
            gradient: GameGradients.well,
            showSheen: false,
            padding: EdgeInsets.all(6 * scale),
            child: GridView.builder(
              physics: const BouncingScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 6 * scale,
                mainAxisSpacing: 6 * scale,
                childAspectRatio: 0.62,
              ),
              itemCount: roster.Characters.count,
              itemBuilder: (_, i) {
                final c = roster.Characters.all[i];
                return CharacterCard(
                  character: c,
                  index: i + 1,
                  selected: c.name == selected,
                  scale: scale,
                  onTap: () => onPick(c.name),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

/// A premium collectible character card: metallic outer frame, coloured rarity
/// border, artwork, number badge, name and a glossy SELECT button.
class CharacterCard extends StatelessWidget {
  const CharacterCard({
    super.key,
    required this.character,
    required this.index,
    required this.selected,
    required this.scale,
    required this.onTap,
  });

  final roster.GameCharacter character;
  final int index;
  final bool selected;
  final double scale;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    // Each card gets a rarity tint so the grid looks as varied as the
    // reference art; the selected state is what actually stands out.
    final rarity = GameColors.rarity[index % GameColors.rarity.length];
    final radius = GameRadius.md * scale;

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          // metallic outer frame
          gradient: GameGradients.goldRim,
          borderRadius: GameRadius.all(radius),
          boxShadow: selected
              ? GameShadows.glow(rarity, strength: 0.85)
              : GameShadows.raised,
        ),
        padding: EdgeInsets.all(1.8 * scale),
        child: DecoratedBox(
          // coloured rarity border just inside the metal
          decoration: BoxDecoration(
            color: rarity.withValues(alpha: selected ? 1.0 : 0.78),
            borderRadius: GameRadius.all(radius * 0.9),
          ),
          child: Padding(
            padding: EdgeInsets.all((selected ? 2.2 : 1.5) * scale),
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: GameGradients.cardWell,
                borderRadius: GameRadius.all(radius * 0.8),
              ),
              child: ClipRRect(
                borderRadius: GameRadius.all(radius * 0.8),
                child: Column(
                  children: [
                    Expanded(
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: Image.asset(
                              character.asset,
                              fit: BoxFit.cover,
                              alignment: Alignment.topCenter,
                              filterQuality: FilterQuality.medium,
                              errorBuilder: (_, __, ___) =>
                                  GameAvatar(seed: index, size: 60 * scale),
                            ),
                          ),
                          // inner highlight along the top edge
                          Positioned.fill(
                            child: IgnorePointer(
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  gradient: GameGradients.sheen(0.16),
                                ),
                              ),
                            ),
                          ),
                          // number badge
                          Positioned(
                            left: 4 * scale,
                            top: 4 * scale,
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                horizontal: 5 * scale,
                                vertical: 1 * scale,
                              ),
                              decoration: BoxDecoration(
                                gradient: GameGradients.well,
                                borderRadius: GameRadius.all(
                                  GameRadius.xs * scale,
                                ),
                                border: Border.all(
                                  color: GameColors.gold.withValues(
                                    alpha: 0.75,
                                  ),
                                  width: 0.9,
                                ),
                              ),
                              child: Text(
                                '$index',
                                style: GameTypography.counter(9.5 * scale),
                              ),
                            ),
                          ),
                          if (selected)
                            Positioned(
                              right: 4 * scale,
                              top: 4 * scale,
                              child: Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  boxShadow: GameShadows.glow(
                                    GameColors.green,
                                    strength: 0.5,
                                  ),
                                ),
                                child: Icon(
                                  Icons.check_circle,
                                  size: 18 * scale,
                                  color: GameColors.greenLight,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    // name plate
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(vertical: 3 * scale),
                      decoration: BoxDecoration(
                        gradient: GameGradients.well,
                        border: Border(
                          top: BorderSide(
                            color: GameColors.gold.withValues(alpha: 0.45),
                            width: 1,
                          ),
                        ),
                      ),
                      child: Text(
                        character.name,
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GameTypography.name(12 * scale),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(
                        5 * scale,
                        4 * scale,
                        5 * scale,
                        5 * scale,
                      ),
                      child: GlossyButton(
                        label: selected ? 'SELECTED' : 'SELECT',
                        height: 22 * scale,
                        fontSize: 9 * scale,
                        gradient: selected
                            ? GameGradients.play
                            : GameGradients.idleButton,
                        onTap: onTap,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// GameBottomNavigation — Home / Settings / Profile in the game HUD style.
/// ---------------------------------------------------------------------------
class GameBottomNavigation extends StatelessWidget {
  const GameBottomNavigation({
    super.key,
    required this.scale,
    required this.onHome,
    required this.onSettings,
    required this.onProfile,
  });

  final double scale;
  final VoidCallback onHome;
  final VoidCallback onSettings;
  final VoidCallback onProfile;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(8 * scale, 2 * scale, 8 * scale, 6 * scale),
      child: MetalPanel(
        radius: GameRadius.lg * scale,
        rimWidth: 2.0 * scale,
        padding: EdgeInsets.symmetric(vertical: 5 * scale),
        child: Row(
          children: [
            Expanded(
              child: _NavItem(
                icon: Icons.home,
                label: 'Home',
                active: true,
                scale: scale,
                onTap: onHome,
              ),
            ),
            _Divider(scale: scale),
            Expanded(
              child: _NavItem(
                icon: Icons.settings,
                label: 'Settings',
                scale: scale,
                onTap: onSettings,
              ),
            ),
            _Divider(scale: scale),
            Expanded(
              child: _NavItem(
                icon: Icons.person,
                label: 'Profile',
                scale: scale,
                onTap: onProfile,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  const _Divider({required this.scale});
  final double scale;

  @override
  Widget build(BuildContext context) => Container(
    width: 1.2,
    height: 26 * scale,
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          GameColors.gold.withValues(alpha: 0.0),
          GameColors.gold.withValues(alpha: 0.55),
          GameColors.gold.withValues(alpha: 0.0),
        ],
      ),
    ),
  );
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.scale,
    required this.onTap,
    this.active = false,
  });

  final IconData icon;
  final String label;
  final double scale;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final tint = active ? GameColors.coin : Colors.white70;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Icon(icon, size: 23 * scale, color: tint),
              if (active)
                Positioned(
                  top: -9 * scale,
                  left: -7 * scale,
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 4 * scale,
                      vertical: 1 * scale,
                    ),
                    decoration: BoxDecoration(
                      gradient: GameGradients.play,
                      borderRadius: GameRadius.all(GameRadius.xs * scale),
                      border: Border.all(color: Colors.white54, width: 0.8),
                      boxShadow: GameShadows.button,
                    ),
                    child: Text(
                      'Active',
                      style: GameTypography.button(7 * scale),
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 2 * scale),
          Text(label, style: GameTypography.name(10 * scale, color: tint)),
        ],
      ),
    );
  }
}
