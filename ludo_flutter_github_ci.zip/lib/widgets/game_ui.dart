import 'package:flutter/material.dart';

import '../core/game_theme.dart';

/// Shared building blocks for the premium arcade lobby.
///
/// Every one of these is a real Flutter widget composed from gradients,
/// borders and shadows (plus the user's own artwork where supplied) — no
/// screenshots, no flat Material cards.

/// A metallic blue panel with a gold rim and a bevelled inner edge.
///
/// This is the workhorse behind the HUD, the bottom nav and the rules panel.
class MetalPanel extends StatelessWidget {
  const MetalPanel({
    super.key,
    required this.child,
    this.radius = GameRadius.md,
    this.rimWidth = 2.0,
    this.gradient,
    this.padding,
    this.showSheen = true,
    this.shadows,
  });

  final Widget child;
  final double radius;

  /// Thickness of the gold/bronze metal rim.
  final double rimWidth;

  /// Inner fill. Defaults to the metallic blue HUD gradient.
  final Gradient? gradient;

  final EdgeInsetsGeometry? padding;
  final bool showSheen;
  final List<BoxShadow>? shadows;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      // outer gold rim, drawn as a gradient-filled container
      decoration: BoxDecoration(
        gradient: GameGradients.goldRim,
        borderRadius: GameRadius.all(radius),
        boxShadow: shadows ?? GameShadows.panel,
      ),
      child: Padding(
        padding: EdgeInsets.all(rimWidth),
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: gradient ?? GameGradients.hud,
            borderRadius: GameRadius.all(radius - rimWidth * 0.5),
            border: GameBorders.innerLight(1.0),
          ),
          child: ClipRRect(
            borderRadius: GameRadius.all(radius - rimWidth * 0.5),
            child: Stack(
              children: [
                if (showSheen)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: GameGradients.sheen(0.20),
                        ),
                      ),
                    ),
                  ),
                Padding(padding: padding ?? EdgeInsets.zero, child: child),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// The glossy green action button from the reference art.
///
/// Uses the supplied [GameArt.playButton] artwork when [useArtwork] is set and
/// falls back to a hand-built glossy gradient otherwise, so it always renders.
class GlossyButton extends StatefulWidget {
  const GlossyButton({
    super.key,
    required this.label,
    required this.onTap,
    this.height = 34,
    this.fontSize = 13,
    this.gradient,
    this.useArtwork = false,
    this.enabled = true,
  });

  final String label;
  final VoidCallback onTap;
  final double height;
  final double fontSize;

  /// Override the fill (e.g. the grey idle gradient for unselected cards).
  final Gradient? gradient;

  final bool useArtwork;
  final bool enabled;

  @override
  State<GlossyButton> createState() => _GlossyButtonState();
}

class _GlossyButtonState extends State<GlossyButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final r = widget.height * 0.30;
    return GestureDetector(
      onTap: widget.enabled ? widget.onTap : null,
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) => setState(() => _down = false),
      onTapCancel: () => setState(() => _down = false),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        height: widget.height,
        transform: Matrix4.translationValues(0, _down ? 1.6 : 0, 0),
        decoration: BoxDecoration(
          borderRadius: GameRadius.all(r),
          // the darker "lip" under the button face
          color: const Color(0xFF14301A),
          boxShadow: _down ? null : GameShadows.button,
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(1.4, 1.0, 1.4, 2.6),
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: widget.gradient ?? GameGradients.play,
              borderRadius: GameRadius.all(r * 0.9),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.55),
                width: 1.1,
              ),
            ),
            child: ClipRRect(
              borderRadius: GameRadius.all(r * 0.9),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  if (widget.useArtwork)
                    Positioned.fill(
                      child: Image.asset(
                        GameArt.playButton,
                        fit: BoxFit.fill,
                        // Artwork is decorative; the gradient underneath is the
                        // guaranteed fallback if it ever fails to load.
                        errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                      ),
                    ),
                  // top-light gloss
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    height: widget.height * 0.42,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: GameGradients.sheen(0.42),
                        ),
                      ),
                    ),
                  ),
                  Text(
                    widget.label,
                    style: GameTypography.button(widget.fontSize),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Gold-rimmed circular avatar frame used by the HUD profile.
class CircleFrame extends StatelessWidget {
  const CircleFrame({
    super.key,
    required this.child,
    required this.size,
    this.rimWidth,
    this.glow,
  });

  final Widget child;
  final double size;
  final double? rimWidth;
  final Color? glow;

  @override
  Widget build(BuildContext context) {
    final rim = rimWidth ?? size * 0.075;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: GameGradients.goldRim,
        boxShadow: glow != null
            ? GameShadows.glow(glow!, strength: 0.7)
            : GameShadows.raised,
      ),
      padding: EdgeInsets.all(rim),
      child: DecoratedBox(
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: GameColors.steelDeep,
        ),
        child: ClipOval(child: child),
      ),
    );
  }
}

/// Premium currency capsule (gold coins / diamonds) for the HUD.
class CurrencyCounter extends StatelessWidget {
  const CurrencyCounter({
    super.key,
    required this.icon,
    required this.iconColor,
    required this.value,
    this.height = 30,
    this.showPlus = false,
    this.onTap,
  });

  final IconData icon;
  final Color iconColor;
  final String value;
  final double height;

  /// The little red "+" badge the reference shows on the diamond capsule.
  final bool showPlus;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            height: height,
            padding: EdgeInsets.symmetric(horizontal: height * 0.10),
            decoration: BoxDecoration(
              gradient: GameGradients.goldRim,
              borderRadius: GameRadius.all(height * 0.5),
              boxShadow: GameShadows.raised,
            ),
            child: Padding(
              padding: EdgeInsets.all(height * 0.055),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: height * 0.22),
                decoration: BoxDecoration(
                  gradient: GameGradients.well,
                  borderRadius: GameRadius.all(height * 0.45),
                  border: GameBorders.innerLight(0.9),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, size: height * 0.52, color: iconColor),
                    SizedBox(width: height * 0.12),
                    Text(value, style: GameTypography.counter(height * 0.40)),
                  ],
                ),
              ),
            ),
          ),
          if (showPlus)
            Positioned(
              right: -2,
              top: -2,
              child: Container(
                width: height * 0.40,
                height: height * 0.40,
                decoration: BoxDecoration(
                  color: const Color(0xFFE03A36),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white70, width: 1),
                  boxShadow: GameShadows.button,
                ),
                child: Icon(
                  Icons.add,
                  size: height * 0.28,
                  color: Colors.white,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Square metallic-blue icon button (settings, sound, carousel arrows).
class MetalIconButton extends StatelessWidget {
  const MetalIconButton({
    super.key,
    required this.onTap,
    this.icon,
    this.asset,
    this.size = 34,
    this.circular = false,
  });

  final VoidCallback onTap;

  /// Either a Material [icon] or a bundled [asset] from the design pack.
  final IconData? icon;
  final String? asset;

  final double size;
  final bool circular;

  @override
  Widget build(BuildContext context) {
    final r = circular ? size * 0.5 : size * 0.26;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: GameGradients.goldRim,
          borderRadius: GameRadius.all(r),
          boxShadow: GameShadows.raised,
        ),
        padding: EdgeInsets.all(size * 0.055),
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: GameGradients.hud,
            borderRadius: GameRadius.all(r * 0.88),
            border: GameBorders.innerLight(0.9),
          ),
          child: ClipRRect(
            borderRadius: GameRadius.all(r * 0.88),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned.fill(
                  child: IgnorePointer(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: GameGradients.sheen(0.26),
                      ),
                    ),
                  ),
                ),
                if (asset != null)
                  Padding(
                    padding: EdgeInsets.all(size * 0.14),
                    child: Image.asset(
                      asset!,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => Icon(
                        icon ?? Icons.settings,
                        size: size * 0.54,
                        color: Colors.white,
                      ),
                    ),
                  )
                else
                  Icon(icon, size: size * 0.54, color: Colors.white),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Centred section heading with gold rules either side ("Select Mode").
class SectionHeading extends StatelessWidget {
  const SectionHeading({super.key, required this.text, this.fontSize = 15});

  final String text;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(child: _GoldRule()),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: GameSpacing.md),
          child: Text(text, style: GameTypography.heading(fontSize)),
        ),
        const Expanded(child: _GoldRule(flip: true)),
      ],
    );
  }
}

class _GoldRule extends StatelessWidget {
  const _GoldRule({this.flip = false});
  final bool flip;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 2,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: flip ? Alignment.centerLeft : Alignment.centerRight,
          end: flip ? Alignment.centerRight : Alignment.centerLeft,
          colors: [GameColors.gold, GameColors.gold.withValues(alpha: 0.0)],
        ),
      ),
    );
  }
}

/// Faint diagonal weave + vignette so the backdrop is never a flat gradient.
class TexturePainter extends CustomPainter {
  const TexturePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final r = Offset.zero & size;

    final stripe = Paint()
      ..color = Colors.white.withValues(alpha: 0.016)
      ..strokeWidth = 10;
    for (double x = -size.height; x < size.width + size.height; x += 44) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x + size.height, size.height),
        stripe,
      );
    }

    canvas.drawRect(
      r,
      Paint()
        ..shader = RadialGradient(
          colors: [Colors.transparent, Colors.black.withValues(alpha: 0.45)],
          stops: const [0.50, 1.0],
        ).createShader(r),
    );
  }

  @override
  bool shouldRepaint(covariant TexturePainter oldDelegate) => false;
}
