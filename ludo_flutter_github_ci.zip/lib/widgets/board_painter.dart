import 'dart:math';
import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../game/board_map.dart';

/// Draws the static ludo board: 4 bases, white ring cells, colored paths,
/// star safe cells, home triangles and the center house.
class BoardPainter extends CustomPainter {
  const BoardPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final s = min(size.width, size.height);
    final u = s / 15.0;

    final cellFill = Paint()..color = Colors.white;
    final line = Paint()
      ..color = AppColors.boardLine.withValues(alpha: 0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = max(0.7, u * 0.055);

    // ---------- corner bases (6x6 rounded panels) ----------
    for (final e in BoardMap.baseOrigin.entries) {
      final color = e.key;
      final o = e.value;
      final rect = Rect.fromLTWH(o.c * u, o.r * u, u * 6, u * 6);
      final rr = RRect.fromRectAndRadius(rect, Radius.circular(u * 0.55));
      canvas.drawRRect(
        rr,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [color.main, color.dark],
          ).createShader(rect),
      );
      // glossy top highlight
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(
            rect.left + u * .35,
            rect.top + u * .35,
            rect.width - u * .7,
            rect.height * .42,
          ),
          Radius.circular(u * 0.4),
        ),
        Paint()..color = Colors.white.withValues(alpha: 0.10),
      );
      canvas.drawRRect(
        rr,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = u * 0.09
          ..color = Colors.white.withValues(alpha: 0.35),
      );
    }

    // ---------- ring cells (rounded, subtly recessed like the reference) ----
    final cellRadius = Radius.circular(u * 0.20);
    for (var i = 0; i < BoardMap.ring.length; i++) {
      final cell = BoardMap.ring[i];
      final r = BoardMap.rectOf(cell, s).deflate(u * 0.045);
      final rr = RRect.fromRectAndRadius(r, cellRadius);
      // inner shadow: darker top edge, bright body -> recessed feel
      canvas.drawRRect(
        RRect.fromRectAndRadius(r.translate(0, u * 0.03), cellRadius),
        Paint()..color = const Color(0xFFD3D9E4),
      );
      canvas.drawRRect(rr, cellFill);
      canvas.drawRRect(rr, line);
    }

    // ---------- colored start squares ----------
    BoardMap.startIndex.forEach((color, idx) {
      final r = BoardMap.rectOf(BoardMap.ring[idx], s).deflate(u * 0.045);
      final rr = RRect.fromRectAndRadius(r, cellRadius);
      canvas.drawRRect(
        rr,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color.lerp(color.main, Colors.white, 0.22)!,
              color.main,
              color.dark,
            ],
          ).createShader(r),
      );
      canvas.drawRRect(
        rr,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = u * 0.05
          ..color = Colors.white.withValues(alpha: 0.55),
      );
    });

    // ---------- home columns ----------
    BoardMap.homeColumn.forEach((color, cells) {
      for (final c in cells) {
        final r = BoardMap.rectOf(c, s).deflate(u * 0.045);
        final rr = RRect.fromRectAndRadius(r, cellRadius);
        canvas.drawRRect(
          rr,
          Paint()
            ..shader = LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color.lerp(color.main, Colors.white, 0.18)!,
                color.main,
                color.dark,
              ],
            ).createShader(r),
        );
        canvas.drawRRect(
          rr,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = u * 0.045
            ..color = Colors.white.withValues(alpha: 0.42),
        );
      }
    });

    // ---------- star safe cells (white star, per the reference) ----------
    for (final idx in BoardMap.starRingIndexes) {
      final center = BoardMap.centerOf(BoardMap.ring[idx], s);
      // soft grey halo so the white star reads on a white cell
      canvas.drawCircle(
        center,
        u * 0.33,
        Paint()..color = const Color(0xFF8C93A3).withValues(alpha: 0.28),
      );
      _drawStar(canvas, center, u * 0.31, Colors.white);
      _drawStarOutline(
        canvas,
        center,
        u * 0.31,
        const Color(0xFF7A8296),
        u * 0.035,
      );
    }

    // ---------- arrows pointing into home columns ----------
    _drawArrow(
      canvas,
      BoardMap.centerOf(const Cell(7, 0.5), s),
      u,
      PColor.yellow,
      Direction.right,
    );
    _drawArrow(
      canvas,
      BoardMap.centerOf(const Cell(0.5, 7), s),
      u,
      PColor.blue,
      Direction.down,
    );
    _drawArrow(
      canvas,
      BoardMap.centerOf(const Cell(7, 13.5), s),
      u,
      PColor.red,
      Direction.left,
    );
    _drawArrow(
      canvas,
      BoardMap.centerOf(const Cell(13.5, 7), s),
      u,
      PColor.green,
      Direction.up,
    );

    // ---------- center home ----------
    final cRect = Rect.fromLTWH(u * 6, u * 6, u * 3, u * 3);
    canvas.drawRect(cRect, Paint()..color = Colors.white);
    final cx = cRect.center;
    final tri = <List<Offset>>[
      [cRect.topLeft, cRect.bottomLeft, cx], // left -> yellow
      [cRect.topLeft, cRect.topRight, cx], // top -> blue
      [cRect.topRight, cRect.bottomRight, cx], // right -> red
      [cRect.bottomLeft, cRect.bottomRight, cx], // bottom -> green
    ];
    final triColors = [PColor.yellow, PColor.blue, PColor.red, PColor.green];
    for (var i = 0; i < 4; i++) {
      final path = Path()
        ..moveTo(tri[i][0].dx, tri[i][0].dy)
        ..lineTo(tri[i][1].dx, tri[i][1].dy)
        ..lineTo(tri[i][2].dx, tri[i][2].dy)
        ..close();
      canvas.drawPath(
        path,
        Paint()..color = triColors[i].main.withValues(alpha: 0.92),
      );
    }
    // white house circle in the middle
    canvas.drawCircle(cx, u * 0.85, Paint()..color = Colors.white);
    canvas.drawCircle(
      cx,
      u * 0.85,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = u * 0.07
        ..color = AppColors.boardLine,
    );
    _drawHouse(canvas, cx, u * 0.5);
    canvas.drawRect(
      cRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = u * 0.06
        ..color = AppColors.boardLine,
    );
  }

  void _drawHouse(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = AppColors.accentDeep;
    final path = Path()
      ..moveTo(c.dx, c.dy - r)
      ..lineTo(c.dx + r, c.dy - r * 0.05)
      ..lineTo(c.dx + r * 0.62, c.dy - r * 0.05)
      ..lineTo(c.dx + r * 0.62, c.dy + r * 0.75)
      ..lineTo(c.dx - r * 0.62, c.dy + r * 0.75)
      ..lineTo(c.dx - r * 0.62, c.dy - r * 0.05)
      ..lineTo(c.dx - r, c.dy - r * 0.05)
      ..close();
    canvas.drawPath(path, p);
  }

  void _drawStar(Canvas canvas, Offset c, double r, Color color) {
    final path = Path();
    for (var i = 0; i < 10; i++) {
      final rad = i.isEven ? r : r * 0.45;
      final a = -pi / 2 + i * pi / 5;
      final p = Offset(c.dx + cos(a) * rad, c.dy + sin(a) * rad);
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.drawPath(path, Paint()..color = color);
  }

  void _drawStarOutline(
    Canvas canvas,
    Offset c,
    double r,
    Color color,
    double stroke,
  ) {
    final path = Path();
    for (var i = 0; i < 10; i++) {
      final rad = i.isEven ? r : r * 0.45;
      final a = -pi / 2 + i * pi / 5;
      final p = Offset(c.dx + cos(a) * rad, c.dy + sin(a) * rad);
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = stroke
        ..strokeJoin = StrokeJoin.round
        ..color = color,
    );
  }

  void _drawArrow(
    Canvas canvas,
    Offset c,
    double u,
    PColor color,
    Direction dir,
  ) {
    final size = u * 0.34;
    final path = Path();
    switch (dir) {
      case Direction.right:
        path
          ..moveTo(c.dx - size, c.dy - size)
          ..lineTo(c.dx + size, c.dy)
          ..lineTo(c.dx - size, c.dy + size);
        break;
      case Direction.left:
        path
          ..moveTo(c.dx + size, c.dy - size)
          ..lineTo(c.dx - size, c.dy)
          ..lineTo(c.dx + size, c.dy + size);
        break;
      case Direction.down:
        path
          ..moveTo(c.dx - size, c.dy - size)
          ..lineTo(c.dx, c.dy + size)
          ..lineTo(c.dx + size, c.dy - size);
        break;
      case Direction.up:
        path
          ..moveTo(c.dx - size, c.dy + size)
          ..lineTo(c.dx, c.dy - size)
          ..lineTo(c.dx + size, c.dy + size);
        break;
    }
    path.close();
    canvas.drawPath(path, Paint()..color = color.main);
  }

  @override
  bool shouldRepaint(covariant BoardPainter oldDelegate) => false;
}

enum Direction { up, down, left, right }
