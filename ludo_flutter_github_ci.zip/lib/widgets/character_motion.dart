import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Which animation [CharacterMotion] plays on its child.
enum CharacterMotionStyle {
  /// Character slides/jumps in, squashes on landing, dust ring + gentle
  /// breathing afterwards.
  arrival,

  /// Big pop-in, floating + swaying, rotating light rays and twinkling stars
  /// behind it. Meant for the winner / MVP.
  mvp,

  /// Just a soft breathing loop (lobby, waiting screens).
  idle,
}

/// Brings a flat 2D character PNG to life without any 3D model.
///
/// Wrap any widget (a bare `Image.asset`, a `CharacterCardPanel`, a whole
/// podium entry) and pick a [style]. Everything is plain Flutter animation, no
/// extra packages, so it works in FlutLab / any build.
///
/// ```dart
/// CharacterMotion(
///   style: CharacterMotionStyle.mvp,
///   child: Image.asset('assets/characters/Alok.png', height: 220),
/// )
/// ```
class CharacterMotion extends StatefulWidget {
  const CharacterMotion({
    super.key,
    required this.child,
    this.style = CharacterMotionStyle.arrival,
    this.delay = Duration.zero,
    this.fromSide = 0,
    this.travel = 140,
    this.accent = const Color(0xFFFFC93C),
  });

  final Widget child;
  final CharacterMotionStyle style;

  /// Wait this long before the intro starts (use it to stagger several
  /// characters).
  final Duration delay;

  /// Arrival direction: -1 = from the left, 1 = from the right,
  /// 0 = from below.
  final int fromSide;

  /// How many logical pixels the arrival slide covers.
  final double travel;

  /// Colour of the rays / dust / sparkles.
  final Color accent;

  @override
  State<CharacterMotion> createState() => _CharacterMotionState();
}

class _CharacterMotionState extends State<CharacterMotion>
    with TickerProviderStateMixin {
  late final AnimationController _intro;
  late final AnimationController _loop;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _intro = AnimationController(
      vsync: this,
      duration: Duration(
        milliseconds: widget.style == CharacterMotionStyle.mvp ? 1100 : 900,
      ),
    );
    _loop = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2600),
    )..repeat();

    if (widget.delay == Duration.zero) {
      _intro.forward();
    } else {
      _timer = Timer(widget.delay, () {
        if (mounted) _intro.forward();
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _intro.dispose();
    _loop.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_intro, _loop]),
      builder: (context, _) {
        final t = _intro.value; // 0 -> 1 once
        final loop = _loop.value; // 0 -> 1 repeating
        final wave = math.sin(loop * 2 * math.pi);

        double opacity = 1;
        double dx = 0;
        double dy = 0;
        double sx = 1;
        double sy = 1;
        double rot = 0;

        switch (widget.style) {
          case CharacterMotionStyle.mvp:
            opacity = (t / 0.25).clamp(0.0, 1.0);
            final pop = Curves.elasticOut.transform(t);
            final s = 0.2 + 0.8 * pop;
            sx = s;
            sy = s;
            dy = -wave * 4 * t;
            rot = wave * 0.02 * t;
            break;
          case CharacterMotionStyle.arrival:
            opacity = (t / 0.35).clamp(0.0, 1.0);
            final p = Curves.easeOutBack.transform(t);
            dx = (1 - p) * widget.fromSide * widget.travel;
            dy = widget.fromSide == 0 ? (1 - p) * widget.travel : 0;
            final squash = math.sin(t * math.pi * 3) * (1 - t) * 0.10;
            sx = 1 + squash;
            sy = 1 - squash + wave * 0.012 * t;
            break;
          case CharacterMotionStyle.idle:
            sy = 1 + wave * 0.015;
            break;
        }

        Widget body = Transform(
          alignment: Alignment.bottomCenter,
          transform: Matrix4.diagonal3Values(sx, sy, 1),
          child: widget.child,
        );
        body = Transform.rotate(
          angle: rot,
          alignment: Alignment.bottomCenter,
          child: body,
        );
        body = Transform.translate(offset: Offset(dx, dy), child: body);
        body = Opacity(opacity: opacity, child: body);

        return Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          children: [
            if (widget.style == CharacterMotionStyle.mvp && t > 0)
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _RaysPainter(
                      angle: loop * 2 * math.pi * 0.35,
                      loop: loop,
                      color: widget.accent,
                      strength: Curves.easeOut.transform(t),
                    ),
                  ),
                ),
              ),
            if (widget.style == CharacterMotionStyle.arrival)
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _LandingBurstPainter(
                      progress: ((t - 0.55) / 0.45).clamp(0.0, 1.0),
                      color: widget.accent,
                    ),
                  ),
                ),
              ),
            body,
          ],
        );
      },
    );
  }
}

/// Slowly rotating light wedges + twinkling four-point stars (MVP).
class _RaysPainter extends CustomPainter {
  _RaysPainter({
    required this.angle,
    required this.loop,
    required this.color,
    required this.strength,
  });

  final double angle;
  final double loop;
  final Color color;
  final double strength;

  static const List<Offset> _stars = [
    Offset(-0.06, 0.14),
    Offset(1.06, 0.08),
    Offset(-0.02, 0.62),
    Offset(1.02, 0.55),
    Offset(0.18, -0.06),
    Offset(0.82, -0.04),
    Offset(0.10, 0.95),
    Offset(0.92, 0.92),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.longestSide * 0.95;

    final rayPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          color.withValues(alpha: 0.5 * strength),
          color.withValues(alpha: 0.0),
        ],
      ).createShader(Rect.fromCircle(center: c, radius: r));

    const rays = 14;
    for (var i = 0; i < rays; i++) {
      final a0 = angle + i * 2 * math.pi / rays;
      final a1 = a0 + math.pi / rays * 0.9;
      final path = Path()
        ..moveTo(c.dx, c.dy)
        ..lineTo(c.dx + r * math.cos(a0), c.dy + r * math.sin(a0))
        ..lineTo(c.dx + r * math.cos(a1), c.dy + r * math.sin(a1))
        ..close();
      canvas.drawPath(path, rayPaint);
    }

    final starPaint = Paint()..color = Colors.white.withValues(alpha: 0.95);
    for (var i = 0; i < _stars.length; i++) {
      final tw = math.max(0.0, math.sin(loop * 2 * math.pi * 2 + i * 1.7));
      final s = (6 + size.shortestSide * 0.05) * tw * strength;
      if (s < 0.5) continue;
      final p = Offset(_stars[i].dx * size.width, _stars[i].dy * size.height);
      _star(canvas, p, s, starPaint);
    }
  }

  void _star(Canvas canvas, Offset p, double s, Paint paint) {
    final path = Path()
      ..moveTo(p.dx, p.dy - s)
      ..quadraticBezierTo(p.dx, p.dy, p.dx + s, p.dy)
      ..quadraticBezierTo(p.dx, p.dy, p.dx, p.dy + s)
      ..quadraticBezierTo(p.dx, p.dy, p.dx - s, p.dy)
      ..quadraticBezierTo(p.dx, p.dy, p.dx, p.dy - s)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _RaysPainter old) =>
      old.angle != angle || old.loop != loop || old.strength != strength;
}

/// Expanding dust ring + puffs where the character lands (arrival).
class _LandingBurstPainter extends CustomPainter {
  _LandingBurstPainter({required this.progress, required this.color});

  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    if (progress <= 0 || progress >= 1) return;

    final eased = Curves.easeOut.transform(progress);
    final fade = 1 - progress;
    final feet = Offset(size.width / 2, size.height * 0.96);

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5 * fade + 1
      ..color = color.withValues(alpha: 0.8 * fade);
    final rw = size.width * 0.75 * eased;
    canvas.drawOval(
      Rect.fromCenter(center: feet, width: rw * 2, height: rw * 0.7),
      ring,
    );

    final puff = Paint()..color = Colors.white.withValues(alpha: 0.55 * fade);
    for (var i = 0; i < 6; i++) {
      final dir = i < 3 ? -1.0 : 1.0;
      final k = (i % 3) + 1;
      final x = feet.dx + dir * size.width * 0.12 * k * (0.4 + eased);
      final y = feet.dy - eased * size.height * 0.05 * k;
      canvas.drawCircle(Offset(x, y), (3 + 2.0 * k) * fade, puff);
    }
  }

  @override
  bool shouldRepaint(covariant _LandingBurstPainter old) =>
      old.progress != progress || old.color != color;
}
