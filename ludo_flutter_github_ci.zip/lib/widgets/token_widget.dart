import 'package:flutter/material.dart';

import '../core/theme.dart';

/// A 3D-ish ludo pawn drawn with CustomPaint (no image assets → tiny APK).
class PawnPainter extends CustomPainter {
  PawnPainter({
    required this.color,
    this.highlight = false,
    this.glowPhase = 0,
  });

  final PColor color;
  final bool highlight;
  final double glowPhase;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;

    if (highlight) {
      canvas.drawCircle(
        Offset(cx, h * 0.72),
        w * (0.52 + 0.10 * glowPhase),
        Paint()
          ..color = Colors.white.withValues(alpha: 0.35 * (1 - glowPhase))
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
      );
    }

    // shadow
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(cx, h * 0.90),
        width: w * 0.78,
        height: h * 0.18,
      ),
      Paint()..color = Colors.black.withValues(alpha: 0.28),
    );

    // Richer, higher-contrast body so a pawn always reads clearly even when
    // it is standing on a square of its own colour (reference video look).
    final grad = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Color.lerp(color.main, Colors.white, 0.22)!,
        color.main,
        Color.lerp(color.dark, Colors.black, 0.28)!,
      ],
      stops: const [0.0, 0.45, 1.0],
    );

    // dark contour drawn slightly larger, behind everything → crisp silhouette
    final contour = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.10
      ..strokeJoin = StrokeJoin.round
      ..color = Colors.black.withValues(alpha: 0.34);

    // base
    final baseRect = Rect.fromCenter(
      center: Offset(cx, h * 0.82),
      width: w * 0.80,
      height: h * 0.26,
    );
    canvas.drawOval(baseRect, contour);
    canvas.drawOval(baseRect, Paint()..shader = grad.createShader(baseRect));

    // body (cone)
    final body = Path()
      ..moveTo(cx - w * 0.30, h * 0.82)
      ..quadraticBezierTo(cx - w * 0.16, h * 0.50, cx - w * 0.20, h * 0.40)
      ..lineTo(cx + w * 0.20, h * 0.40)
      ..quadraticBezierTo(cx + w * 0.16, h * 0.50, cx + w * 0.30, h * 0.82)
      ..close();
    final bodyRect = Rect.fromLTWH(cx - w * 0.3, h * 0.4, w * 0.6, h * 0.42);
    canvas.drawPath(body, contour);
    canvas.drawPath(body, Paint()..shader = grad.createShader(bodyRect));

    // head
    final headC = Offset(cx, h * 0.30);
    final headR = w * 0.26;
    final headRect = Rect.fromCircle(center: headC, radius: headR);
    canvas.drawCircle(headC, headR, contour);
    canvas.drawCircle(
      headC,
      headR,
      Paint()..shader = grad.createShader(headRect),
    );

    // specular highlight
    canvas.drawCircle(
      Offset(cx - headR * 0.32, h * 0.30 - headR * 0.34),
      headR * 0.30,
      Paint()..color = Colors.white.withValues(alpha: 0.55),
    );

    // thin white rim on top of the dark contour → pops without washing out
    // the pawn's own colour on small board cells
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * (highlight ? 0.05 : 0.038)
      ..strokeJoin = StrokeJoin.round
      ..color = Colors.white.withValues(alpha: highlight ? 1.0 : 0.75);
    canvas.drawCircle(headC, headR, stroke);
    canvas.drawPath(body, stroke);
  }

  @override
  bool shouldRepaint(covariant PawnPainter old) =>
      old.color != color ||
      old.highlight != highlight ||
      old.glowPhase != glowPhase;
}

class Pawn extends StatelessWidget {
  const Pawn({
    super.key,
    required this.color,
    this.size = 22,
    this.highlight = false,
    this.glowPhase = 0,
    this.count = 1,
  });

  final PColor color;
  final double size;
  final bool highlight;
  final double glowPhase;
  final int count;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size * 1.15,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          CustomPaint(
            size: Size(size, size * 1.15),
            painter: PawnPainter(
              color: color,
              highlight: highlight,
              glowPhase: glowPhase,
            ),
          ),
          // Stack count badge — green circle with a white number, matching
          // the reference gameplay video.
          if (count > 1)
            Positioned(
              right: -size * 0.12,
              top: -size * 0.08,
              child: Container(
                width: size * 0.50,
                height: size * 0.50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF4CE06B), Color(0xFF1F9E3D)],
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: size * 0.045),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.35),
                      blurRadius: size * 0.10,
                      offset: Offset(0, size * 0.03),
                    ),
                  ],
                ),
                child: Text(
                  '$count',
                  style: TextStyle(
                    fontSize: size * 0.32,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    height: 1,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
