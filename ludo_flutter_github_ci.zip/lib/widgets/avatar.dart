import 'dart:math';
import 'package:flutter/material.dart';

/// Procedurally drawn cartoon avatars (like the reference art) so the game
/// stays fully offline with zero image assets.
class GameAvatar extends StatelessWidget {
  const GameAvatar({super.key, required this.seed, this.size = 56});

  final int seed;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _AvatarPainter(seed)),
    );
  }
}

class _AvatarPainter extends CustomPainter {
  _AvatarPainter(this.seed);
  final int seed;

  static const List<Color> _skins = [
    Color(0xFFF0BE96),
    Color(0xFFE0A87A),
    Color(0xFFC98A5D),
    Color(0xFFF6CFAE),
  ];
  static const List<Color> _hairs = [
    Color(0xFF2B2246),
    Color(0xFF14131A),
    Color(0xFF3E2A1C),
    Color(0xFF4A2E6B),
  ];
  static const List<Color> _shirts = [
    Color(0xFF2C6DBF),
    Color(0xFF1E8C55),
    Color(0xFFB93A45),
    Color(0xFFB58B22),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final rnd = Random(seed * 977 + 13);
    final skin = _skins[seed % _skins.length];
    final hair = _hairs[(seed + 1) % _hairs.length];
    final shirt = _shirts[seed % _shirts.length];
    final glasses = rnd.nextBool();
    final mustache = seed % 3 == 1;

    final cx = w / 2;

    // shoulders / shirt
    final shoulder = Path()
      ..moveTo(w * 0.06, h)
      ..quadraticBezierTo(w * 0.12, h * 0.70, cx, h * 0.70)
      ..quadraticBezierTo(w * 0.88, h * 0.70, w * 0.94, h)
      ..close();
    canvas.drawPath(shoulder, Paint()..color = shirt);

    // neck
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(cx, h * 0.70),
          width: w * 0.20,
          height: h * 0.16,
        ),
        Radius.circular(w * 0.06),
      ),
      Paint()..color = Color.lerp(skin, Colors.black, 0.12)!,
    );

    // ears
    canvas.drawCircle(
      Offset(w * 0.255, h * 0.47),
      w * 0.062,
      Paint()..color = skin,
    );
    canvas.drawCircle(
      Offset(w * 0.745, h * 0.47),
      w * 0.062,
      Paint()..color = skin,
    );

    // face
    final faceRect = Rect.fromCenter(
      center: Offset(cx, h * 0.44),
      width: w * 0.50,
      height: h * 0.58,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(faceRect, Radius.circular(w * 0.22)),
      Paint()..color = skin,
    );

    // hair
    final hairPath = Path()
      ..moveTo(w * 0.24, h * 0.42)
      ..quadraticBezierTo(w * 0.20, h * 0.10, cx, h * 0.12)
      ..quadraticBezierTo(w * 0.82, h * 0.10, w * 0.76, h * 0.40)
      ..quadraticBezierTo(w * 0.72, h * 0.24, cx + w * 0.04, h * 0.245)
      ..quadraticBezierTo(w * 0.34, h * 0.27, w * 0.28, h * 0.44)
      ..close();
    canvas.drawPath(hairPath, Paint()..color = hair);

    // eyes
    final eyeY = h * 0.44;
    for (final ex in [cx - w * 0.105, cx + w * 0.105]) {
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(ex, eyeY),
          width: w * 0.10,
          height: h * 0.075,
        ),
        Paint()..color = Colors.white,
      );
      canvas.drawCircle(
        Offset(ex, eyeY),
        w * 0.028,
        Paint()..color = const Color(0xFF2A2440),
      );
    }

    // brows
    final brow = Paint()
      ..color = hair
      ..strokeWidth = w * 0.030
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(cx - w * 0.155, h * 0.375),
      Offset(cx - w * 0.055, h * 0.362),
      brow,
    );
    canvas.drawLine(
      Offset(cx + w * 0.055, h * 0.362),
      Offset(cx + w * 0.155, h * 0.375),
      brow,
    );

    // glasses
    if (glasses) {
      final gp = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.024
        ..color = const Color(0xFF2E2A3D);
      canvas.drawCircle(Offset(cx - w * 0.105, eyeY), w * 0.085, gp);
      canvas.drawCircle(Offset(cx + w * 0.105, eyeY), w * 0.085, gp);
      canvas.drawLine(
        Offset(cx - w * 0.02, eyeY),
        Offset(cx + w * 0.02, eyeY),
        gp,
      );
    }

    // nose
    canvas.drawLine(
      Offset(cx, h * 0.50),
      Offset(cx, h * 0.545),
      Paint()
        ..color = Color.lerp(skin, Colors.black, 0.22)!
        ..strokeWidth = w * 0.022
        ..strokeCap = StrokeCap.round,
    );

    // mustache
    if (mustache) {
      final m = Path()
        ..moveTo(cx - w * 0.115, h * 0.575)
        ..quadraticBezierTo(cx, h * 0.545, cx + w * 0.115, h * 0.575)
        ..quadraticBezierTo(cx, h * 0.625, cx - w * 0.115, h * 0.575)
        ..close();
      canvas.drawPath(m, Paint()..color = hair);
    }

    // smile
    final smile = Path()
      ..moveTo(cx - w * 0.075, h * (mustache ? 0.645 : 0.60))
      ..quadraticBezierTo(
        cx,
        h * (mustache ? 0.695 : 0.655),
        cx + w * 0.075,
        h * (mustache ? 0.645 : 0.60),
      );
    canvas.drawPath(
      smile,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.026
        ..strokeCap = StrokeCap.round
        ..color = const Color(0xFF8A4030),
    );
  }

  @override
  bool shouldRepaint(covariant _AvatarPainter old) => old.seed != seed;
}

/// A character portrait from `assets/characters/`, framed like the reference
/// lobby art. Falls back to the procedural [GameAvatar] if the asset is ever
/// missing, so a bad name can never blank out a seat.
class CharacterPortrait extends StatelessWidget {
  const CharacterPortrait({
    super.key,
    required this.character,
    required this.size,
    this.fallbackSeed = 0,
    this.borderColor,
    this.borderWidth,
    this.radius,
    // Portraits are pre-cropped to the figure; bias the crop towards the head
    // so the small circular/rounded frames show the face.
    this.alignment = const Alignment(0, -0.45),
    this.fit = BoxFit.cover,
  });

  final String character;
  final double size;
  final int fallbackSeed;
  final Color? borderColor;
  final double? borderWidth;
  final double? radius;
  final Alignment alignment;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    final r = radius ?? size * 0.5;
    final bw = borderWidth ?? size * 0.06;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(r),
        color: const Color(0xFF1B2436),
        border: borderColor == null
            ? null
            : Border.all(color: borderColor!, width: bw),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: size * 0.12,
            offset: Offset(0, size * 0.04),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(r - bw * 0.5),
        child: Image.asset(
          'assets/characters/$character.png',
          fit: fit,
          alignment: alignment,
          filterQuality: FilterQuality.medium,
          errorBuilder: (_, __, ___) =>
              GameAvatar(seed: fallbackSeed, size: size),
        ),
      ),
    );
  }
}

/// A character portrait overlaid directly onto its coloured corner panel —
/// no frame, plate or border, and (unlike the old "blend" behaviour) no
/// cropping or stretching either.
///
/// The bundled artwork has had its background fully removed (true alpha
/// transparency), so this simply lays the cutout on top of the seat's own
/// colour "as-is" (`BoxFit.contain`) — the character's own edges are the
/// only edges you see, exactly like a clean sticker placed on the panel,
/// rather than a rectangular photo stretched/cropped to fill the block.
class CharacterBlend extends StatelessWidget {
  const CharacterBlend({
    super.key,
    required this.character,
    this.fallbackSeed = 0,
    // The figure is anchored to the bottom of its block so its feet sit on
    // the panel's own floor line, while the head reaches up near the top —
    // a true "full portrait", not just a bottom-corner accent.
    this.alignment = Alignment.bottomCenter,
    this.widthFactor = 1.05,
  });

  final String character;
  final int fallbackSeed;
  final Alignment alignment;

  /// Fraction of the block's width the figure occupies.
  final double widthFactor;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, cts) {
        final w = cts.maxWidth * widthFactor;
        return Align(
          alignment: alignment,
          child: SizedBox(
            width: w,
            height: cts.maxHeight,
            child: Image.asset(
              'assets/characters/$character.png',
              // BoxFit.contain: show the transparent cutout exactly as-is,
              // never cropped or stretched — the coloured panel behind it
              // shows straight through the removed background.
              fit: BoxFit.contain,
              alignment: alignment,
              filterQuality: FilterQuality.medium,
              errorBuilder: (_, __, ___) =>
                  GameAvatar(seed: fallbackSeed, size: w),
            ),
          ),
        );
      },
    );
  }
}
