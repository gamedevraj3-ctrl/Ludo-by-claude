import 'dart:math';

import 'package:flutter/material.dart';

import '../core/theme.dart';

/// White 3D dice face drawn with CustomPaint.
class DiceFace extends StatelessWidget {
  const DiceFace({
    super.key,
    required this.value,
    this.size = 34,
    this.dotColor = AppColors.accentDeep,
    this.faceColor = Colors.white,
  });

  final int value;
  final double size;
  final Color dotColor;
  final Color faceColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.22),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [faceColor, Color.lerp(faceColor, Colors.grey, 0.22)!],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: size * 0.15,
            offset: Offset(0, size * 0.07),
          ),
        ],
      ),
      child: CustomPaint(painter: _DotsPainter(value, dotColor)),
    );
  }
}

class _DotsPainter extends CustomPainter {
  _DotsPainter(this.value, this.color);
  final int value;
  final Color color;

  static const Map<int, List<List<double>>> layout = {
    1: [
      [0.5, 0.5],
    ],
    2: [
      [0.28, 0.28],
      [0.72, 0.72],
    ],
    3: [
      [0.26, 0.26],
      [0.5, 0.5],
      [0.74, 0.74],
    ],
    4: [
      [0.28, 0.28],
      [0.72, 0.28],
      [0.28, 0.72],
      [0.72, 0.72],
    ],
    5: [
      [0.26, 0.26],
      [0.74, 0.26],
      [0.5, 0.5],
      [0.26, 0.74],
      [0.74, 0.74],
    ],
    6: [
      [0.28, 0.24],
      [0.72, 0.24],
      [0.28, 0.5],
      [0.72, 0.5],
      [0.28, 0.76],
      [0.72, 0.76],
    ],
  };

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.width * 0.088;
    final p = Paint()..color = color;
    final dots = layout[value.clamp(1, 6)]!;
    for (final d in dots) {
      canvas.drawCircle(Offset(d[0] * size.width, d[1] * size.height), r, p);
    }
  }

  @override
  bool shouldRepaint(covariant _DotsPainter old) =>
      old.value != value || old.color != color;
}

/// Big tappable roll button at the bottom (like the reference art).
class RollDiceButton extends StatefulWidget {
  const RollDiceButton({
    super.key,
    required this.value,
    required this.enabled,
    required this.rolling,
    required this.onTap,
    this.turnProgress = 1.0,
    this.ringColor,
  });

  final int? value;
  final bool enabled;
  final bool rolling;
  final VoidCallback onTap;

  /// 1.0 → full turn time left, 0.0 → time over. Drawn as a draining arc.
  final double turnProgress;

  /// Colour of the draining arc — the active player's colour.
  final Color? ringColor;

  @override
  State<RollDiceButton> createState() => _RollDiceButtonState();
}

class _RollDiceButtonState extends State<RollDiceButton>
    with SingleTickerProviderStateMixin {
  // slow, calm breathing pulse (was a fast 1.1s flash)
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1700),
  )..repeat(reverse: true);

  // gentle continuous tumble rotation used only while rolling
  late final AnimationController _spin = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );

  @override
  void didUpdateWidget(RollDiceButton old) {
    super.didUpdateWidget(old);
    if (widget.rolling && !_spin.isAnimating) {
      _spin.repeat();
    } else if (!widget.rolling && _spin.isAnimating) {
      _spin.stop();
      _spin.value = 0;
    }
  }

  @override
  void dispose() {
    _c.dispose();
    _spin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.enabled ? widget.onTap : null,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final pulse = widget.enabled ? _c.value : 0.0;
          final ring = widget.ringColor ?? AppColors.glow;
          final dice = Container(
            width: 84,
            height: 84,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF6E52D8), Color(0xFF3B2A86)],
              ),
              border: Border.all(
                color: widget.enabled
                    ? AppColors.glow.withValues(alpha: 0.55 + 0.45 * pulse)
                    : Colors.white24,
                width: 2.4,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.glow.withValues(
                    alpha: widget.enabled ? 0.28 + 0.25 * pulse : 0.06,
                  ),
                  blurRadius: 22 + 12 * pulse,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Center(
              child: AnimatedScale(
                scale: widget.rolling ? 1.10 : 1.0,
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOut,
                child: AnimatedBuilder(
                  animation: _spin,
                  builder: (context, child) => Transform.rotate(
                    angle: widget.rolling ? _spin.value * 2 * pi : 0,
                    child: child,
                  ),
                  child: DiceFace(
                    value: widget.value ?? 6,
                    size: 44,
                    faceColor: widget.enabled
                        ? Colors.white
                        : const Color(0xFFB9B3D6),
                  ),
                ),
              ),
            ),
          );

          // Outer draining turn-timer ring in the active player's colour
          // (matches the reference gameplay video).
          return SizedBox(
            width: 100,
            height: 100,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomPaint(
                  size: const Size(100, 100),
                  painter: _TurnRingPainter(
                    progress: widget.turnProgress.clamp(0.0, 1.0),
                    color: ring,
                  ),
                ),
                dice,
              ],
            ),
          );
        },
      ),
    );
  }
}

/// Circular draining progress arc used around the roll button.
class _TurnRingPainter extends CustomPainter {
  _TurnRingPainter({required this.progress, required this.color});

  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2 - 3.5;
    final track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round
      ..color = Colors.black.withValues(alpha: 0.35);
    canvas.drawCircle(c, r, track);

    if (progress <= 0) return;
    final low = progress < 0.3;
    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round
      ..color = low ? const Color(0xFFFF4D5E) : color;
    canvas.drawArc(
      Rect.fromCircle(center: c, radius: r),
      -pi / 2,
      2 * pi * progress,
      false,
      arc,
    );
  }

  @override
  bool shouldRepaint(covariant _TurnRingPainter old) =>
      old.progress != progress || old.color != color;
}

/// Ludo King style corner dice used in PASS & PLAY.
///
/// It is the two-segment conjoined plate from the reference art: a narrow
/// segment carrying that seat's location-pin badge, joined to a wider tray with
/// a gold border holding the white die. Both segments are tinted with the
/// player's own colour, so every board colour gets its own matching dice.
///
/// [pinOnLeft] flips which side the pin sits on, so the pin always faces the
/// board and the die always faces the outside of the screen.
class CornerDicePlate extends StatelessWidget {
  const CornerDicePlate({
    super.key,
    required this.value,
    required this.width,
    required this.seatColor,
    required this.seatDark,
    this.pinOnLeft = true,
    this.live = false,
    this.pulse = 0.0,
    this.turnProgress,
  });

  /// Number to display. `null` = this seat has not rolled yet, so a blank face
  /// is drawn rather than pretending a 6 was thrown.
  final int? value;

  /// Total width of the conjoined plate. Height is derived from it.
  final double width;

  /// That player's colour — drives the pin segment and the glow.
  final Color seatColor;
  final Color seatDark;

  final bool pinOnLeft;

  /// True while this seat may actually tap to roll.
  final bool live;

  /// 0→1 breathing value driving the glow while [live].
  final double pulse;

  /// 1.0 → full turn time left, 0.0 → out of time. Null hides the ring.
  final double? turnProgress;

  // Reference proportions: pin segment ~40%, dice tray ~60%.
  static const double _pinFrac = 0.40;

  @override
  Widget build(BuildContext context) {
    final h = width * 0.62;
    final radius = h * 0.26;
    const gold = Color(0xFFE3C77A);

    final pin = _PinSegment(
      height: h,
      seatColor: seatColor,
      seatDark: seatDark,
      live: live,
      turnProgress: turnProgress,
    );

    final tray = _DiceSegment(
      height: h,
      value: value,
      live: live,
      pulse: pulse,
    );

    return Container(
      width: width,
      height: h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: live
              ? Color.lerp(gold, Colors.white, 0.30 + 0.35 * pulse)!
              : gold.withValues(alpha: 0.62),
          width: h * 0.075,
        ),
        boxShadow: [
          BoxShadow(
            color: live
                ? seatColor.withValues(alpha: 0.50 + 0.35 * pulse)
                : Colors.black.withValues(alpha: 0.42),
            blurRadius: live ? h * 0.42 + h * 0.22 * pulse : h * 0.18,
            spreadRadius: live ? h * 0.03 : 0,
            offset: Offset(0, h * 0.05),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius * 0.86),
        child: Row(
          children: pinOnLeft
              ? [
                  SizedBox(width: width * _pinFrac, child: pin),
                  Expanded(child: tray),
                ]
              : [
                  Expanded(child: tray),
                  SizedBox(width: width * _pinFrac, child: pin),
                ],
        ),
      ),
    );
  }
}

/// The narrow coloured segment holding the map-pin badge. Doubles as the
/// turn-timer: a thin arc sweeps around the pin while that seat is deciding.
class _PinSegment extends StatelessWidget {
  const _PinSegment({
    required this.height,
    required this.seatColor,
    required this.seatDark,
    required this.live,
    required this.turnProgress,
  });

  final double height;
  final Color seatColor;
  final Color seatDark;
  final bool live;
  final double? turnProgress;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        // dark at the bottom, brighter at the top, as in the reference
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: live
              ? [Color.lerp(seatColor, Colors.white, 0.28)!, seatDark]
              : [
                  Color.lerp(
                    seatColor,
                    Colors.white,
                    0.10,
                  )!.withValues(alpha: 0.80),
                  seatDark.withValues(alpha: 0.80),
                ],
        ),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (turnProgress != null)
            Padding(
              padding: EdgeInsets.all(height * 0.10),
              child: AspectRatio(
                aspectRatio: 1,
                child: CircularProgressIndicator(
                  value: turnProgress!.clamp(0.0, 1.0),
                  strokeWidth: height * 0.075,
                  backgroundColor: Colors.black.withValues(alpha: 0.22),
                  valueColor: AlwaysStoppedAnimation(
                    turnProgress! <= 0.3
                        ? const Color(0xFFFFE04A)
                        : Colors.white,
                  ),
                ),
              ),
            ),
          CustomPaint(
            size: Size(height * 0.44, height * 0.54),
            painter: _MapPinPainter(coreColor: seatColor),
          ),
        ],
      ),
    );
  }
}

/// White teardrop map pin with a coloured core, drawn to match the reference.
class _MapPinPainter extends CustomPainter {
  _MapPinPainter({required this.coreColor});
  final Color coreColor;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final headR = w * 0.5;
    final headC = Offset(w * 0.5, headR);

    // teardrop = circular head + tapered tail down to the tip
    final path = Path()
      ..addOval(Rect.fromCircle(center: headC, radius: headR))
      ..moveTo(w * 0.16, h * 0.60)
      ..quadraticBezierTo(w * 0.42, h * 0.86, w * 0.5, h)
      ..quadraticBezierTo(w * 0.58, h * 0.86, w * 0.84, h * 0.60)
      ..close();

    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.28)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.10),
    );
    canvas.drawPath(path, Paint()..color = Colors.white);

    // coloured core
    canvas.drawCircle(headC, headR * 0.44, Paint()..color = coreColor);
  }

  @override
  bool shouldRepaint(covariant _MapPinPainter old) =>
      old.coreColor != coreColor;
}

/// The cream tray holding the white die with black pips.
class _DiceSegment extends StatelessWidget {
  const _DiceSegment({
    required this.height,
    required this.value,
    required this.live,
    required this.pulse,
  });

  final double height;
  final int? value;
  final bool live;
  final double pulse;

  @override
  Widget build(BuildContext context) {
    final die = height * 0.62;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: live
              ? const [Color(0xFFFFFDF5), Color(0xFFF0E7D2)]
              : [
                  const Color(0xFFFFFDF5).withValues(alpha: 0.70),
                  const Color(0xFFF0E7D2).withValues(alpha: 0.70),
                ],
        ),
      ),
      alignment: Alignment.center,
      child: value == null
          // Nothing rolled yet this match — a neutral blank face rather than
          // a misleading default 6.
          ? Container(
              width: die,
              height: die,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(die * 0.20),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFFFFFFF), Color(0xFFDCD8CF)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.20),
                    blurRadius: die * 0.14,
                    offset: Offset(0, die * 0.06),
                  ),
                ],
              ),
            )
          : Container(
              width: die,
              height: die,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(die * 0.20),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFFFFFFF), Color(0xFFE8E5DE)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.26),
                    blurRadius: die * 0.16,
                    offset: Offset(0, die * 0.07),
                  ),
                  if (live)
                    BoxShadow(
                      color: Colors.white.withValues(alpha: 0.5 * pulse),
                      blurRadius: die * 0.30,
                    ),
                ],
              ),
              child: CustomPaint(
                painter: _DotsPainter(value!, const Color(0xFF14121A)),
              ),
            ),
    );
  }
}
