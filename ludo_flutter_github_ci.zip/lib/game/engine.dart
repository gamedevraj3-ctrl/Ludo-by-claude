import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../core/theme.dart';
import 'board_map.dart';
import 'game_speed.dart';
import 'characters.dart';
import 'models.dart';

/// Every sound effect the engine can request from the UI layer.
enum GameSfx {
  matchStart,
  diceRoll,
  diceSix,
  hop,
  tokenOpen,
  cut,
  home,
  extraTurn,
  noMove,
  miss,
  forfeit,
  win,
  lose,
  tap,

  /// Free-Fire-style menu click — lobby / login / loading / store /
  /// characters / victory screens only. Never fired for in-match dice or
  /// board interactions (see Update #2 item 8).
  uiClick,
}

/// An opponent token that a candidate move would cut.
class _Victim {
  const _Victim(this.player, this.value);
  final Player player;
  final int value;
}

/// One log/toast event produced by the engine.
class GameEvent {
  final String text;
  final PColor? color;
  final int stamp;
  GameEvent(this.text, {this.color})
    : stamp = DateTime.now().microsecondsSinceEpoch;
}

/// Ludo rules engine — 100% local, no network at all.
///
/// Supports two rule sets (see [MatchMode]):
///
/// RUSH MODE (score race)
///  * Match is time limited (default 6 min).
///  * All 4 tokens start already OPEN on the start square (no 6 needed).
///  * 1 step = 1 point. Reaching HOME = +56 bonus points.
///  * Cutting steals every point the victim token had earned — the victim
///    loses them and the CUTTER gains them.
///  * Highest score when the clock runs out wins.
///
/// CLASSIC MODE (traditional)
///  * No clock, no scoring at all.
///  * A 6 is required to bring a token out of the yard.
///  * First player to bring all 4 tokens HOME wins.
///
/// SHARED RULES
///  * Star cells + start squares are SAFE (no cutting, stacking allowed).
///  * BLOCK: 2, 3 or 4 tokens of the SAME colour standing on one cell form a
///    block and can never be cut, anywhere on the board.
///  * Rolling a 6 or cutting a token grants an extra turn.
///  * Three sixes in a row: the third roll is void, the turn is forfeited.
///  * Per turn timer; miss the turn -> counted as a miss.
///  * 3 consecutive misses -> player eliminated.
class LudoEngine extends ChangeNotifier {
  LudoEngine({required this.config, GameSpeed? speed, this.onSound})
    : speed = speed ?? GameSpeed(preset: config.speed) {
    _setupPlayers();
    _remainingMatch = config.matchSeconds;
    _turnRemaining = config.turnSeconds;
  }

  /// Fired for every sound effect the UI should play.
  final void Function(GameSfx sfx)? onSound;

  void _sfx(GameSfx s) => onSound?.call(s);

  bool get isClassic => config.matchMode.isClassic;
  bool get isRush => config.matchMode.isRush;

  final GameConfig config;

  /// Every pause in the match is produced here so the pacing stays
  /// human-like instead of instant/robotic.
  GameSpeed speed;

  /// Change pacing mid-match (from the in-game settings sheet).
  void setSpeed(SpeedPreset preset) {
    if (speed.preset == preset) return;
    speed = GameSpeed(preset: preset);
    notifyListeners();
  }

  SpeedPreset get speedPreset => speed.preset;

  final Random _rng = Random();

  late List<Player> players;
  int currentIndex = 0;

  int? dice; // last rolled value (null = not rolled yet this turn)
  bool rolling = false;
  bool moving = false;
  bool extraTurn = false;
  int turnsPlayed = 0;

  /// Consecutive sixes rolled by the CURRENT player this turn sequence.
  /// On the third six the roll is void and the whole turn is forfeited.
  int sixStreak = 0;

  /// Bumped every single time a turn ends for ANY reason (played, missed,
  /// forfeited, extra turn, seat change).
  ///
  /// `rollDice()` and `moveToken()` are long async chains full of animation
  /// delays. If the turn clock ran out half way through one of those chains
  /// the seat would advance underneath it, and when the old chain woke up it
  /// happily called `_endTurn()` on the NEW player — which is what produced
  /// the bogus "Player 2 rolled null — no move" toast. Every chain now
  /// remembers the epoch it started in and quietly abandons itself the moment
  /// that epoch is gone.
  int _turnEpoch = 0;

  int _remainingMatch = 600;
  int _turnRemaining = 15;
  bool started = false;
  bool finished = false;
  bool paused = false;

  Timer? _ticker;
  final List<GameEvent> events = [];

  /// token indexes that can legally move with current dice
  List<int> movable = [];

  /// token currently animating (for highlight)
  int? animatingToken;

  /// token that just hopped one cell (drives the little bounce animation)
  int? hopToken;

  /// increments on every single-cell hop so the UI can re-trigger a bounce
  int hopSeq = 0;

  Player get current => players[currentIndex];
  Player get me =>
      players.firstWhere((p) => !p.isBot, orElse: () => players.first);
  int get remainingMatch => _remainingMatch;
  int get turnRemaining => _turnRemaining;
  bool get myTurn => !current.isBot && !finished;

  // ---------------------------------------------------------------- setup

  // Bots no longer use a hard-coded nickname list — each one is named after
  // the character portrait it is wearing (see Characters.pickBots).

  void _setupPlayers() {
    // Human always sits bottom-left (green). Opponents are spread around the
    // board so 2/3/4 player games all look balanced.
    const seats2 = [Seat.bottomLeft, Seat.topRight];
    const seats3 = [Seat.bottomLeft, Seat.topRight, Seat.topLeft];
    const seats4 = [
      Seat.bottomLeft,
      Seat.topRight,
      Seat.topLeft,
      Seat.bottomRight,
    ];
    final seats = switch (config.playerCount) {
      2 => seats2,
      3 => seats3,
      _ => seats4,
    };

    // In classic mode tokens stay in the yard until a 6 opens them.
    final openAtStart = config.matchMode.isRush;

    // Seat 0 wears the character the human picked in the lobby; every other
    // seat gets a DIFFERENT one, so no two players in a match ever share a
    // face or a name. A bot's name is simply its character's name.
    final others = Characters.pickBots(
      seats.length - 1,
      exclude: config.myCharacter,
      rng: _rng,
    );

    players = [];
    for (var i = 0; i < seats.length; i++) {
      final isHuman = config.mode == GameMode.passAndPlay ? true : i == 0;
      final character = i == 0
          ? Characters.byName(config.myCharacter).name
          : others[i - 1].name;
      players.add(
        Player(
          id: i,
          // Bots (and the other pass-&-play seats) are named after the
          // character they are wearing.
          name: i == 0 ? config.myName : character,
          color: seats[i].color,
          seat: seats[i],
          isBot: !isHuman,
          avatarSeed: i,
          character: character,
          // Only the local player has a real profile name to show alongside
          // their character.
          realName: i == 0 ? config.myName : null,
          tokensOpen: openAtStart,
        ),
      );
    }
    currentIndex = 0;
  }

  // ---------------------------------------------------------------- timers

  void start() {
    if (started) return;
    started = true;
    _turnRemaining = config.turnSeconds;
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
    _sfx(GameSfx.matchStart);
    _log(
      config.timed
          ? 'Match started! ${_fmt(config.matchSeconds)} on the clock'
          : 'Classic match started — first to bring all 4 tokens home wins',
    );
    notifyListeners();
    // give the player a moment to see the board before the first turn runs
    _schedule(speed.turnHandover, _maybeBotTurn);
  }

  void _tick() {
    if (finished || paused) return;
    // Classic mode has no match clock — it runs until somebody finishes.
    if (config.timed) {
      _remainingMatch--;
      if (_remainingMatch <= 0) {
        _remainingMatch = 0;
        _finish('Time up!');
        return;
      }
    }
    // The turn clock only runs while the player is actually deciding.
    // It is frozen during the dice tumble, the pawn animation and while a
    // bot is "thinking", so slower pacing never causes an unfair miss.
    final busy = rolling || moving || current.isBot;
    if (!busy) {
      _turnRemaining--;
      if (_turnRemaining <= 0) {
        _missTurn();
      }
    }
    notifyListeners();
  }

  // ---------------------------------------------------------------- pause
  //
  // Pausing has to freeze EVERYTHING: the match clock, the turn clock, the
  // pawn/dice animations and — most importantly — the queued "next turn" and
  // "bot picks up the dice" callbacks. Previously those callbacks simply
  // returned when they woke up during a pause, which silently killed the turn
  // chain and left the match stuck forever after resuming.

  void pause() {
    if (paused || finished) return;
    paused = true;
    notifyListeners();
  }

  void resume() {
    if (!paused) return;
    paused = false;
    notifyListeners();
    // Safety net: if the turn chain was interrupted, kick it back to life.
    _kickTurn();
  }

  void togglePause() => paused ? resume() : pause();

  /// Waits [d], then keeps waiting for as long as the match is paused.
  /// Every engine delay goes through here, so a pause really does stop time.
  Future<void> _wait(Duration d) async {
    await Future<void>.delayed(d);
    while (paused && !finished) {
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
  }

  /// Pause-aware replacement for `Future.delayed(d, fn)`.
  void _schedule(Duration d, void Function() fn) {
    _wait(d).then((_) {
      if (!finished) fn();
    });
  }

  /// True when the turn that started at [epoch] is still the live turn.
  /// Async chains check this after every delay and bail out if it is false.
  bool _sameTurn(int epoch) => !finished && _turnEpoch == epoch;

  /// Restarts whatever the match was waiting for. Safe to call at any time —
  /// it does nothing unless the game is genuinely idle.
  void _kickTurn() {
    if (finished || !started || paused) return;
    if (rolling || moving) return;
    if (current.isBot && dice == null) {
      _maybeBotTurn();
    } else {
      notifyListeners();
    }
  }

  // ---------------------------------------------------------------- rolling

  Future<void> rollDice() async {
    if (finished || rolling || moving || paused) return;
    if (dice != null) return; // already rolled, must move
    final epoch = _turnEpoch;
    rolling = true;
    notifyListeners();

    // Dice tumble: frames slow down towards the end (losing momentum).
    final frames = speed.diceTumbleFrames;
    for (var i = 0; i < frames; i++) {
      dice = 1 + _rng.nextInt(6);
      notifyListeners();
      await _wait(speed.diceTumbleGap(i, frames));
      // Turn ran out mid-tumble -> this roll belongs to nobody now.
      if (!_sameTurn(epoch)) {
        rolling = false;
        return;
      }
    }
    dice = _fairRoll();
    // Remember it on the player too, so their corner dice keeps showing the
    // number they really rolled once the turn moves on.
    current.lastDice = dice;
    rolling = false;
    _sfx(dice == 6 ? GameSfx.diceSix : GameSfx.diceRoll);
    movable = _movableTokens(current, dice!);
    notifyListeners();

    // let the player actually read the rolled number
    await _wait(speed.afterDiceSettle);
    if (!_sameTurn(epoch)) return;

    // ---- three sixes in a row: this roll is void, turn is forfeited ----
    if (dice == 6) {
      sixStreak++;
      if (sixStreak >= 3) {
        _log(
          '${current.name} rolled three 6s — turn forfeited!',
          color: current.color,
        );
        _sfx(GameSfx.forfeit);
        movable = [];
        notifyListeners();
        await _wait(speed.noMovePause);
        if (!_sameTurn(epoch)) return;
        _forfeitTurn();
        return;
      }
    } else {
      sixStreak = 0;
    }

    if (movable.isEmpty) {
      _log('${current.name} rolled $dice — no move', color: current.color);
      _sfx(GameSfx.noMove);
      await _wait(speed.noMovePause);
      if (!_sameTurn(epoch)) return;
      _endTurn(gotSix: dice == 6, cut: false);
      return;
    }

    if (current.isBot) {
      // bot "thinks" — longer when it has more options to weigh
      await _wait(speed.botChooseToken(movable.length));
      if (!_sameTurn(epoch)) return;
      final pick = _botChoose(current, dice!, movable);
      await moveToken(pick);
    } else if (movable.length == 1) {
      // only one legal option -> move it for the player, but slow enough
      // that they can see which token was chosen
      await _wait(speed.singleOptionAutoMove);
      if (!_sameTurn(epoch)) return;
      await moveToken(movable.first);
    }
  }

  /// Plain, honest 1..6 dice. No weighting, no "lucky" bias — every face has
  /// exactly the same chance for humans, bots and pass-and-play friends alike.
  int _fairRoll() => 1 + _rng.nextInt(6);

  /// How many of [owner]'s own tokens are standing on ring cell [ring].
  ///
  /// Used for the BLOCK rule: 2, 3 or 4 tokens of the same colour sharing one
  /// cell protect each other and can never be cut.
  int _stackSizeOn(Player owner, int ring) {
    var n = 0;
    for (final t in owner.tokens) {
      if (!t.onBoard || t.pos > BoardMap.lastRingStep) continue;
      if (BoardMap.ringIndexFor(owner.color, t.pos) == ring) n++;
    }
    return n;
  }

  /// True when [owner]'s token sitting on [pos] is un-cuttable, either because
  /// the cell itself is safe (star / start box / home column) or because the
  /// cell hosts a same-colour BLOCK of 2 or more tokens (belonging to ANY
  /// player, not just [owner] — see [_cellHasBlock]).
  bool _isProtected(Player owner, int pos) {
    if (BoardMap.isSafePos(owner.color, pos)) return true;
    return _cellHasBlock(BoardMap.ringIndexFor(owner.color, pos));
  }

  /// True when ANY player currently has a same-colour BLOCK (2, 3 or 4
  /// tokens) standing on ring cell [ring].
  ///
  /// Once a block exists on a cell the WHOLE cell becomes protected — even a
  /// lone token of a DIFFERENT colour that simply walked onto that same cell
  /// is shielded by the block and cannot be cut, exactly like a star cell.
  bool _cellHasBlock(int ring) {
    for (final o in players) {
      if (_stackSizeOn(o, ring) >= 2) return true;
    }
    return false;
  }

  /// Would a token of [p] landing on path position [np] cut somebody?
  bool _wouldCut(Player p, int np) {
    if (np > BoardMap.lastRingStep) return false;
    if (BoardMap.isSafePos(p.color, np)) return false;
    final ring = BoardMap.ringIndexFor(p.color, np);
    for (final o in players) {
      if (o.id == p.id) continue;
      for (final ot in o.tokens) {
        if (!ot.onBoard || ot.pos > BoardMap.lastRingStep) continue;
        if (BoardMap.ringIndexFor(o.color, ot.pos) != ring) continue;
        if (_isProtected(o, ot.pos)) continue; // safe cell or block
        return true;
      }
    }
    return false;
  }

  // ---------------------------------------------------------------- moving

  List<int> _movableTokens(Player p, int d) {
    final res = <int>[];
    for (final t in p.tokens) {
      if (t.finished) continue;
      // classic mode: a yarded token can only be opened with a 6
      if (!t.open) {
        if (d == 6) res.add(t.index);
        continue;
      }
      if (t.pos + d <= BoardMap.homeStep) res.add(t.index);
    }
    return res;
  }

  Future<void> moveToken(int tokenIndex) async {
    if (finished || moving || dice == null) return;
    if (!movable.contains(tokenIndex)) return;

    moving = true;
    animatingToken = tokenIndex;
    final p = current;
    final t = p.tokens[tokenIndex];
    final steps = dice!;
    movable = [];
    notifyListeners();

    // tiny beat before the pawn lifts off
    await _wait(speed.beforePawnMove);

    // ---- classic mode: opening a yarded token with a 6 ----
    if (!t.open) {
      t.open = true;
      t.pos = 0;
      hopToken = tokenIndex;
      hopSeq++;
      _sfx(GameSfx.tokenOpen);
      _log('${p.name} opened a token', color: p.color);
      notifyListeners();
      await _wait(speed.pawnHop(0, 1));
      hopToken = null;
      final openCut = _resolveCut(p, t);
      animatingToken = null;
      moving = false;
      notifyListeners();
      await _wait(openCut ? speed.cutPause : speed.afterPawnMove);
      _endTurn(gotSix: true, cut: openCut);
      return;
    }

    // step-by-step hop animation (+1 point per step in rush mode)
    for (var i = 0; i < steps; i++) {
      t.pos += 1;
      if (isRush) p.score += 1; // 1 step = 1 point (rush only)
      hopToken = tokenIndex;
      hopSeq++;
      _sfx(GameSfx.hop);
      notifyListeners();
      await _wait(speed.pawnHop(i, steps));
      if (finished) {
        hopToken = null;
        moving = false;
        return;
      }
    }
    hopToken = null;

    var cut = false;
    var reachedHome = false;

    if (t.pos == BoardMap.homeStep) {
      t.finished = true;
      if (isRush) p.score += 56; // HOME bonus (rush only)
      reachedHome = true;
      _sfx(GameSfx.home);
      _log(
        isRush
            ? '${p.name} sent a token HOME  +56'
            : '${p.name} sent a token HOME',
        color: p.color,
      );
    } else {
      cut = _resolveCut(p, t);
    }

    animatingToken = null;
    moving = false;
    notifyListeners();

    if (reachedHome && p.allHome) {
      _log('${p.name} finished all 4 tokens!', color: p.color);
      // Classic mode: the first player to finish all 4 tokens wins outright.
      if (isClassic) {
        _sfx(GameSfx.win);
        await _wait(speed.homeCelebration);
        _finish('${p.name} brought all 4 tokens home');
        return;
      }
    }

    // let big moments breathe
    if (reachedHome) {
      await _wait(speed.homeCelebration);
    } else if (cut) {
      await _wait(speed.cutPause);
    } else {
      await _wait(speed.afterPawnMove);
    }
    _endTurn(gotSix: steps == 6, cut: cut);
  }

  /// Resolves a cut on the cell [t] just landed on.
  ///
  /// Rush mode: every point the victim token had earned is TRANSFERRED to the
  /// cutter — the victim loses them, the cutter gains them.
  /// Classic mode: the victim token simply goes back to its yard.
  ///
  /// BLOCK RULE: if ANY colour has 2, 3 or 4 tokens standing on that cell it
  /// forms a block, and the WHOLE cell becomes protected — including a lone
  /// token of a completely DIFFERENT colour that simply joined the block's
  /// cell. None of them can be cut; the landing token just shares the cell.
  ///
  /// Returns true if a cut happened.
  bool _resolveCut(Player p, Token t) {
    if (t.pos > BoardMap.lastRingStep) return false;
    if (BoardMap.isSafePos(p.color, t.pos)) return false;

    final myRing = BoardMap.ringIndexFor(p.color, t.pos);

    // Every opponent token standing on the landing cell, grouped by owner.
    final Map<int, List<Token>> onCellByOwner = {};
    for (final other in players) {
      if (other.id == p.id) continue;
      final onCell = other.tokens
          .where(
            (ot) =>
                ot.onBoard &&
                ot.pos <= BoardMap.lastRingStep &&
                BoardMap.ringIndexFor(other.color, ot.pos) == myRing,
          )
          .toList();
      if (onCell.isNotEmpty) onCellByOwner[other.id] = onCell;
    }
    if (onCellByOwner.isEmpty) return false;

    // BLOCK: once any colour has 2+ tokens here, the ENTIRE cell is shielded
    // — even single tokens of a different colour standing alongside it.
    final hasBlock = onCellByOwner.values.any((toks) => toks.length >= 2);
    if (hasBlock) {
      for (final entry in onCellByOwner.entries) {
        final other = players.firstWhere((pl) => pl.id == entry.key);
        _log(
          '${other.name} is shielded by a block on this cell — safe!',
          color: other.color,
        );
      }
      return false;
    }

    var didCut = false;
    for (final entry in onCellByOwner.entries) {
      final other = players.firstWhere((pl) => pl.id == entry.key);
      // No block exists on this cell, so every owner present has exactly
      // one token here.
      final ot = entry.value.first;
      final stolen = ot.carried;
      if (isRush) {
        // points change hands
        other.score -= stolen;
        if (other.score < 0) other.score = 0;
        p.score += stolen;
        _log(
          '${p.name} CUT ${other.name} and stole $stolen points',
          color: p.color,
        );
      } else {
        _log('${p.name} cut ${other.name}\'s token', color: p.color);
      }

      // send the victim token back
      ot.pos = 0;
      if (isClassic) ot.open = false; // back to the yard, needs a 6 again
      didCut = true;
    }
    if (didCut) _sfx(GameSfx.cut);
    return didCut;
  }

  // ---------------------------------------------------------------- turns

  void _endTurn({required bool gotSix, required bool cut}) {
    _turnEpoch++; // any in-flight chain from the old turn is now void
    dice = null;
    movable = [];
    turnsPlayed++;
    current.misses = 0; // played successfully -> reset miss streak

    if (finished) return;

    if ((gotSix || cut) && current.active) {
      extraTurn = true;
      _turnRemaining = config.turnSeconds;
      _sfx(GameSfx.extraTurn);
      _log('${current.name} gets an extra turn', color: current.color);
      notifyListeners();
      _schedule(speed.extraTurnPause, _maybeBotTurn);
      return;
    }

    extraTurn = false;
    sixStreak = 0; // streak only survives within one player's turn chain
    _advanceSeat();
  }

  /// Third six in a row — the roll does not count and the turn is over.
  /// It is NOT counted as a miss (the player did act, they were just unlucky).
  void _forfeitTurn() {
    if (finished) return;
    _turnEpoch++;
    dice = null;
    movable = [];
    sixStreak = 0;
    extraTurn = false;
    current.misses = 0;
    _advanceSeat();
  }

  void _missTurn() {
    if (finished) return;
    _turnEpoch++; // kill any dice/pawn chain still running for this seat
    final p = current;
    p.misses++;
    sixStreak = 0;
    _sfx(GameSfx.miss);
    dice = null;
    movable = [];
    rolling = false;
    moving = false;
    hopToken = null;
    animatingToken = null;
    _log('${p.name} missed the turn (${p.misses}/3)', color: p.color);
    if (p.misses >= 3) {
      p.eliminated = true;
      _log('${p.name} ELIMINATED (3 misses)', color: p.color);
    }
    _advanceSeat();
  }

  void _advanceSeat() {
    final alive = players.where((p) => p.active).length;
    if (alive <= 1 || players.every((p) => !p.active)) {
      _finish(alive == 1 ? 'Only one player left' : 'Everyone done');
      return;
    }
    var guard = 0;
    do {
      currentIndex = (currentIndex + 1) % players.length;
      guard++;
    } while (!players[currentIndex].active && guard < 16);

    _turnEpoch++;
    _turnRemaining = config.turnSeconds;
    dice = null;
    notifyListeners();

    // pause while the "phone is passed" to the next player
    _schedule(speed.turnHandover, _maybeBotTurn);
  }

  void _maybeBotTurn() {
    if (finished || !started) return;
    if (!current.isBot) return;
    // bot reaches for the dice after a human-like pause
    _schedule(speed.botPickUpDice, () {
      if (current.isBot && dice == null && !rolling && !moving) rollDice();
    });
  }

  // ---------------------------------------------------------------- bot AI

  /// Strong, human-like bot. Evaluates every legal move on a weighted set of
  /// real ludo heuristics instead of just "move the furthest token":
  ///
  ///  1. finishing a token / entering the home column
  ///  2. cutting — valued by how much the victim actually loses
  ///  3. landing safety (star cells, own start, blocks)
  ///  4. THREAT: how likely is the landing cell to be cut next round, weighted
  ///     by the real probability of each opponent rolling the needed number
  ///  5. rescuing its own tokens that are currently in danger
  ///  6. spreading tokens instead of parking them all in one place
  ///  7. mode awareness — rush bots chase points, classic bots race home
  ///  8. a small amount of deliberate imperfection so it feels human
  int _botChoose(Player p, int d, List<int> options) {
    if (options.length == 1) return options.first;

    // Easy bots stay dumb on purpose.
    if (config.botLevel == 1) {
      return options[_rng.nextInt(options.length)];
    }

    final hard = config.botLevel >= 3;
    double bestScore = -1e9;
    var best = options.first;

    // How much danger is each of my tokens in right now (before moving)?
    final dangerNow = <int, double>{};
    for (final t in p.tokens) {
      dangerNow[t.index] = t.onBoard ? _threatAt(p, t.pos) : 0;
    }

    for (final idx in options) {
      final t = p.tokens[idx];
      var s = 0.0;

      // ---- classic: opening a token from the yard ----
      if (!t.open) {
        s += 120; // getting tokens out is strong in classic
        s += (4 - p.tokens.where((x) => x.onBoard).length) * 45;
        if (_wouldCut(p, 0)) s += 200;
        if (s > bestScore) {
          bestScore = s;
          best = idx;
        }
        continue;
      }

      final np = t.pos + d;

      // ---- 1. progress & finishing ----
      if (np == BoardMap.homeStep) {
        s += isRush ? 900 : 1200; // classic: finishing is the whole goal
      } else if (np > BoardMap.lastRingStep) {
        s += 260; // inside the safe home column
        s += (np - BoardMap.lastRingStep) * 14; // deeper is better
      }

      // ---- 2. cutting ----
      final victims = _cutVictims(p, np);
      for (final v in victims) {
        if (isRush) {
          // stealing points is the single best play in rush mode
          s += 320 + v.value * 4.0;
        } else {
          // classic: value cutting by how far back the victim is thrown
          s += 300 + v.value * 3.0;
        }
      }

      // ---- 3. landing safety ----
      // Joining one of my own tokens forms an un-cuttable BLOCK, which is
      // just as safe as a star cell.
      final formsBlock =
          np <= BoardMap.lastRingStep && _myTokensAt(p, np, exclude: idx) >= 1;
      final landsSafe =
          np > BoardMap.lastRingStep ||
          BoardMap.isSafePos(p.color, np) ||
          formsBlock;
      if (landsSafe) {
        s += 130;
      }
      if (formsBlock) s += 90; // blocks are strong: safe AND they wall the lane

      // ---- 4. threat on the landing cell (probability weighted) ----
      if (hard && !landsSafe) {
        final threat = _threatAt(p, np);
        // a loaded token is much more painful to lose
        final atRisk = isRush ? (t.pos + d) : (t.pos + d) * 0.6;
        s -= threat * (60 + atRisk * 1.8);
      }

      // ---- 5. rescuing a token that is currently in danger ----
      final wasDanger = dangerNow[idx] ?? 0;
      if (wasDanger > 0.15) {
        final nowDanger = landsSafe ? 0.0 : _threatAt(p, np);
        if (nowDanger < wasDanger) {
          s += (wasDanger - nowDanger) * (90 + t.pos * 1.4);
        }
      }

      // ---- 6. spread / don't pile all four on one square ----
      if (_myTokensAt(p, np, exclude: idx) >= 3) s -= 55;

      // ---- 7. mode-specific shaping ----
      if (isRush) {
        // in rush, every step is a point, so keep the furthest token rolling
        s += t.pos * 0.55;
        // late in the match, prioritise banking the home bonus
        if (_remainingMatch < 75 && np > BoardMap.lastRingStep) s += 120;
      } else {
        // classic: push the leader home, but never leave a token stranded
        s += t.pos * 0.85;
        if (p.tokensYarded > 0 && d == 6) s -= 30; // prefer opening on a 6
      }

      // slight preference for using a token that is already near home
      if (t.pos > 44) s += 35;

      // ---- 8. human imperfection ----
      // Level 2 bots wobble a lot, level 3 only a little.
      s += _rng.nextDouble() * (hard ? 28 : 95);

      if (s > bestScore) {
        bestScore = s;
        best = idx;
      }
    }
    return best;
  }

  /// Opponent tokens that would be cut by landing on [np], with the value
  /// that would be taken from them.
  List<_Victim> _cutVictims(Player p, int np) {
    final out = <_Victim>[];
    if (np > BoardMap.lastRingStep) return out;
    if (BoardMap.isSafePos(p.color, np)) return out;
    final ring = BoardMap.ringIndexFor(p.color, np);
    if (_cellHasBlock(ring)) return out; // whole cell shielded by a block
    for (final o in players) {
      if (o.id == p.id) continue;
      final onCell = o.tokens
          .where(
            (ot) =>
                ot.onBoard &&
                ot.pos <= BoardMap.lastRingStep &&
                BoardMap.ringIndexFor(o.color, ot.pos) == ring,
          )
          .toList();
      if (onCell.isEmpty) continue;
      out.add(_Victim(o, onCell.first.carried));
    }
    return out;
  }

  /// Number of [p]'s own tokens standing on path position [np], optionally
  /// ignoring the token with index [exclude] (the one that is about to move).
  int _myTokensAt(Player p, int np, {int exclude = -1}) {
    if (np > BoardMap.lastRingStep) return 0;
    final ring = BoardMap.ringIndexFor(p.color, np);
    var n = 0;
    for (final t in p.tokens) {
      if (t.index == exclude) continue;
      if (!t.onBoard || t.pos > BoardMap.lastRingStep) continue;
      if (BoardMap.ringIndexFor(p.color, t.pos) == ring) n++;
    }
    return n;
  }

  /// Probability-ish threat level (0..~1) that a token of [p] sitting on path
  /// position [pos] gets cut on the opponents' next turns. An opponent 1..6
  /// cells behind has a 1/6 chance per die face; being within reach of several
  /// opponent tokens compounds the risk.
  double _threatAt(Player p, int pos) {
    if (pos > BoardMap.lastRingStep) return 0;
    if (BoardMap.isSafePos(p.color, pos)) return 0;
    final myRing = BoardMap.ringIndexFor(p.color, pos);
    // A block of 2+ tokens of ANY colour on this cell shields everyone on it.
    if (_cellHasBlock(myRing)) return 0;
    var safeProb = 1.0;

    for (final o in players) {
      if (o.id == p.id || !o.active) continue;
      for (final ot in o.tokens) {
        if (!ot.onBoard || ot.pos > BoardMap.lastRingStep) continue;
        final oRing = BoardMap.ringIndexFor(o.color, ot.pos);
        var gap = myRing - oRing;
        if (gap < 0) gap += 52;
        if (gap >= 1 && gap <= 6) {
          // that opponent token needs exactly `gap` to reach me
          safeProb *= (1 - 1 / 6);
        }
      }
    }
    return 1 - safeProb;
  }

  // ---------------------------------------------------------------- finish

  void _finish(String reason) {
    if (finished) return;
    finished = true;
    _ticker?.cancel();
    _log('Match over — $reason');
    final rows = results();
    _sfx(rows.isNotEmpty && rows.first.isMe ? GameSfx.win : GameSfx.lose);
    notifyListeners();
  }

  void forceFinish() => _finish('Left the match');

  List<ScoreRow> results() {
    final rows = players
        .map(
          (p) => ScoreRow(
            name: p.name,
            color: p.color,
            score: p.score,
            tokensHome: p.tokensHome,
            isMe: !p.isBot,
            eliminated: p.eliminated,
            character: p.character,
            progress: p.tokens.fold<int>(0, (a, t) => a + t.pos),
          ),
        )
        .toList();
    rows.sort((a, b) {
      if (a.eliminated != b.eliminated) return a.eliminated ? 1 : -1;
      if (isClassic) {
        // classic: most tokens home wins, furthest progress breaks ties
        final h = b.tokensHome.compareTo(a.tokensHome);
        if (h != 0) return h;
        return b.progress.compareTo(a.progress);
      }
      final s = b.score.compareTo(a.score);
      if (s != 0) return s;
      return b.tokensHome.compareTo(a.tokensHome);
    });
    return rows;
  }

  void _log(String text, {PColor? color}) {
    events.add(GameEvent(text, color: color));
    if (events.length > 40) events.removeAt(0);
  }

  static String _fmt(int s) {
    final m = (s ~/ 60).toString().padLeft(2, '0');
    final ss = (s % 60).toString().padLeft(2, '0');
    return '$m:$ss';
  }

  String get clockText => _fmt(_remainingMatch);

  // -------------------------------------------------------------- test hooks
  //
  // The rule engine is deliberately private, but the unit tests need to poke
  // individual rules in isolation (without spinning up timers or animations).
  // These thin, testing-only wrappers keep the production API clean.

  @visibleForTesting
  void forfeitTurnForTest() => _forfeitTurn();

  @visibleForTesting
  List<int> movableForTest(Player p, int d) => _movableTokens(p, d);

  @visibleForTesting
  int botChooseForTest(Player p, int d, List<int> options) =>
      _botChoose(p, d, options);

  @visibleForTesting
  int fairRollForTest() => _fairRoll();

  @visibleForTesting
  bool resolveCutForTest(Player p, Token t) => _resolveCut(p, t);

  @visibleForTesting
  bool isProtectedForTest(Player owner, int pos) => _isProtected(owner, pos);

  @visibleForTesting
  void endTurnForTest({required bool gotSix, required bool cut}) =>
      _endTurn(gotSix: gotSix, cut: cut);

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }
}
