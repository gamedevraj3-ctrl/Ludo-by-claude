import 'package:flutter/material.dart';
import '../core/theme.dart';

/// A cell on the 15x15 ludo grid.
class Cell {
  final double r;
  final double c;
  const Cell(this.r, this.c);
}

/// Complete geometry + path definition of the Rush Ludo board.
///
/// Board is a 15x15 grid.
///  * 4 corner bases (6x6) -> yellow(top-left), blue(top-right),
///    green(bottom-left), red(bottom-right)
///  * 52 cell outer ring
///  * 5 home-column cells + center home for every color
///
/// Path length per token = 57 positions (0..56)
///   0        -> start square (token begins here, already "open")
///   1..50    -> ring travel
///   51..55   -> colored home column (55 is the arrow cell)
///   56       -> HOME (center)  => +56 bonus points
class BoardMap {
  BoardMap._();

  /// 52 ring cells in clockwise order, index 0 = yellow start square.
  static const List<Cell> ring = [
    Cell(6, 1), Cell(6, 2), Cell(6, 3), Cell(6, 4), Cell(6, 5), // 0-4
    Cell(5, 6), Cell(4, 6), Cell(3, 6), Cell(2, 6), Cell(1, 6), // 5-9
    Cell(0, 6), // 10
    Cell(0, 7), // 11
    Cell(0, 8), // 12
    Cell(1, 8), Cell(2, 8), Cell(3, 8), Cell(4, 8), Cell(5, 8), // 13-17
    Cell(6, 9), Cell(6, 10), Cell(6, 11), Cell(6, 12), Cell(6, 13), // 18-22
    Cell(6, 14), // 23
    Cell(7, 14), // 24
    Cell(8, 14), // 25
    Cell(8, 13), Cell(8, 12), Cell(8, 11), Cell(8, 10), Cell(8, 9), // 26-30
    Cell(9, 8), Cell(10, 8), Cell(11, 8), Cell(12, 8), Cell(13, 8), // 31-35
    Cell(14, 8), // 36
    Cell(14, 7), // 37
    Cell(14, 6), // 38
    Cell(13, 6), Cell(12, 6), Cell(11, 6), Cell(10, 6), Cell(9, 6), // 39-43
    Cell(8, 5), Cell(8, 4), Cell(8, 3), Cell(8, 2), Cell(8, 1), // 44-48
    Cell(8, 0), // 49
    Cell(7, 0), // 50
    Cell(6, 0), // 51
  ];

  /// Ring index where each color starts.
  static const Map<PColor, int> startIndex = {
    PColor.yellow: 0,
    PColor.blue: 13,
    PColor.red: 26,
    PColor.green: 39,
  };

  /// Ring indexes that can never be cut (4 starts + 4 stars).
  static const Set<int> safeRingIndexes = {0, 13, 26, 39, 8, 21, 34, 47};

  /// Star marked (grey star) ring indexes.
  static const Set<int> starRingIndexes = {8, 21, 34, 47};

  /// Colored home column cells (5 each, last one is the arrow cell).
  static const Map<PColor, List<Cell>> homeColumn = {
    PColor.yellow: [Cell(7, 1), Cell(7, 2), Cell(7, 3), Cell(7, 4), Cell(7, 5)],
    PColor.blue: [Cell(1, 7), Cell(2, 7), Cell(3, 7), Cell(4, 7), Cell(5, 7)],
    PColor.red: [
      Cell(7, 13),
      Cell(7, 12),
      Cell(7, 11),
      Cell(7, 10),
      Cell(7, 9),
    ],
    PColor.green: [
      Cell(13, 7),
      Cell(12, 7),
      Cell(11, 7),
      Cell(10, 7),
      Cell(9, 7),
    ],
  };

  /// Top-left corner (row,col) of each 6x6 base panel.
  static const Map<PColor, Cell> baseOrigin = {
    PColor.yellow: Cell(0, 0),
    PColor.blue: Cell(0, 9),
    PColor.green: Cell(9, 0),
    PColor.red: Cell(9, 9),
  };

  /// Center home resting cell (slightly offset per color so 4 colors fit).
  static const Map<PColor, Cell> homeCenter = {
    PColor.yellow: Cell(7, 6.55),
    PColor.blue: Cell(6.55, 7),
    PColor.red: Cell(7, 7.45),
    PColor.green: Cell(7.45, 7),
  };

  static const int lastRingStep = 50; // pos 50 == home entry ring cell
  static const int homeStep = 56;

  /// Resting spot (fractional grid cell) of a still-closed token inside its
  /// own base yard — used by classic mode, where a 6 is needed to come out.
  ///
  /// The four slots sit in a row across the free top strip of the 6x6 base
  /// panel so they never collide with the avatar or the score column.
  static Cell yardSlot(PColor color, int slot) {
    final o = baseOrigin[color]!;
    const cols = [0.35, 1.15, 1.95, 2.75];
    return Cell(o.r + 0.6, o.c + cols[slot.clamp(0, 3)]);
  }

  /// Ring index for a token of [color] standing on [pos] (0..50).
  static int ringIndexFor(PColor color, int pos) {
    return (startIndex[color]! + pos) % 52;
  }

  /// Grid cell for a token of [color] at [pos] (0..56).
  static Cell cellFor(PColor color, int pos) {
    if (pos <= lastRingStep) {
      return ring[ringIndexFor(color, pos)];
    }
    if (pos < homeStep) {
      return homeColumn[color]![pos - 51];
    }
    return homeCenter[color]!;
  }

  /// True when a token at [pos] cannot be cut.
  static bool isSafePos(PColor color, int pos) {
    if (pos > lastRingStep) return true;
    return safeRingIndexes.contains(ringIndexFor(color, pos));
  }

  /// Pixel rect of a grid cell for a board of [size] pixels.
  static Rect rectOf(Cell cell, double size) {
    final u = size / 15.0;
    return Rect.fromLTWH(cell.c * u, cell.r * u, u, u);
  }

  /// Pixel center of a grid cell.
  static Offset centerOf(Cell cell, double size) {
    final u = size / 15.0;
    return Offset((cell.c + 0.5) * u, (cell.r + 0.5) * u);
  }
}
