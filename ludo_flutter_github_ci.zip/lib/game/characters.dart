import 'dart:math';

/// One playable character portrait.
///
/// The artwork lives in `assets/characters/<name>.png`. Characters are the only
/// image assets in the whole game — everything else is still drawn with
/// CustomPainter, and nothing here needs the network.
class GameCharacter {
  const GameCharacter(this.name);

  /// Display name, also used as the bot's name so a bot is always called the
  /// same thing as the face it is wearing.
  final String name;

  String get asset => 'assets/characters/$name.png';

  @override
  String toString() => name;
}

/// The full roster shipped with the game.
///
/// Order matters: it is the order the horizontal Characters rail scrolls in,
/// and index 0 is the default pick for a brand-new player.
class Characters {
  Characters._();

  static const List<GameCharacter> all = [
    GameCharacter('A124'),
    GameCharacter('A-Patroa'),
    GameCharacter('Alok'),
    GameCharacter('Alvaro'),
    GameCharacter('Andrew'),
    GameCharacter('Antonio'),
    GameCharacter('Caroline'),
    GameCharacter('Cla'),
    GameCharacter('Clu'),
    GameCharacter('D-Bee'),
    GameCharacter('Dasha'),
    GameCharacter('Dimitri'),
    GameCharacter('Ford'),
    GameCharacter('Hayato'),
    GameCharacter('Homer'),
    GameCharacter('Ignis'),
    GameCharacter('Iris'),
    GameCharacter('Joseph'),
    GameCharacter('Jota'),
    GameCharacter('K'),
    GameCharacter('Kapella'),
    GameCharacter('Kassie'),
    GameCharacter('Kelly'),
    GameCharacter('Kenta'),
    GameCharacter('Kiaros'),
    GameCharacter('Koda'),
    GameCharacter('Laura'),
    GameCharacter('Leon'),
    GameCharacter('Lila'),
    GameCharacter('Luna'),
    GameCharacter('Luqueta'),
    GameCharacter('Maro'),
    GameCharacter('Maxim'),
    GameCharacter('Miguel'),
    GameCharacter('Misha'),
    GameCharacter('Moco'),
    GameCharacter('Morse'),
    GameCharacter('Nairi'),
    GameCharacter('Nero'),
    GameCharacter('Nikita'),
    GameCharacter('Notora'),
    GameCharacter('Olivia'),
    GameCharacter('Orion'),
    GameCharacter('Oscar'),
    GameCharacter('Otho'),
    GameCharacter('Paloma'),
    GameCharacter('Rafel'),
    GameCharacter('Ray'),
    GameCharacter('Rin'),
    GameCharacter('Ryden'),
    GameCharacter('Santino'),
    GameCharacter('Shani'),
    GameCharacter('Shirou'),
    GameCharacter('Skyler'),
    GameCharacter('Soniya'),
    GameCharacter('Steffie'),
    GameCharacter('Suzy'),
    GameCharacter('Tatsuya'),
    GameCharacter('Thiva'),
    GameCharacter('Wolfrah'),
    GameCharacter('Wukong'),
    GameCharacter('Xayne'),
  ];

  static int get count => all.length;

  /// Look a character up by name, falling back to the first one so a corrupt
  /// or outdated saved preference can never crash the app.
  static GameCharacter byName(String? name) {
    if (name == null) return all.first;
    for (final c in all) {
      if (c.name == name) return c;
    }
    return all.first;
  }

  static String assetFor(String? name) => byName(name).asset;

  /// Pick [n] characters for the bots, guaranteed distinct from each other and
  /// from [exclude] (the human's pick), so no two seats ever wear the same
  /// face or carry the same name in a match.
  static List<GameCharacter> pickBots(int n, {String? exclude, Random? rng}) {
    final r = rng ?? Random();
    final pool = all.where((c) => c.name != exclude).toList()..shuffle(r);
    // The roster is far bigger than the 3 bots a match can ever need, but be
    // defensive anyway rather than throwing on a short pool.
    if (n <= pool.length) return pool.take(n).toList();
    final out = <GameCharacter>[];
    while (out.length < n) {
      out.addAll(pool.take(min(pool.length, n - out.length)));
    }
    return out;
  }
}
