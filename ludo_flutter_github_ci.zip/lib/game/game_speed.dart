import 'dart:math';

/// How fast the whole match plays out.
///
/// The engine never hard-codes a delay — every pause goes through
/// [GameSpeed] so the pacing feels like a real person is holding the phone
/// (thinking before a move, dice tumbling, pawn hopping cell by cell).
enum SpeedPreset { relaxed, normal, fast }

extension SpeedPresetX on SpeedPreset {
  String get label {
    switch (this) {
      case SpeedPreset.relaxed:
        return 'Relaxed';
      case SpeedPreset.normal:
        return 'Normal';
      case SpeedPreset.fast:
        return 'Fast';
    }
  }

  String get hint {
    switch (this) {
      case SpeedPreset.relaxed:
        return 'Slow & calm — easiest to follow';
      case SpeedPreset.normal:
        return 'Human-like pace (recommended)';
      case SpeedPreset.fast:
        return 'Quick moves for pros';
    }
  }

  /// Multiplier applied to every duration. Bigger = slower.
  double get factor {
    switch (this) {
      case SpeedPreset.relaxed:
        return 1.45;
      case SpeedPreset.normal:
        return 1.0;
      case SpeedPreset.fast:
        return 0.68;
    }
  }
}

/// Produces the humanized delays used by the engine.
///
/// All base values are tuned so a 4-player match feels unhurried: a pawn
/// takes ~0.26s per cell, a bot "thinks" for 0.9-1.8s before committing,
/// and every action is followed by a small breathing pause.
class GameSpeed {
  GameSpeed({this.preset = SpeedPreset.normal, int? seed})
    : _rng = Random(seed ?? DateTime.now().millisecondsSinceEpoch);

  final SpeedPreset preset;
  final Random _rng;

  double get _f => preset.factor;

  Duration _ms(num v) => Duration(milliseconds: (v * _f).round());

  /// Random jitter so repeated actions never feel machine-perfect.
  int _jitter(int spread) => spread == 0 ? 0 : _rng.nextInt(spread);

  // ------------------------------------------------------------------ dice

  /// Number of face flips shown while the dice tumbles.
  int get diceTumbleFrames => 10 + _jitter(4);

  /// Gap between two tumble frames — starts quick, slows near the end so the
  /// dice looks like it is losing momentum.
  Duration diceTumbleGap(int frame, int total) {
    final t = total <= 1 ? 1.0 : frame / (total - 1);
    // ease-out: 60ms -> 165ms
    final base = 60 + 105 * (t * t);
    return _ms(base);
  }

  /// Pause after the dice settles so the player can read the number.
  Duration get afterDiceSettle => _ms(430 + _jitter(140));

  // ------------------------------------------------------------------ pawn

  /// Time for a pawn to hop one cell. Longer runs speed up slightly, the
  /// last two hops slow down for a satisfying landing.
  Duration pawnHop(int step, int totalSteps) {
    var base = 250.0;
    if (totalSteps >= 5) base = 225.0;
    final remaining = totalSteps - step - 1;
    if (remaining == 1) base += 55;
    if (remaining == 0) base += 110; // final settle
    return _ms(base);
  }

  /// Small pause right before the pawn starts moving (hand reaching out).
  Duration get beforePawnMove => _ms(190 + _jitter(90));

  /// Beat after landing, before the turn is handed over.
  Duration get afterPawnMove => _ms(430 + _jitter(120));

  /// Extra celebration beat when a token reaches HOME (+56).
  Duration get homeCelebration => _ms(760);

  /// Extra beat after a cut so the player sees what happened.
  Duration get cutPause => _ms(880);

  // ------------------------------------------------------------------ turns

  /// A bot "thinking" before it taps the dice.
  Duration get botPickUpDice => _ms(880 + _jitter(620));

  /// A bot deciding which token to move (longer when more options exist).
  Duration botChooseToken(int optionCount) {
    final extra = (optionCount - 1).clamp(0, 3) * 210;
    return _ms(700 + extra + _jitter(480));
  }

  /// Pause shown when a roll produces no legal move.
  Duration get noMovePause => _ms(1000);

  /// Handover pause between two players' turns.
  Duration get turnHandover => _ms(520 + _jitter(180));

  /// Pause before the extra turn (after a 6 or a cut) begins.
  Duration get extraTurnPause => _ms(760);

  /// Auto-move delay when the human has only a single legal option.
  Duration get singleOptionAutoMove => _ms(560 + _jitter(160));

  // ------------------------------------------------------------------ ui

  /// How long a toast/banner stays visible.
  Duration get toastVisible => _ms(1900);

  /// Delay before navigating to the result screen.
  Duration get resultDelay => _ms(1500);
}
