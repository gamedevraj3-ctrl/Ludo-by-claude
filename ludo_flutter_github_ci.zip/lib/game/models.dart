import '../core/theme.dart';
import 'game_speed.dart';

/// Which seat of the board a player owns.
enum Seat { topLeft, topRight, bottomLeft, bottomRight }

extension SeatX on Seat {
  PColor get color {
    switch (this) {
      case Seat.topLeft:
        return PColor.yellow;
      case Seat.topRight:
        return PColor.blue;
      case Seat.bottomLeft:
        return PColor.green;
      case Seat.bottomRight:
        return PColor.red;
    }
  }
}

class Token {
  final int index;
  int pos; // 0..56
  bool finished;

  /// Classic mode only: a token sits in the base yard until a 6 opens it.
  /// In rush mode every token is open from the very first turn.
  bool open;

  Token(this.index, {this.pos = 0, this.finished = false, this.open = true});

  /// Points currently "carried" by this token (lost when cut, and in rush
  /// mode handed over to whoever cut it).
  int get carried => finished ? 0 : pos;

  /// A token that is on the board right now (not yarded, not home).
  bool get onBoard => open && !finished;
}

class Player {
  final int id;
  final String name;
  final PColor color;
  final Seat seat;
  final bool isBot;
  final int avatarSeed;

  /// Which character portrait this seat wears. Every seat in a match gets a
  /// different one, and a bot's [name] is always its character's name.
  final String character;

  /// The human's real profile name. Only set for the local player, so the
  /// match UI can show both "their real name" and the character they picked.
  /// Null for bots and for the other pass-&-play seats.
  final String? realName;

  int score;
  int misses;
  bool eliminated;
  List<Token> tokens;

  /// The number this player actually rolled on their most recent turn.
  ///
  /// Their own dice keeps showing this value while other seats play, instead
  /// of snapping back to a meaningless default 6. `null` only until the very
  /// first roll of the match.
  int? lastDice;

  Player({
    required this.id,
    required this.name,
    required this.color,
    required this.seat,
    required this.isBot,
    required this.avatarSeed,
    required this.character,
    this.realName,
    bool tokensOpen = true,
  }) : score = 0,
       misses = 0,
       eliminated = false,
       lastDice = null,
       tokens = List.generate(4, (i) => Token(i, open: tokensOpen));

  int get livesLeft => (3 - misses).clamp(0, 3);
  int get tokensHome => tokens.where((t) => t.finished).length;
  bool get allHome => tokensHome == 4;
  bool get active => !eliminated && !allHome;

  /// Classic mode: tokens still waiting in the yard for a 6.
  int get tokensYarded => tokens.where((t) => !t.open && !t.finished).length;

  /// What to show on the seat's name plate. Bots just use their character
  /// name; the human shows their real name so they can spot themselves.
  String get displayName => realName ?? name;

  /// Secondary line under the plate: the human's chosen character. Null for
  /// bots, whose name already IS the character name — no point repeating it.
  String? get subName => realName == null ? null : character;
}

enum GameMode { bots, passAndPlay }

/// Which rule set the match uses.
enum MatchMode {
  /// Traditional ludo: a 6 is needed to open a token, no scoring at all,
  /// first player to bring all 4 tokens home wins.
  classic,

  /// Rush ludo: every token starts open, 1 step = 1 point, home = +56,
  /// cutting steals the victim's points. Highest score when time runs out.
  rush,
}

extension MatchModeX on MatchMode {
  String get label => this == MatchMode.classic ? 'Classic Ludo' : 'Rush Ludo';

  String get tagline => this == MatchMode.classic
      ? 'Traditional rules • First to bring all 4 tokens home wins'
      : 'Score race • Steal points by cutting • Highest score wins';

  bool get isClassic => this == MatchMode.classic;
  bool get isRush => this == MatchMode.rush;
}

class GameConfig {
  final GameMode mode;

  /// Rule set: classic ludo or rush (score) ludo.
  final MatchMode matchMode;

  final int playerCount; // 2, 3 or 4
  final int matchSeconds; // total match duration (rush mode only)
  final int turnSeconds; // per turn thinking time
  final String myName;

  /// The character portrait the human picked in the lobby. Bots are assigned
  /// distinct characters around it, so no two seats ever share a face.
  final String myCharacter;

  final int botLevel; // 1 easy .. 3 hard

  /// Overall pacing of the match (dice tumble, pawn hops, bot thinking).
  final SpeedPreset speed;

  const GameConfig({
    required this.mode,
    required this.playerCount,
    this.matchMode = MatchMode.rush,
    this.matchSeconds = 360,
    this.turnSeconds = 15,
    this.myName = 'You',
    this.myCharacter = 'A124',
    this.botLevel = 3,
    this.speed = SpeedPreset.normal,
  });

  /// Classic mode has no match clock — it runs until somebody finishes.
  bool get timed => matchMode.isRush;
}

/// Result row shown on the result screen.
class ScoreRow {
  final String name;
  final PColor color;
  final int score;
  final int tokensHome;
  final bool isMe;
  final bool eliminated;

  /// Which character portrait this seat wore — used by the Booyah victory
  /// screen to show each podium seat's own character PNG on their board
  /// colour, instead of the old procedural avatar.
  final String character;

  /// Total path progress of all 4 tokens — used to break ties in classic mode.
  final int progress;

  const ScoreRow({
    required this.name,
    required this.color,
    required this.score,
    required this.tokensHome,
    required this.isMe,
    required this.eliminated,
    required this.character,
    this.progress = 0,
  });
}
