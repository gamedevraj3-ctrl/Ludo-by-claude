import 'package:flutter/material.dart';

/// Centralised design tokens for the premium arcade lobby.
///
/// Everything here describes the "AAA mobile Ludo" look from the reference
/// design: dark blue/charcoal textures, metallic blue HUD panels, gold/bronze
/// edging, layered bevels, glossy buttons and real dimensional shadows.
/// Deliberately NOT Material 3 — no flat cards, no SaaS surfaces.

/// Flat colour tokens.
class GameColors {
  GameColors._();

  // ---- backdrop: dark blue / charcoal ----
  static const bgTop = Color(0xFF2E3947);
  static const bgMid = Color(0xFF232C38);
  static const bgDeep = Color(0xFF171D26);
  static const bgVoid = Color(0xFF0E131A);

  // ---- metallic blue HUD ----
  static const steelLight = Color(0xFF4E7FB8);
  static const steel = Color(0xFF2F5E96);
  static const steelDark = Color(0xFF1B3A63);
  static const steelDeep = Color(0xFF12283F);

  // ---- gold / bronze edging ----
  static const goldLight = Color(0xFFFBE9A8);
  static const gold = Color(0xFFE0B34A);
  static const goldDeep = Color(0xFFA97B21);
  static const bronze = Color(0xFF7A5516);

  // ---- glossy green action button ----
  static const greenLight = Color(0xFF8CEE6B);
  static const green = Color(0xFF4FC13C);
  static const greenDark = Color(0xFF2A7D25);

  // ---- mode card palettes ----
  static const classicTop = Color(0xFFFFE9A8);
  static const classicBot = Color(0xFFE9B644);
  static const classicInk = Color(0xFF16375F);

  static const rushTop = Color(0xFFF0603F);
  static const rushBot = Color(0xFF9E1B14);
  static const rushInk = Color(0xFFFFE04A);

  // ---- rarity frames for collectible cards ----
  static const rarity = <Color>[
    Color(0xFFE0B34A), // gold
    Color(0xFF9B6BD8), // amethyst
    Color(0xFF4FB6E8), // aqua
    Color(0xFFE0629B), // rose
    Color(0xFF56C071), // jade
    Color(0xFFE05050), // ruby
  ];

  // ---- text ----
  static const ink = Color(0xFF0D1218);
  static const paper = Color(0xFFF6F3EA);
  static const muted = Color(0xFFA9B4C2);

  static const diamond = Color(0xFF5AC8FA);
  static const coin = Color(0xFFFFC93C);
  static const online = Color(0xFF35D07F);
}

/// Reusable gradients — the bevelled, lit look comes almost entirely from here.
class GameGradients {
  GameGradients._();

  /// Whole-screen textured backdrop.
  static const screen = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [GameColors.bgTop, GameColors.bgMid, GameColors.bgDeep],
  );

  /// Metallic blue HUD panel — bright top edge, dark belly.
  static const hud = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      GameColors.steelLight,
      GameColors.steel,
      GameColors.steelDark,
      GameColors.steelDeep,
    ],
    stops: [0.0, 0.30, 0.72, 1.0],
  );

  /// Slightly recessed inner well (currency capsules, rail background).
  static const well = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [GameColors.steelDeep, GameColors.steelDark],
  );

  /// Glossy green PLAY button.
  static const play = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [GameColors.greenLight, GameColors.green, GameColors.greenDark],
    stops: [0.0, 0.52, 1.0],
  );

  /// Dull grey twin of [play] for unselected SELECT buttons.
  static const idleButton = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFFCED3DB), Color(0xFF97A0AD), Color(0xFF6B737F)],
    stops: [0.0, 0.52, 1.0],
  );

  /// Gold rim used as an outer "metal" border via a gradient-filled container.
  static const goldRim = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      GameColors.goldLight,
      GameColors.gold,
      GameColors.goldDeep,
      GameColors.gold,
    ],
    stops: [0.0, 0.35, 0.7, 1.0],
  );

  static const classicCard = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [GameColors.classicTop, GameColors.classicBot],
  );

  static const rushCard = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [GameColors.rushTop, GameColors.rushBot],
  );

  /// Dark plate behind a collectible portrait.
  static const cardWell = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFF33455F), Color(0xFF1B2433)],
  );

  /// Top-light sheen laid over buttons and panels for the glossy read.
  static LinearGradient sheen([double strength = 0.30]) => LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Colors.white.withValues(alpha: strength),
      Colors.white.withValues(alpha: strength * 0.25),
      Colors.transparent,
    ],
    stops: const [0.0, 0.42, 1.0],
  );
}

/// Drop shadows and inner glows that give the UI its depth.
class GameShadows {
  GameShadows._();

  static List<BoxShadow> panel = [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.55),
      blurRadius: 14,
      offset: const Offset(0, 5),
    ),
  ];

  static List<BoxShadow> raised = [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.48),
      blurRadius: 9,
      offset: const Offset(0, 4),
    ),
  ];

  static List<BoxShadow> button = [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.45),
      blurRadius: 6,
      offset: const Offset(0, 3),
    ),
  ];

  /// Coloured halo used for the selected collectible card / active mode.
  static List<BoxShadow> glow(Color c, {double strength = 1.0}) => [
    BoxShadow(
      color: c.withValues(alpha: 0.70 * strength),
      blurRadius: 20 * strength,
      spreadRadius: 1.5 * strength,
    ),
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.40),
      blurRadius: 8,
      offset: const Offset(0, 4),
    ),
  ];
}

/// Border/edging helpers.
class GameBorders {
  GameBorders._();

  static Border gold([double w = 1.8]) =>
      Border.all(color: GameColors.gold, width: w);

  static Border goldSoft([double w = 1.4]) =>
      Border.all(color: GameColors.gold.withValues(alpha: 0.62), width: w);

  /// The bright inner hairline that sells the bevel.
  static Border innerLight([double w = 1.2]) =>
      Border.all(color: Colors.white.withValues(alpha: 0.32), width: w);

  static Border dark([double w = 1.2]) =>
      Border.all(color: Colors.black.withValues(alpha: 0.45), width: w);
}

/// Spacing scale.
class GameSpacing {
  GameSpacing._();
  static const xs = 4.0;
  static const sm = 6.0;
  static const md = 10.0;
  static const lg = 14.0;
  static const xl = 20.0;
  static const xxl = 28.0;
}

/// Corner radius scale.
class GameRadius {
  GameRadius._();
  static const xs = 5.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 22.0;
  static const pill = 999.0;

  static BorderRadius all(double r) => BorderRadius.circular(r);
}

/// Game-style typography: heavy, slightly condensed, always shadowed.
class GameTypography {
  GameTypography._();

  static const _shadow = [
    Shadow(color: Colors.black54, blurRadius: 3, offset: Offset(0, 1.5)),
  ];

  /// Big mode-card title.
  static TextStyle title(double size, Color color) => TextStyle(
    fontSize: size,
    height: 1.02,
    fontWeight: FontWeight.w900,
    color: color,
    letterSpacing: size * 0.02,
    shadows: const [
      Shadow(color: Colors.black45, blurRadius: 4, offset: Offset(0, 2)),
    ],
  );

  /// Section heading ("Select Mode", "Characters").
  static TextStyle heading(double size) => TextStyle(
    fontSize: size,
    fontWeight: FontWeight.w900,
    color: GameColors.paper,
    letterSpacing: size * 0.03,
    shadows: _shadow,
  );

  /// Button face.
  static TextStyle button(double size) => TextStyle(
    fontSize: size,
    fontWeight: FontWeight.w900,
    color: Colors.white,
    letterSpacing: size * 0.08,
    shadows: _shadow,
  );

  /// Player / character name.
  static TextStyle name(double size, {Color color = Colors.white}) => TextStyle(
    fontSize: size,
    fontWeight: FontWeight.w900,
    color: color,
    shadows: _shadow,
  );

  /// Small supporting copy.
  static TextStyle label(double size, {Color color = GameColors.muted}) =>
      TextStyle(fontSize: size, fontWeight: FontWeight.w700, color: color);

  /// Currency counters.
  static TextStyle counter(double size) => TextStyle(
    fontSize: size,
    fontWeight: FontWeight.w900,
    color: Colors.white,
    shadows: _shadow,
  );
}

/// Paths to the bundled lobby artwork (from the user's own design pack).
class GameArt {
  GameArt._();
  static const background = 'assets/ui/lobby_bg.png';
  /// Free-Fire-style military camp backdrop for the rebuilt "hub" lobby
  /// (Part 3 reference re-build — Quonset hangars, watchtower, jeeps).
  static const ffLobbyBackground = 'assets/ui/ff_lobby_bg.jpg';
  static const hudProfile = 'assets/ui/hud_profile.png';
  static const hudCurrency = 'assets/ui/hud_currency.png';
  static const cardFrame = 'assets/ui/card_frame.png';
  static const playButton = 'assets/ui/btn_play.png';
  static const boardClassic = 'assets/ui/board_classic.png';
  static const boardRush = 'assets/ui/board_rush.png';
  static const iconSettings = 'assets/ui/ic_settings.png';
  static const iconVolume = 'assets/ui/ic_volume.png';
  /// Small winged rank-crest icon used by the top-left "VP" rank pill.
  static const rankCrest = 'assets/ui/rank_crest.png';
}
