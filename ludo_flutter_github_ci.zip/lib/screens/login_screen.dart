import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/audio.dart';
import '../core/theme.dart';
import 'lobby_screen.dart';

/// Sign-in screen modelled on the reference art: a wide royal-blue
/// "Sign in with Facebook" bar, an "or" divider with rules either side, and two
/// small light-grey buttons — "Guest" and "More" — sitting below it.
///
/// Only **Guest** actually does anything: the game is 100% offline, so there is
/// no account system to sign into. Facebook and More are deliberately inert —
/// tapping them does nothing at all, exactly as requested.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _in = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 650),
  )..forward();

  bool _leaving = false;

  @override
  void dispose() {
    _in.dispose();
    super.dispose();
  }

  void _continueAsGuest() {
    if (_leaving) return;
    setState(() => _leaving = true);
    Sfx.instance.uiClick();
    HapticFeedback.mediumImpact();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, a, __) =>
            FadeTransition(opacity: a, child: const LobbyScreen()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.screenBg),
        child: Stack(
          children: [
            // blurry blue-grey textured backdrop, like the reference
            const Positioned.fill(
              child: IgnorePointer(
                child: CustomPaint(painter: _LoginBackdrop()),
              ),
            ),
            SafeArea(
              child: LayoutBuilder(
                builder: (context, cts) {
                  // The reference button block is roughly 78% of the screen width.
                  final blockW = min(cts.maxWidth * 0.78, 340.0);
                  return Center(
                    child: FadeTransition(
                      opacity: _in,
                      child: SizedBox(
                        width: blockW,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _brand(blockW),
                            SizedBox(height: blockW * 0.16),
                            _facebookButton(blockW),
                            SizedBox(height: blockW * 0.055),
                            _orDivider(blockW),
                            SizedBox(height: blockW * 0.055),
                            Row(
                              children: [
                                Expanded(
                                  child: _smallButton(
                                    width: blockW,
                                    icon: Icons.person,
                                    label: 'Guest',
                                    onTap: _continueAsGuest,
                                  ),
                                ),
                                SizedBox(width: blockW * 0.04),
                                Expanded(
                                  child: _smallButton(
                                    width: blockW,
                                    icon: Icons.more_horiz,
                                    label: 'More',
                                    // Deliberately dead — offline game.
                                    onTap: null,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- brand

  Widget _brand(double w) => Column(
    children: [
      Text(
        'LUDO RUSH',
        style: TextStyle(
          fontSize: w * 0.14,
          fontWeight: FontWeight.w900,
          color: Colors.white,
          letterSpacing: w * 0.006,
          shadows: [
            Shadow(
              color: AppColors.gold.withValues(alpha: 0.55),
              blurRadius: w * 0.07,
            ),
            const Shadow(color: Colors.black54, blurRadius: 6),
          ],
        ),
      ),
    ],
  );

  // ------------------------------------------------------- facebook button

  /// Wide royal-blue bar with the round white "f" badge on the left.
  /// Inert on purpose — there is nothing online to sign in to.
  Widget _facebookButton(double w) {
    final h = w * 0.148;
    return Opacity(
      // Slightly dimmed so it reads as unavailable without looking broken.
      opacity: 0.92,
      child: SizedBox(
        height: h,
        child: Material(
          color: const Color(0xFF1877F2),
          borderRadius: BorderRadius.circular(w * 0.018),
          child: InkWell(
            // Deliberately does nothing functionally, but still gives the
            // same menu click feedback as every other lobby-family button.
            onTap: Sfx.instance.uiClick,
            borderRadius: BorderRadius.circular(w * 0.018),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: h * 0.28),
              child: Row(
                children: [
                  // round white badge with a blue "f"
                  Container(
                    width: h * 0.56,
                    height: h * 0.56,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      'f',
                      style: TextStyle(
                        fontSize: h * 0.44,
                        height: 1.0,
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF1877F2),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'Sign in with Facebook',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: h * 0.34,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(width: h * 0.56),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ----------------------------------------------------------- or divider

  Widget _orDivider(double w) => Row(
    children: [
      Expanded(
        child: Container(
          height: 1,
          color: Colors.white.withValues(alpha: 0.45),
        ),
      ),
      Padding(
        padding: EdgeInsets.symmetric(horizontal: w * 0.035),
        child: Text(
          'or',
          style: TextStyle(
            fontSize: w * 0.042,
            fontWeight: FontWeight.w700,
            color: Colors.white.withValues(alpha: 0.85),
          ),
        ),
      ),
      Expanded(
        child: Container(
          height: 1,
          color: Colors.white.withValues(alpha: 0.45),
        ),
      ),
    ],
  );

  // --------------------------------------------------------- small buttons

  /// The light-grey Guest / More pair. [onTap] is null for the inert one.
  Widget _smallButton({
    required double width,
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
  }) {
    final h = width * 0.125;
    final enabled = onTap != null;
    return SizedBox(
      height: h,
      child: Material(
        color: enabled
            ? const Color(0xFFE4E6EB)
            : const Color(0xFFE4E6EB).withValues(alpha: 0.72),
        borderRadius: BorderRadius.circular(h * 0.20),
        child: InkWell(
          // Tapping "More" does nothing structurally, but still shows a
          // ripple + the standard menu click so it never feels broken.
          onTap: onTap ?? Sfx.instance.uiClick,
          borderRadius: BorderRadius.circular(h * 0.20),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(h * 0.20),
              border: Border.all(
                color: const Color(0xFF8A8D93).withValues(alpha: 0.55),
              ),
              // A soft gold ring marks the one button that actually works.
              boxShadow: enabled
                  ? [
                      BoxShadow(
                        color: AppColors.gold.withValues(alpha: 0.45),
                        blurRadius: h * 0.32,
                      ),
                    ]
                  : null,
            ),
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: h * 0.46, color: const Color(0xFF3A3D42)),
                SizedBox(width: h * 0.16),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: h * 0.36,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF3A3D42),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Blurry blue-grey texture behind the sign-in block.
class _LoginBackdrop extends CustomPainter {
  const _LoginBackdrop();

  @override
  void paint(Canvas canvas, Size size) {
    final r = Offset.zero & size;
    canvas.drawRect(
      r,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF2C3E57), Color(0xFF1C2436), Color(0xFF141A28)],
        ).createShader(r),
    );

    // soft out-of-focus light pools
    final pools = <(Color, double, double, double)>[
      (const Color(0xFF6FA8DC), 0.22, 0.20, 0.46),
      (const Color(0xFF8A4DFF), 0.82, 0.30, 0.40),
      (const Color(0xFF2BE08A), 0.30, 0.82, 0.34),
      (const Color(0xFFFFC93C), 0.78, 0.86, 0.30),
    ];
    for (final (c, fx, fy, fr) in pools) {
      final ctr = Offset(size.width * fx, size.height * fy);
      final rad = size.shortestSide * fr;
      canvas.drawCircle(
        ctr,
        rad,
        Paint()
          ..shader = RadialGradient(
            colors: [c.withValues(alpha: 0.30), c.withValues(alpha: 0.0)],
          ).createShader(Rect.fromCircle(center: ctr, radius: rad)),
      );
    }

    // faint diagonal grain
    final grain = Paint()
      ..color = Colors.white.withValues(alpha: 0.028)
      ..strokeWidth = 1.2;
    for (double x = -size.height; x < size.width; x += 16) {
      canvas.drawLine(
        Offset(x, size.height),
        Offset(x + size.height, 0),
        grain,
      );
    }

    // darken the edges so the buttons pop
    canvas.drawRect(
      r,
      Paint()
        ..shader = RadialGradient(
          colors: [Colors.transparent, Colors.black.withValues(alpha: 0.55)],
          stops: const [0.55, 1.0],
        ).createShader(r),
    );
  }

  @override
  bool shouldRepaint(covariant _LoginBackdrop oldDelegate) => false;
}
