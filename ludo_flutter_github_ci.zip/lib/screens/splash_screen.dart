import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import 'login_screen.dart';

/// Landscape "RESOURCE LOADING, PLEASE WAIT" boot screen, modelled on the
/// reference art the user supplied: a wide band of abstract game artwork with a
/// thin full-width yellow→orange progress bar pinned near the bottom and the
/// uppercase status caption sitting just above it.
///
/// This screen — and only this screen — is forced into landscape; the rest of
/// the game stays portrait, so the orientation is restored on the way out.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  /// Drives the slowly drifting nebula behind the bar.
  late final AnimationController _drift = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 12),
  )..repeat();

  /// Drives the bright flare that rides the right-hand tip of the fill.
  late final AnimationController _flare = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  double _progress = 0;

  @override
  void initState() {
    super.initState();
    // Landscape for the boot screen only (matches the reference image).
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _load();
  }

  Future<void> _load() async {
    // A chunky, "real installer" style fill instead of a smooth continuous
    // crawl (which reads as stutter/lag): quickly climb to a checkpoint,
    // pause there for a visible beat, then jump again — e.g. snap to ~10%,
    // hold, jump to ~50%, hold, etc. Each checkpoint's climb is still eased
    // over a few frames (not a single instant teleport) so it reads as a
    // quick, deliberate fill rather than a glitch. Total run time stays
    // ~10 seconds, matching the previous version.
    const segments = <(double target, int climbMs, int holdMs)>[
      (0.10, 300, 900),
      (0.25, 380, 850),
      (0.50, 520, 1500),
      (0.65, 380, 850),
      (0.80, 420, 900),
      (0.92, 380, 750),
      (1.00, 320, 500),
    ];

    // A brief initial pause at 0% — like the app is still reading its first
    // batch of assets — before the first quick jump.
    await Future<void>.delayed(const Duration(milliseconds: 1050));
    if (!mounted) return;

    for (final (target, climbMs, holdMs) in segments) {
      const subSteps = 6;
      final start = _progress;
      final stepMs = (climbMs / subSteps).round().clamp(4, climbMs);
      for (var i = 1; i <= subSteps; i++) {
        await Future<void>.delayed(Duration(milliseconds: stepMs));
        if (!mounted) return;
        final eased = Curves.easeOut.transform(i / subSteps);
        setState(() => _progress = start + (target - start) * eased);
      }
      // Land exactly on the checkpoint, then hold there for a beat.
      setState(() => _progress = target);
      await Future<void>.delayed(Duration(milliseconds: holdMs));
      if (!mounted) return;
    }

    // Loading, login and the lobby all stay in landscape; only the match
    // itself flips back to portrait (see GameScreen).
    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, a, __) =>
            FadeTransition(opacity: a, child: const LoginScreen()),
      ),
    );
  }

  @override
  void dispose() {
    _drift.dispose();
    _flare.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(
        builder: (context, cts) {
          final w = cts.maxWidth;
          final h = cts.maxHeight;
          // On a phone this screen is locked to landscape, so the height is the
          // short side and everything can be scaled off it. On the web preview
          // (and on tablets) the window may still be portrait, so clamp against
          // the width too — otherwise the title grows absurdly large.
          final s = min(h, w * 0.56);
          // Bar geometry copied from the reference: full-bleed, thin, low.
          final barH = max(4.0, s * 0.016);
          final barBottom = s * 0.085;
          final capFont = max(9.5, s * 0.046);

          return Stack(
            children: [
              // --- abstract game artwork band (procedural, zero assets) ---
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: _drift,
                  builder: (_, __) =>
                      CustomPaint(painter: _ArtworkPainter(_drift.value)),
                ),
              ),

              // --- the dark mask over the upper part, as in the reference ---
              Positioned(
                left: 0,
                right: 0,
                top: 0,
                height: h * 0.56,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black,
                          Colors.black.withValues(alpha: 0.92),
                          Colors.black.withValues(alpha: 0.0),
                        ],
                        stops: const [0.0, 0.62, 1.0],
                      ),
                    ),
                  ),
                ),
              ),

              // --- game title, sitting in the dark band ---
              Positioned(
                left: w * 0.10,
                right: w * 0.10,
                top: h * 0.17,
                child: Column(
                  children: [
                    // FittedBox guarantees the wordmark always fits on one line,
                    // whatever the window shape is (phone landscape, tablet, or
                    // the portrait web preview).
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        'LUDO RUSH',
                        maxLines: 1,
                        style: TextStyle(
                          fontSize: s * 0.145,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: s * 0.012,
                          height: 1.0,
                          shadows: [
                            Shadow(
                              color: AppColors.gold.withValues(alpha: 0.65),
                              blurRadius: s * 0.05,
                            ),
                            const Shadow(color: Colors.black, blurRadius: 6),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // --- caption directly above the bar ---
              Positioned(
                left: w * 0.06,
                right: w * 0.06,
                bottom: barBottom + barH + s * 0.028,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    'RESOURCE LOADING, PLEASE WAIT',
                    maxLines: 1,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: capFont,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: capFont * 0.16,
                      shadows: const [
                        Shadow(color: Colors.black, blurRadius: 7),
                        Shadow(color: Colors.black54, blurRadius: 14),
                      ],
                    ),
                  ),
                ),
              ),

              // --- the full-width progress bar ---
              Positioned(
                left: 0,
                right: 0,
                bottom: barBottom,
                height: barH,
                child: AnimatedBuilder(
                  animation: _flare,
                  builder: (_, __) => CustomPaint(
                    painter: _LoadingBarPainter(
                      progress: _progress,
                      flare: _flare.value,
                    ),
                  ),
                ),
              ),

              // --- percentage on the right, under the bar ---
              Positioned(
                right: w * 0.03,
                bottom: barBottom - s * 0.062,
                child: Text(
                  '${(_progress * 100).round()}%',
                  style: TextStyle(
                    fontSize: s * 0.042,
                    fontWeight: FontWeight.w900,
                    color: AppColors.gold,
                    letterSpacing: 0.5,
                    shadows: const [Shadow(color: Colors.black, blurRadius: 6)],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Abstract green / purple / blue "gaming artwork" behind the loading bar,
/// painted entirely with gradients and blurred blobs so the app still ships
/// with zero image assets.
class _ArtworkPainter extends CustomPainter {
  _ArtworkPainter(this.t);
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final r = Offset.zero & size;

    // base wash
    canvas.drawRect(
      r,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF10203A), Color(0xFF1B1040), Color(0xFF07131F)],
        ).createShader(r),
    );

    // drifting colour blobs
    final blobs = <(Color, double, double, double)>[
      (const Color(0xFF2BE08A), 0.16, 0.74, 0.42), // green
      (const Color(0xFF8A4DFF), 0.52, 0.86, 0.50), // purple
      (const Color(0xFF2F9CF0), 0.84, 0.70, 0.44), // blue
      (const Color(0xFFFF7A3D), 0.68, 0.96, 0.28), // warm accent
      (const Color(0xFF19C6C6), 0.34, 0.94, 0.30), // teal
    ];

    for (var i = 0; i < blobs.length; i++) {
      final (c, fx, fy, fr) = blobs[i];
      final phase = t * 2 * pi + i * 1.27;
      final cx = size.width * (fx + 0.035 * sin(phase));
      final cy = size.height * (fy + 0.030 * cos(phase * 0.8));
      final rad = size.height * fr * (1 + 0.07 * sin(phase * 1.3));
      canvas.drawCircle(
        Offset(cx, cy),
        rad,
        Paint()
          ..shader = RadialGradient(
            colors: [c.withValues(alpha: 0.62), c.withValues(alpha: 0.0)],
          ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: rad)),
      );
    }

    // a few light streaks for that "concept art" feel
    final streak = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < 5; i++) {
      final y = size.height * (0.58 + i * 0.085);
      final p = Path()
        ..moveTo(-size.width * 0.1, y)
        ..lineTo(size.width * 1.1, y - size.height * 0.10)
        ..lineTo(size.width * 1.1, y - size.height * 0.075)
        ..lineTo(-size.width * 0.1, y + size.height * 0.025)
        ..close();
      canvas.drawPath(
        p,
        streak
          ..shader = LinearGradient(
            colors: [
              Colors.white.withValues(alpha: 0.0),
              Colors.white.withValues(alpha: 0.055),
              Colors.white.withValues(alpha: 0.0),
            ],
          ).createShader(r),
      );
    }

    // vignette so the caption always stays readable
    canvas.drawRect(
      r,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.transparent, Colors.black.withValues(alpha: 0.55)],
          stops: const [0.55, 1.0],
        ).createShader(r),
    );
  }

  @override
  bool shouldRepaint(covariant _ArtworkPainter old) => old.t != t;
}

/// The thin full-width bar: dark track, yellow→orange fill and a bright
/// vertical flare riding the leading edge, exactly like the reference.
class _LoadingBarPainter extends CustomPainter {
  _LoadingBarPainter({required this.progress, required this.flare});
  final double progress;
  final double flare;

  @override
  void paint(Canvas canvas, Size size) {
    final h = size.height;
    final track = Rect.fromLTWH(0, 0, size.width, h);

    // dark track with a subtle top highlight
    canvas.drawRect(
      track,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF241C11).withValues(alpha: 0.96),
            const Color(0xFF0C0A06).withValues(alpha: 0.96),
          ],
        ).createShader(track),
    );

    final w = (size.width * progress.clamp(0.0, 1.0));
    if (w > 0.5) {
      final fill = Rect.fromLTWH(0, 0, w, h);
      canvas.drawRect(
        fill,
        Paint()
          ..shader = const LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [Color(0xFFB86A00), Color(0xFFFFA61E), Color(0xFFFFE04A)],
          ).createShader(fill),
      );

      // glossy top half
      canvas.drawRect(
        Rect.fromLTWH(0, 0, w, h * 0.45),
        Paint()..color = Colors.white.withValues(alpha: 0.22),
      );

      // bright flare at the leading tip
      final glowW = h * 2.6;
      final gRect = Rect.fromLTWH(w - glowW, -h * 0.6, glowW, h * 2.2);
      canvas.drawRect(
        gRect,
        Paint()
          ..shader = LinearGradient(
            colors: [
              const Color(0xFFFFE04A).withValues(alpha: 0.0),
              const Color(0xFFFFF7B0).withValues(alpha: 0.55 + 0.35 * flare),
            ],
          ).createShader(gRect),
      );
      canvas.drawRect(
        Rect.fromLTWH(w - h * 0.16, -h * 0.35, h * 0.16, h * 1.7),
        Paint()..color = Colors.white.withValues(alpha: 0.75 + 0.25 * flare),
      );
    }

    // hairline borders top & bottom
    final line = Paint()
      ..color = const Color(0xFFFFC93C).withValues(alpha: 0.55)
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, 0.5), Offset(size.width, 0.5), line);
    canvas.drawLine(Offset(0, h - 0.5), Offset(size.width, h - 0.5), line);
  }

  @override
  bool shouldRepaint(covariant _LoadingBarPainter old) =>
      old.progress != progress || old.flare != flare;
}
