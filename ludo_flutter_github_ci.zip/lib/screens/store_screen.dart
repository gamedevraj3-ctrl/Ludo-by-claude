import 'package:flutter/material.dart';

import '../core/audio.dart';
import '../core/game_theme.dart';
import '../widgets/game_ui.dart';

/// ---------------------------------------------------------------------------
/// Update #2 (item 3) — Store screen shell matching the reference `Store.png`
/// layout: top category tabs, a scrollable left-hand item list with "HOT"
/// tags and BUY buttons, and a big featured banner on the right (landscape)
/// / top (portrait).
///
/// Per the user's explicit instruction, this is a SHELL ONLY — "store me
/// konse items add honge wo abhi usme mat dikhao" — so every row is a
/// placeholder ("Coming Soon") with disabled buttons rather than real
/// purchasable content. The whole visual frame (tabs, banner, list rows) is
/// fully built and ready for real items to be wired in later.
/// ---------------------------------------------------------------------------
class StoreScreen extends StatefulWidget {
  const StoreScreen({super.key});

  @override
  State<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends State<StoreScreen> {
  int _tab = 0;
  static const _tabs = ['Featured', 'Characters', 'Boards', 'Bundles', 'Other'];

  void _back() {
    Sfx.instance.uiClick();
    Navigator.of(context).pop();
  }

  void _selectTab(int i) {
    Sfx.instance.uiClick();
    setState(() => _tab = i);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GameColors.bgVoid,
      body: DecoratedBox(
        decoration: const BoxDecoration(gradient: GameGradients.screen),
        child: Stack(
          children: [
            const Positioned.fill(
              child: IgnorePointer(
                child: RepaintBoundary(
                  child: CustomPaint(painter: TexturePainter()),
                ),
              ),
            ),
            SafeArea(
              child: LayoutBuilder(
                builder: (context, cts) {
                  final landscape = cts.maxWidth > cts.maxHeight;
                  final scale = (cts.maxHeight / 460.0).clamp(0.6, 1.4);
                  return Column(
                    children: [
                      _topBar(scale),
                      _tabBar(scale),
                      SizedBox(height: 8 * scale),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12 * scale),
                          child: landscape
                              ? Row(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Expanded(flex: 6, child: _itemList(scale)),
                                    SizedBox(width: 12 * scale),
                                    Expanded(flex: 5, child: _banner(scale)),
                                  ],
                                )
                              : Column(
                                  children: [
                                    SizedBox(
                                      height: cts.maxHeight * 0.28,
                                      child: _banner(scale),
                                    ),
                                    SizedBox(height: 10 * scale),
                                    Expanded(child: _itemList(scale)),
                                  ],
                                ),
                        ),
                      ),
                      SizedBox(height: 10 * scale),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _topBar(double scale) {
    return Padding(
      padding: EdgeInsets.fromLTRB(10 * scale, 8 * scale, 10 * scale, 4 * scale),
      child: Row(
        children: [
          MetalIconButton(icon: Icons.arrow_back, size: 34 * scale, onTap: _back),
          Expanded(
            child: Center(
              child: Text('STORE', style: GameTypography.heading(16 * scale)),
            ),
          ),
          CurrencyCounter(
            icon: Icons.attach_money,
            iconColor: GameColors.coin,
            value: '0',
            height: 30 * scale,
          ),
          SizedBox(width: 8 * scale),
          CurrencyCounter(
            icon: Icons.diamond,
            iconColor: GameColors.diamond,
            value: '0',
            height: 30 * scale,
          ),
        ],
      ),
    );
  }

  Widget _tabBar(double scale) {
    return SizedBox(
      height: 34 * scale,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 12 * scale),
        itemCount: _tabs.length,
        separatorBuilder: (_, __) => SizedBox(width: 8 * scale),
        itemBuilder: (_, i) {
          final sel = i == _tab;
          return GestureDetector(
            onTap: () => _selectTab(i),
            behavior: HitTestBehavior.opaque,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              padding: EdgeInsets.symmetric(horizontal: 16 * scale),
              decoration: BoxDecoration(
                gradient: sel ? GameGradients.goldRim : null,
                color: sel ? null : Colors.black.withValues(alpha: 0.28),
                borderRadius: GameRadius.all(GameRadius.pill),
                border: Border.all(
                  color: sel ? GameColors.gold : Colors.white24,
                  width: sel ? 1.4 : 1,
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                _tabs[i],
                style: TextStyle(
                  fontSize: 12 * scale,
                  fontWeight: FontWeight.w800,
                  color: sel ? GameColors.ink : Colors.white70,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  /// Featured banner — placeholder art + copy, matches the big legendary
  /// bundle panel from the reference, wired for a real promo later.
  Widget _banner(double scale) {
    return MetalPanel(
      radius: GameRadius.lg * scale,
      rimWidth: 2.2 * scale,
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF3B2E77), Color(0xFF201748), Color(0xFF120C2E)],
      ),
      padding: EdgeInsets.all(14 * scale),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.auto_awesome,
            size: 40 * scale,
            color: GameColors.gold,
          ),
          SizedBox(height: 10 * scale),
          Text(
            'LIMITED TIME OFFERS',
            textAlign: TextAlign.center,
            style: GameTypography.title(15 * scale, GameColors.goldLight),
          ),
          SizedBox(height: 6 * scale),
          Text(
            'Coming soon',
            textAlign: TextAlign.center,
            style: GameTypography.label(11 * scale, color: Colors.white60),
          ),
        ],
      ),
    );
  }

  /// Scrollable row list — HOT tags on the first couple of rows to match the
  /// reference read, but every row is a locked placeholder for now.
  Widget _itemList(double scale) {
    return MetalPanel(
      radius: GameRadius.md * scale,
      rimWidth: 1.6 * scale,
      gradient: GameGradients.well,
      showSheen: false,
      padding: EdgeInsets.all(6 * scale),
      child: ListView.separated(
        physics: const BouncingScrollPhysics(),
        itemCount: 8,
        separatorBuilder: (_, __) => SizedBox(height: 8 * scale),
        itemBuilder: (_, i) => _StoreRow(scale: scale, hot: i < 2),
      ),
    );
  }
}

class _StoreRow extends StatelessWidget {
  const _StoreRow({required this.scale, required this.hot});
  final double scale;
  final bool hot;

  @override
  Widget build(BuildContext context) {
    final radius = GameRadius.sm * scale;
    return Container(
      padding: EdgeInsets.all(8 * scale),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.30),
        borderRadius: GameRadius.all(radius),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 46 * scale,
                height: 46 * scale,
                decoration: BoxDecoration(
                  gradient: GameGradients.cardWell,
                  borderRadius: GameRadius.all(radius * 0.8),
                  border: Border.all(color: Colors.white24),
                ),
                child: Icon(
                  Icons.lock_outline,
                  size: 20 * scale,
                  color: Colors.white38,
                ),
              ),
              if (hot)
                Positioned(
                  left: -4 * scale,
                  top: -6 * scale,
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 5 * scale,
                      vertical: 1 * scale,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE0342E),
                      borderRadius: GameRadius.all(GameRadius.xs * scale),
                      border: Border.all(color: Colors.white70, width: 0.8),
                    ),
                    child: Text(
                      'HOT',
                      style: TextStyle(
                        fontSize: 8 * scale,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(width: 10 * scale),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Coming Soon',
                  style: GameTypography.name(12.5 * scale),
                ),
                SizedBox(height: 2 * scale),
                Text(
                  'New items on the way',
                  style: GameTypography.label(9.5 * scale),
                ),
              ],
            ),
          ),
          SizedBox(width: 8 * scale),
          GlossyButton(
            label: 'SOON',
            height: 26 * scale,
            fontSize: 10 * scale,
            gradient: GameGradients.idleButton,
            enabled: false,
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
