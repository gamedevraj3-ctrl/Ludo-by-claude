import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/theme.dart';
import '../widgets/lobby_components.dart';
import '../widgets/game_ui.dart';
import '../widgets/character_card_panel.dart';
import '../core/game_theme.dart';
import '../game/game_speed.dart';
import '../game/characters.dart' as roster;
import '../game/models.dart';
import 'characters_screen.dart';
import 'game_screen.dart';
import 'store_screen.dart';

/// ---------------------------------------------------------------------------
/// Update #2 (items 3 & 5) — the lobby was rebuilt from scratch to match the
/// Free-Fire-style reference (`extra2.jpeg`): a full-bleed cyberpunk cityscape
/// backdrop, a top nav row with CHARACTERS / STORE shortcuts, a big centred
/// "player card" showing the currently selected character (reusing the exact
/// same [CharacterCardPanel] widget the victory screen uses — item 6), and a
/// glowing START action bottom-left — all re-themed for Ludo (mode picker +
/// bots/pass-and-play toggle still live here, just restyled to fit the new
/// look).
/// ---------------------------------------------------------------------------
class LobbyScreen extends StatefulWidget {
  const LobbyScreen({super.key});

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  String _name = 'You';
  MatchMode _matchMode = MatchMode.rush;
  GameMode _gameMode = GameMode.bots;
  bool _sound = true;

  /// The character the player is wearing. Persisted, so it survives restarts.
  String _character = roster.Characters.all.first.name;

  late final AnimationController _shine;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _lockLandscape();
    _shine = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..repeat();
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _shine.dispose();
    super.dispose();
  }

  /// The lobby is landscape-first, matching the loading and login screens
  /// (and the Free-Fire reference art itself, which is a landscape scene).
  /// The match itself switches to portrait when it opens, so every time the
  /// lobby becomes visible again it must re-assert its own orientation.
  void _lockLandscape() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _lockLandscape();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _name = p.getString('name') ?? 'You';
      _sound = p.getBool('sound_on') ?? true;
      _character = roster.Characters.byName(p.getString('character')).name;
      final mi = p.getInt('match_mode');
      if (mi != null && mi >= 0 && mi < MatchMode.values.length) {
        _matchMode = MatchMode.values[mi];
      }
    });
  }

  Future<void> _saveName(String v) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('name', v);
    if (!mounted) return;
    setState(() => _name = v);
  }

  Future<void> _pickMode(MatchMode m) async {
    Sfx.instance.uiClick();
    setState(() => _matchMode = m);
    final p = await SharedPreferences.getInstance();
    await p.setInt('match_mode', m.index);
  }

  Future<void> _toggleSound() async {
    await Sfx.instance.toggle();
    if (!mounted) return;
    setState(() => _sound = Sfx.instance.enabled);
    if (_sound) Sfx.instance.uiClick();
  }

  void _pickGameMode(GameMode m) {
    Sfx.instance.uiClick();
    setState(() => _gameMode = m);
  }

  Future<void> _openCharacters() async {
    Sfx.instance.uiClick();
    final picked = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => CharactersScreen(selected: _character)),
    );
    _lockLandscape();
    if (picked != null && mounted) setState(() => _character = picked);
  }

  void _openStore() {
    Sfx.instance.uiClick();
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const StoreScreen()))
        .then((_) => _lockLandscape());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GameColors.bgVoid,
      body: Stack(
        children: [
          // 1) Free-Fire-style cyberpunk cityscape backdrop, full-bleed.
          Positioned.fill(
            child: Image.asset(
              GameArt.ffLobbyBackground,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const DecoratedBox(
                decoration: BoxDecoration(gradient: GameGradients.screen),
              ),
            ),
          ),
          // 2) darkening scrim so the UI stays readable over the art.
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.32),
                      Colors.black.withValues(alpha: 0.18),
                      Colors.black.withValues(alpha: 0.55),
                    ],
                    stops: const [0.0, 0.45, 1.0],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                final landscape = w > h;
                final u = landscape ? h / 460.0 : w / 460.0;
                final scale = u.clamp(0.55, 1.6);

                return Column(
                  children: [
                    _topNav(scale),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(
                          14 * scale,
                          4 * scale,
                          14 * scale,
                          6 * scale,
                        ),
                        child: landscape
                            ? _landscapeBody(scale)
                            : _portraitBody(scale),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // -------------------------------------------------------------- top nav

  /// Menu / inbox-style icon row on the left, CHARACTERS + STORE pill
  /// shortcuts on the right — matching the Free-Fire reference's top bar.
  Widget _topNav(double scale) {
    return Padding(
      padding: EdgeInsets.fromLTRB(10 * scale, 8 * scale, 10 * scale, 0),
      child: Row(
        children: [
          MetalIconButton(
            icon: Icons.settings,
            size: 32 * scale,
            onTap: _openSettings,
          ),
          SizedBox(width: 6 * scale),
          MetalIconButton(
            icon: _sound ? Icons.volume_up : Icons.volume_off,
            size: 32 * scale,
            onTap: _toggleSound,
          ),
          const Spacer(),
          _navPill(
            label: 'CHARACTERS',
            icon: Icons.groups_2_rounded,
            scale: scale,
            onTap: _openCharacters,
          ),
          SizedBox(width: 8 * scale),
          _navPill(
            label: 'STORE',
            icon: Icons.storefront_rounded,
            scale: scale,
            onTap: _openStore,
          ),
        ],
      ),
    );
  }

  Widget _navPill({
    required String label,
    required IconData icon,
    required double scale,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 12 * scale,
          vertical: 7 * scale,
        ),
        decoration: BoxDecoration(
          gradient: GameGradients.goldRim,
          borderRadius: GameRadius.all(GameRadius.pill),
          boxShadow: GameShadows.raised,
        ),
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: 10 * scale,
            vertical: 4 * scale,
          ),
          decoration: BoxDecoration(
            gradient: GameGradients.hud,
            borderRadius: GameRadius.all(GameRadius.pill),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 14 * scale, color: GameColors.goldLight),
              SizedBox(width: 5 * scale),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11 * scale,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.6,
                  color: Colors.white,
                ),
              ),
              SizedBox(width: 3 * scale),
              Icon(
                Icons.keyboard_arrow_down_rounded,
                size: 14 * scale,
                color: Colors.white70,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // -------------------------------------------------------------- layouts

  /// Landscape (primary) layout: mode + start on the left, the big centred
  /// player/character card filling the right — matching the reference's
  /// "hero portrait in the middle of the cityscape" composition.
  Widget _landscapeBody(double scale) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          flex: 5,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              _quickModeRow(scale),
              SizedBox(height: 8 * scale),
              GameModeToggle(
                selected: _gameMode,
                scale: scale,
                onSelect: _pickGameMode,
              ),
              SizedBox(height: 10 * scale),
              _startButton(scale),
            ],
          ),
        ),
        SizedBox(width: 14 * scale),
        Expanded(
          flex: 4,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [_playerCard(scale)],
          ),
        ),
      ],
    );
  }

  Widget _portraitBody(double scale) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(flex: 5, child: Center(child: _playerCard(scale))),
        SizedBox(height: 10 * scale),
        _quickModeRow(scale),
        SizedBox(height: 8 * scale),
        GameModeToggle(
          selected: _gameMode,
          scale: scale,
          onSelect: _pickGameMode,
        ),
        SizedBox(height: 10 * scale),
        _startButton(scale),
      ],
    );
  }

  /// The Free-Fire-style "player card" — the exact same bordered, coloured,
  /// corner-bolded square panel used by the victory screen's podium cards
  /// (item 6's own clarification), here showing the currently selected
  /// character front and centre, tappable to jump straight to Characters.
  Widget _playerCard(double scale) {
    final color = ShowcasePalette.forName(_character);
    return GestureDetector(
      onTap: _openCharacters,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CharacterCardPanel(
            character: _character,
            color: color,
            width: 150 * scale,
            aspectRatio: 0.76,
            glow: color,
            fallbackSeed: _character.codeUnits.fold(0, (a, b) => a + b),
          ),
          SizedBox(height: 8 * scale),
          GestureDetector(
            onTap: _editName,
            behavior: HitTestBehavior.opaque,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "'$_name'",
                  style: GameTypography.name(14 * scale),
                ),
                SizedBox(width: 4 * scale),
                Icon(Icons.edit, size: 12 * scale, color: Colors.white60),
              ],
            ),
          ),
          SizedBox(height: 2 * scale),
          Text(
            _character,
            style: GameTypography.label(11 * scale, color: GameColors.goldLight),
          ),
          SizedBox(height: 2 * scale),
          Text(
            'Tap to change character',
            style: GameTypography.label(9 * scale),
          ),
        ],
      ),
    );
  }

  /// Compact CLASSIC / RUSH toggle — the reference's own "mode" concept,
  /// slimmed down so the hero player card gets most of the screen.
  Widget _quickModeRow(double scale) {
    return Row(
      children: MatchMode.values.map((m) {
        final sel = _matchMode == m;
        return Expanded(
          child: GestureDetector(
            onTap: () => _pickMode(m),
            behavior: HitTestBehavior.opaque,
            child: Container(
              margin: EdgeInsets.only(
                right: m == MatchMode.values.first ? 8 * scale : 0,
              ),
              padding: EdgeInsets.symmetric(vertical: 10 * scale),
              decoration: BoxDecoration(
                gradient: sel ? GameGradients.goldRim : null,
                color: sel ? null : Colors.black.withValues(alpha: 0.34),
                borderRadius: GameRadius.all(GameRadius.md * scale),
                border: Border.all(
                  color: sel ? GameColors.gold : Colors.white24,
                  width: sel ? 1.6 : 1,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    m.label.toUpperCase(),
                    style: TextStyle(
                      fontSize: 12.5 * scale,
                      fontWeight: FontWeight.w900,
                      color: sel ? GameColors.ink : Colors.white,
                    ),
                  ),
                  Text(
                    m.tagline,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 8.5 * scale,
                      fontWeight: FontWeight.w700,
                      color: sel
                          ? GameColors.ink.withValues(alpha: 0.75)
                          : Colors.white60,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  /// The glowing orange "START" action from the reference, bottom-left.
  Widget _startButton(double scale) {
    return SizedBox(
      height: 46 * scale,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: GameRadius.all(GameRadius.lg * scale),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF8A3D).withValues(alpha: 0.65),
              blurRadius: 18 * scale,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: GameRadius.all(GameRadius.lg * scale),
            onTap: () {
              Sfx.instance.uiClick();
              _openSetup(_gameMode);
            },
            child: Ink(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFFC15C), Color(0xFFFF7A1F), Color(0xFFE0501A)],
                  stops: [0.0, 0.55, 1.0],
                ),
                borderRadius: GameRadius.all(GameRadius.lg * scale),
                border: Border.all(color: Colors.white54, width: 1.2),
              ),
              child: Center(
                child: Text(
                  'START',
                  style: TextStyle(
                    fontSize: 17 * scale,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                    color: Colors.white,
                    shadows: const [
                      Shadow(color: Colors.black45, blurRadius: 4, offset: Offset(0, 2)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ flows

  void _openSettings() {
    Sfx.instance.uiClick();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _LobbySettingsSheet(
        onEditName: () {
          Navigator.pop(context);
          _editName();
        },
      ),
    );
  }

  void _editName() {
    Sfx.instance.uiClick();
    final ctrl = TextEditingController(text: _name);
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.panelDark,
        title: const Text('Your Name', style: AppText.h2),
        content: TextField(
          controller: ctrl,
          maxLength: 14,
          style: AppText.body,
          decoration: const InputDecoration(hintText: 'Enter name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final v = ctrl.text.trim();
              if (v.isNotEmpty) _saveName(v);
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _openSetup(GameMode mode) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _SetupSheet(
        mode: mode,
        matchMode: _matchMode,
        myName: _name,
        onStart: _start,
      ),
    );
  }

  void _start(GameConfig cfg) {
    Navigator.of(context)
        .push(
          MaterialPageRoute(
            builder: (_) => GameScreen(
              config: GameConfig(
                mode: cfg.mode,
                matchMode: cfg.matchMode,
                playerCount: cfg.playerCount,
                matchSeconds: cfg.matchSeconds,
                turnSeconds: cfg.turnSeconds,
                myName: _name,
                myCharacter: _character,
                botLevel: cfg.botLevel,
                speed: cfg.speed,
              ),
            ),
          ),
        )
        .then((_) {
          // The match locks portrait while it's playing; re-assert landscape
          // now that we're back so the lobby never gets stuck in portrait.
          _lockLandscape();
          _load();
        });
  }
}

/// Lobby settings sheet: sound effects toggle and a name shortcut. Deliberately
/// has NO "Rules" entry — rules live only inside an active match's own
/// settings sheet.
class _LobbySettingsSheet extends StatefulWidget {
  const _LobbySettingsSheet({required this.onEditName});

  final VoidCallback onEditName;

  @override
  State<_LobbySettingsSheet> createState() => _LobbySettingsSheetState();
}

class _LobbySettingsSheetState extends State<_LobbySettingsSheet> {
  @override
  Widget build(BuildContext context) {
    final on = Sfx.instance.enabled;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 46,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text('Settings', style: AppText.h2),
            const SizedBox(height: 12),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: on,
              activeThumbColor: AppColors.online,
              secondary: Icon(
                on ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                color: on ? AppColors.online : Colors.white38,
              ),
              title: const Text('Sound effects', style: AppText.body),
              subtitle: Text(
                on ? 'Dice, hops, cuts & fanfare' : 'Muted',
                style: AppText.small,
              ),
              onChanged: (v) async {
                await Sfx.instance.setEnabled(v);
                if (!mounted) return;
                setState(() {});
                if (v) Sfx.instance.uiClick();
              },
            ),
            const Divider(color: Colors.white12, height: 1),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.badge_outlined, color: Colors.white70),
              title: const Text('Edit name', style: AppText.body),
              trailing: const Icon(Icons.chevron_right, color: Colors.white38),
              onTap: widget.onEditName,
            ),
          ],
        ),
      ),
    );
  }
}

/// Bottom sheet to pick rule set / players / duration / difficulty.
class _SetupSheet extends StatefulWidget {
  const _SetupSheet({
    required this.mode,
    required this.matchMode,
    required this.myName,
    required this.onStart,
  });

  final GameMode mode;
  final MatchMode matchMode;
  final String myName;
  final void Function(GameConfig) onStart;

  @override
  State<_SetupSheet> createState() => _SetupSheetState();
}

class _SetupSheetState extends State<_SetupSheet> {
  late MatchMode _match;
  int _players = 4;
  int _minutes = 4;
  bool _customTime = false;
  double _customMinutes = 8;
  int _turnSec = 15;
  int _level = 3;
  SpeedPreset _speed = SpeedPreset.normal;

  @override
  void initState() {
    super.initState();
    _match = widget.matchMode;
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    final i = p.getInt('speed');
    setState(() {
      if (i != null && i >= 0 && i < SpeedPreset.values.length) {
        _speed = SpeedPreset.values[i];
      }
      _players = (p.getInt('last_players') ?? 4).clamp(2, 4);
      _level = (p.getInt('last_level') ?? 3).clamp(1, 3);
    });
  }

  Future<void> _saveSpeed(SpeedPreset s) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('speed', s.index);
  }

  Future<void> _remember() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('last_players', _players);
    await p.setInt('last_level', _level);
    await p.setInt('match_mode', _match.index);
  }

  int get _finalMinutes => _customTime ? _customMinutes.round() : _minutes;

  @override
  Widget build(BuildContext context) {
    final isBots = widget.mode == GameMode.bots;
    final rush = _match.isRush;

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 46,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Icon(
                    isBots ? Icons.smart_toy : Icons.groups,
                    size: 20,
                    color: AppColors.glow,
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      isBots ? 'Play with Bots' : 'Pass & Play with Friends',
                      style: AppText.h2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // ------------------------------------------------- rule set
              _labelRow('Rule set'),
              const SizedBox(height: 8),
              Row(
                children: MatchMode.values.map((m) {
                  final sel = _match == m;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Sfx.instance.uiClick();
                        setState(() => _match = m);
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        decoration: BoxDecoration(
                          gradient: sel ? AppColors.purplePill : null,
                          color: sel
                              ? null
                              : Colors.black.withValues(alpha: 0.26),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: sel ? AppColors.glow : Colors.white12,
                            width: sel ? 1.6 : 1,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            m.label,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: sel ? Colors.white : Colors.white60,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 6),
              Text(_match.tagline, style: AppText.small),
              const SizedBox(height: 14),

              // -------------------------------------------------- players
              _chips(
                'Players',
                const [2, 3, 4],
                _players,
                (v) => setState(() => _players = v),
                suffix: '',
              ),
              const SizedBox(height: 14),

              // ----------------------------------------------- match time
              if (rush) ...[
                Row(
                  children: [
                    Expanded(child: _labelRow('Match time')),
                    GestureDetector(
                      onTap: () {
                        Sfx.instance.uiClick();
                        setState(() => _customTime = !_customTime);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: _customTime
                              ? AppColors.accentDeep
                              : Colors.black.withValues(alpha: 0.30),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: _customTime
                                ? AppColors.glow
                                : Colors.white24,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              _customTime
                                  ? Icons.tune_rounded
                                  : Icons.tune_outlined,
                              size: 13,
                              color: _customTime
                                  ? Colors.white
                                  : Colors.white54,
                            ),
                            const SizedBox(width: 5),
                            Text(
                              'Custom',
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w800,
                                color: _customTime
                                    ? Colors.white
                                    : Colors.white54,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                if (!_customTime)
                  Row(
                    children: const [4, 6].map((v) {
                      final sel = v == _minutes;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () {
                            Sfx.instance.uiClick();
                            setState(() => _minutes = v);
                          },
                          child: Container(
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(vertical: 11),
                            decoration: BoxDecoration(
                              gradient: sel ? AppColors.purplePill : null,
                              color: sel
                                  ? null
                                  : Colors.black.withValues(alpha: 0.26),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: sel ? AppColors.glow : Colors.white12,
                                width: sel ? 1.6 : 1,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                '$v min',
                                style: TextStyle(
                                  fontSize: 13.5,
                                  fontWeight: FontWeight.w800,
                                  color: sel ? Colors.white : Colors.white60,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  )
                else
                  _customTimeSlider(),
                const SizedBox(height: 14),
              ],

              // ----------------------------------------------- turn timer
              _chips(
                'Turn timer',
                const [10, 15, 20],
                _turnSec,
                (v) => setState(() => _turnSec = v),
                suffix: ' sec',
              ),
              const SizedBox(height: 14),

              // ---------------------------------------------- game speed
              _labelRow('Game speed'),
              const SizedBox(height: 8),
              Row(
                children: SpeedPreset.values.map((sp) {
                  final sel = _speed == sp;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Sfx.instance.uiClick();
                        setState(() => _speed = sp);
                        _saveSpeed(sp);
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        decoration: BoxDecoration(
                          gradient: sel ? AppColors.purplePill : null,
                          color: sel
                              ? null
                              : Colors.black.withValues(alpha: 0.26),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: sel ? AppColors.glow : Colors.white12,
                            width: sel ? 1.6 : 1,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            sp.label,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: sel ? Colors.white : Colors.white60,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 6),
              Text(_speed.hint, style: AppText.small),

              // ------------------------------------------ bot difficulty
              if (isBots) ...[
                const SizedBox(height: 14),
                _labelRow('Bot skill'),
                const SizedBox(height: 8),
                Row(
                  children: List.generate(3, (i) {
                    const names = ['Casual', 'Sharp', 'Pro'];
                    final lv = i + 1;
                    final sel = _level == lv;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Sfx.instance.uiClick();
                          setState(() => _level = lv);
                        },
                        child: Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(vertical: 11),
                          decoration: BoxDecoration(
                            gradient: sel ? AppColors.purplePill : null,
                            color: sel
                                ? null
                                : Colors.black.withValues(alpha: 0.26),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: sel ? AppColors.glow : Colors.white12,
                              width: sel ? 1.6 : 1,
                            ),
                          ),
                          child: Center(
                            child: Text(
                              names[i],
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: sel ? Colors.white : Colors.white60,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ],

              const SizedBox(height: 20),
              SizedBox(
                height: 52,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.accentDeep,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: () {
                    Sfx.instance.uiClick();
                    _remember();
                    Navigator.pop(context);
                    widget.onStart(
                      GameConfig(
                        mode: widget.mode,
                        matchMode: _match,
                        playerCount: _players,
                        matchSeconds: _finalMinutes * 60,
                        turnSeconds: _turnSec,
                        myName: widget.myName,
                        botLevel: _level,
                        speed: _speed,
                      ),
                    );
                  },
                  child: Text(
                    rush
                        ? 'START $_finalMinutes-MIN RUSH'
                        : 'START CLASSIC MATCH',
                    style: const TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Free-form match length picker (1 - 30 minutes).
  Widget _customTimeSlider() {
    final m = _customMinutes.round();
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.28),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.glow.withValues(alpha: 0.45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.timer_outlined, size: 15, color: AppColors.gold),
              const SizedBox(width: 7),
              Text(
                '$m minute${m == 1 ? '' : 's'}',
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
              const Spacer(),
              Text(
                m <= 3
                    ? 'Blitz'
                    : m <= 6
                    ? 'Quick'
                    : m <= 12
                    ? 'Standard'
                    : 'Marathon',
                style: const TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                  color: AppColors.gold,
                ),
              ),
            ],
          ),
          SliderTheme(
            data: SliderThemeData(
              trackHeight: 5,
              activeTrackColor: AppColors.glow,
              inactiveTrackColor: Colors.white12,
              thumbColor: Colors.white,
              overlayColor: AppColors.glow.withValues(alpha: 0.18),
              valueIndicatorColor: AppColors.accentDeep,
            ),
            child: Slider(
              value: _customMinutes,
              min: 1,
              max: 30,
              divisions: 29,
              label: '$m min',
              onChanged: (v) => setState(() => _customMinutes = v),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 2, bottom: 4),
            child: Text(
              'Drag to set any length from 1 to 30 minutes',
              style: AppText.small,
            ),
          ),
        ],
      ),
    );
  }

  Widget _labelRow(String text) => Text(text, style: AppText.small);

  Widget _chips(
    String label,
    List<int> values,
    int selected,
    ValueChanged<int> onSel, {
    required String suffix,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _labelRow(label),
        const SizedBox(height: 8),
        Row(
          children: values.map((v) {
            final sel = v == selected;
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  Sfx.instance.uiClick();
                  onSel(v);
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(
                    gradient: sel ? AppColors.purplePill : null,
                    color: sel ? null : Colors.black.withValues(alpha: 0.26),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: sel ? AppColors.glow : Colors.white12,
                      width: sel ? 1.6 : 1,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      '$v$suffix',
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: sel ? Colors.white : Colors.white60,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}
