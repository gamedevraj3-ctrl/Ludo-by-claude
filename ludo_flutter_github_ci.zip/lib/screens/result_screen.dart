import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/theme.dart';
import '../game/models.dart';
import '../widgets/character_card_panel.dart';
import '../widgets/character_motion.dart';
import 'game_screen.dart';

/// ---------------------------------------------------------------------------
/// Update #2 (item 2) — the victory screen was COMPLETELY discarded and
/// rebuilt from scratch to match the user's reference image:
///   • a giant diagonal 3D "BOOYAH!" wordmark
///   • a golden "MVP" label + glow halo directly over the winner
///   • every podium finisher shown as a bordered player/character card
///     (see `CharacterCardPanel`, item 6) tinted in THEIR OWN board colour,
///     cascading in a staircase behind the winner
///   • each card's score printed on it, per the reference
///
/// The screen is now portrait (matching both the reference screenshot and
/// the match itself, which is already portrait) instead of the old
/// landscape layout.
/// ---------------------------------------------------------------------------
class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key, required this.rows, required this.config});

  final List<ScoreRow> rows;
  final GameConfig config;

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _confetti = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 6),
  );
  late final AnimationController _entrance = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );
  late final AnimationController _glow = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat(reverse: true);

  @override
  void initState() {
    super.initState();
    // Portrait, matching the match itself and the reference screenshot —
    // the old landscape "results dashboard" layout is gone entirely.
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    _persist();
    _entrance.forward();
    // Win/lose fanfare is already fired by the engine itself right before it
    // navigates here (see LudoEngine._finish) — no need to play it again.
    if (widget.rows.first.isMe) _confetti.repeat();
  }

  @override
  void dispose() {
    _confetti.dispose();
    _entrance.dispose();
    _glow.dispose();
    super.dispose();
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    final me = widget.rows.firstWhere(
      (r) => r.isMe,
      orElse: () => widget.rows.first,
    );
    final winner = widget.rows.first;
    final best = p.getInt('best') ?? 0;
    if (widget.config.matchMode.isRush && me.score > best) {
      await p.setInt('best', me.score);
    }
    await p.setInt('played', (p.getInt('played') ?? 0) + 1);
    if (winner.isMe) {
      await p.setInt('won', (p.getInt('won') ?? 0) + 1);
      if (widget.config.matchMode.isClassic) {
        await p.setInt('classic_wins', (p.getInt('classic_wins') ?? 0) + 1);
      }
    }
  }

  // Victory/MVP screen is a menu screen, not the live board — Update #2
  // item 8 says it gets the Free-Fire-style menu click, not the gameplay tap.
  void _tap() => Sfx.instance.uiClick();

  @override
  Widget build(BuildContext context) {
    final winner = widget.rows.first;
    final iWon = winner.isMe;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF4B2E9E),
              Color(0xFF351D7A),
              Color(0xFF1D1050),
            ],
          ),
        ),
        child: Stack(
          children: [
            // light rays + stone podium backdrop
            const Positioned.fill(
              child: IgnorePointer(child: CustomPaint(painter: _RaysPainter())),
            ),
            if (iWon)
              Positioned.fill(
                child: IgnorePointer(
                  child: AnimatedBuilder(
                    animation: _confetti,
                    builder: (_, __) =>
                        CustomPaint(painter: _ConfettiPainter(_confetti.value)),
                  ),
                ),
              ),
            SafeArea(
              child: LayoutBuilder(
                builder: (context, cts) {
                  final w = cts.maxWidth;
                  final h = cts.maxHeight;
                  // Scale unit off a 390x760 reference portrait canvas.
                  final s = min(w / 390.0, h / 760.0).clamp(0.62, 1.35);

                  return FadeTransition(
                    opacity: CurvedAnimation(
                      parent: _entrance,
                      curve: Curves.easeOut,
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: 10 * s),
                        _statusPill(iWon, s),
                        Expanded(
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              // giant diagonal BOOYAH wordmark, upper-right —
                              // constrained to a fixed-width box and scaled
                              // to fit so it can never clip off the screen
                              // edge regardless of text metrics/rotation.
                              Positioned(
                                right: 6 * s,
                                top: h * 0.02,
                                width: w * 0.60,
                                child: FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: Alignment.centerRight,
                                  child: _BoxyahMark(scale: s, celebrate: iWon),
                                ),
                              ),
                              // cascading podium cards
                              Positioned.fill(
                                child: _Podium(
                                  rows: widget.rows,
                                  scale: s,
                                  glow: _glow,
                                ),
                              ),
                            ],
                          ),
                        ),
                        _subtitle(winner, iWon, s),
                        SizedBox(height: 10 * s),
                        _actions(s),
                        SizedBox(height: 14 * s),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusPill(bool iWon, double s) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20 * s, vertical: 6 * s),
      decoration: BoxDecoration(
        gradient: AppColors.purplePill,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppColors.stroke, width: 1.4),
      ),
      child: Text(
        iWon ? 'VICTORY' : 'MATCH OVER',
        style: TextStyle(
          fontSize: 12 * s,
          fontWeight: FontWeight.w900,
          letterSpacing: 2.0,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _subtitle(ScoreRow winner, bool iWon, double s) {
    final text = widget.config.matchMode.isClassic
        ? (iWon
              ? 'You brought all ${winner.tokensHome} tokens home first!'
              : '${winner.name} got their tokens home first')
        : (iWon
              ? 'Highest score — ${winner.score} points!'
              : '${winner.name} scored highest with ${winner.score} pts');
    return Text(
      text,
      textAlign: TextAlign.center,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
      style: AppText.small.copyWith(fontSize: 12.5 * s, color: Colors.white70),
    );
  }

  Widget _actions(double s) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20 * s),
      child: Row(
        children: [
          Expanded(
            child: SizedBox(
              height: 46 * s,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.white54, width: 1.6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                onPressed: () {
                  _tap();
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                      builder: (_) => GameScreen(config: widget.config),
                    ),
                  );
                },
                child: Text(
                  'PLAY AGAIN',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 12.5 * s,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(width: 12 * s),
          Expanded(
            flex: 2,
            child: SizedBox(
              height: 46 * s,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF2F8CE0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                onPressed: () {
                  _tap();
                  Navigator.of(context).pop();
                },
                child: Text(
                  'CONTINUE',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 13.5 * s,
                    letterSpacing: 0.6,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// The staircase of player cards: winner (MVP) largest and frontmost/centred,
/// 2nd tucked behind-right, 3rd behind-left, 4th further behind-right of 2nd —
/// exactly the formation described in the update notes.
class _Podium extends StatelessWidget {
  const _Podium({required this.rows, required this.scale, required this.glow});

  final List<ScoreRow> rows;
  final double scale;
  final Animation<double> glow;

  @override
  Widget build(BuildContext context) {
    final s = scale;
    // Base card width for the winner; others scale down from it.
    final baseW = 118.0 * s;

    // (dx offset from centre, dy offset from centre, width factor, z-order)
    const layout = <(double, double, double, int)>[
      (0.0, 0.06, 1.0, 3), // rank 1 — MVP, centred, frontmost
      (0.62, -0.10, 0.72, 2), // rank 2 — behind-right
      (-0.60, -0.02, 0.68, 1), // rank 3 — behind-left
      (1.05, -0.26, 0.56, 0), // rank 4 — further behind-right of rank 2
    ];

    final cards = <Widget>[];
    for (var i = 0; i < rows.length && i < 4; i++) {
      final r = rows[i];
      final (dx, dy, wf, z) = layout[i];
      final cardW = baseW * wf;
      final isWinner = i == 0;

      cards.add(
        _PodiumCard(
          key: ValueKey('podium_${r.name}_$i'),
          row: r,
          rank: i + 1,
          width: cardW,
          dx: dx * baseW * 1.35,
          dy: dy * baseW * 1.35,
          zOrder: z,
          isWinner: isWinner,
          glow: glow,
        ),
      );
    }

    // Sort by z-order so higher z paints on top (winner always frontmost).
    cards.sort((a, b) {
      final az = (a as _PodiumCard).zOrder;
      final bz = (b as _PodiumCard).zOrder;
      return az.compareTo(bz);
    });

    return Stack(alignment: Alignment.center, children: cards);
  }
}

class _PodiumCard extends StatelessWidget {
  const _PodiumCard({
    super.key,
    required this.row,
    required this.rank,
    required this.width,
    required this.dx,
    required this.dy,
    required this.zOrder,
    required this.isWinner,
    required this.glow,
  });

  final ScoreRow row;
  final int rank;
  final double width;
  final double dx;
  final double dy;
  final int zOrder;
  final bool isWinner;
  final Animation<double> glow;

  @override
  Widget build(BuildContext context) {
    final card = CharacterCardPanel(
      character: row.character,
      color: row.color.main,
      name: row.name,
      width: width,
      aspectRatio: 0.72,
      dark: isWinner,
      glow: isWinner ? AppColors.gold : null,
      characterWidthFactor: 1.02,
    );

    final scoreChip = Container(
      margin: EdgeInsets.only(top: width * 0.045),
      padding: EdgeInsets.symmetric(
        horizontal: width * 0.14,
        vertical: width * 0.045,
      ),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.45),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppColors.gold.withValues(alpha: 0.7)),
      ),
      child: Text(
        '${row.score} pts',
        style: TextStyle(
          color: AppColors.gold,
          fontWeight: FontWeight.w900,
          fontSize: width * 0.12,
        ),
      ),
    );

    Widget content = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (isWinner)
          AnimatedBuilder(
            animation: glow,
            builder: (_, __) => _MvpHalo(size: width * 1.55, pulse: glow.value),
          ),
        card,
        scoreChip,
      ],
    );

    if (isWinner) {
      // Overlap the halo behind the card by stacking instead of a column gap.
      content = SizedBox(
        width: width * 1.55,
        child: Stack(
          alignment: Alignment.topCenter,
          clipBehavior: Clip.none,
          children: [
            AnimatedBuilder(
              animation: glow,
              builder: (_, __) =>
                  _MvpHalo(size: width * 1.55, pulse: glow.value),
            ),
            Padding(
              padding: EdgeInsets.only(top: width * 0.30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [card, scoreChip],
              ),
            ),
            Positioned(
              top: 0,
              child: _MvpLabel(scale: width / 118.0),
            ),
          ],
        ),
      );
    }

    // PNG character animation: 4th/3rd/2nd place run in one after another from
    // the sides, then the winner pops in last with rays + sparkles (MVP).
    final delayMs = isWinner
        ? 950
        : (rank == 3 ? 150 : (rank == 2 ? 450 : 700));
    final side = rank == 3 ? -1 : (rank == 1 ? 0 : 1);

    return Transform.translate(
      offset: Offset(dx, dy),
      child: CharacterMotion(
        style: isWinner
            ? CharacterMotionStyle.mvp
            : CharacterMotionStyle.arrival,
        delay: Duration(milliseconds: delayMs),
        fromSide: side,
        accent: isWinner ? AppColors.gold : row.color.main,
        child: Opacity(opacity: isWinner ? 1.0 : 0.94, child: content),
      ),
    );
  }
}

/// Golden pulsing halo directly behind/around the winner's portrait.
class _MvpHalo extends StatelessWidget {
  const _MvpHalo({required this.size, required this.pulse});
  final double size;
  final double pulse;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              AppColors.gold.withValues(alpha: 0.42 + 0.16 * pulse),
              AppColors.gold.withValues(alpha: 0.0),
            ],
            stops: const [0.15, 1.0],
          ),
        ),
      ),
    );
  }
}

/// "MVP" label sitting directly above the winner, per the reference image:
/// a bold gold fill with a dark stroke behind it for a stickered, 3D look.
class _MvpLabel extends StatelessWidget {
  const _MvpLabel({required this.scale});
  final double scale;

  @override
  Widget build(BuildContext context) {
    final fs = 22.0 * scale;
    return Stack(
      alignment: Alignment.center,
      children: [
        Text(
          'MVP',
          style: TextStyle(
            fontSize: fs,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = fs * 0.09
              ..color = const Color(0xFF7A4B00),
          ),
        ),
        Text(
          'MVP',
          style: TextStyle(
            fontSize: fs,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            color: AppColors.gold,
            shadows: const [
              Shadow(color: Colors.black54, blurRadius: 4, offset: Offset(0, 1.5)),
            ],
          ),
        ),
      ],
    );
  }
}

/// The giant diagonal 3D "BOOYAH!" wordmark from the reference image: thick
/// black outline, gold/yellow gradient fill, drop shadow, slight rotation and
/// a soft sparkle animation when the local player actually won.
class _BoxyahMark extends StatefulWidget {
  const _BoxyahMark({required this.scale, required this.celebrate});
  final double scale;
  final bool celebrate;

  @override
  State<_BoxyahMark> createState() => _BoxyahMarkState();
}

class _BoxyahMarkState extends State<_BoxyahMark>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.scale;
    return Transform.rotate(
      angle: -0.32,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          final wob = widget.celebrate ? sin(_c.value * pi) * 0.015 : 0.0;
          return Transform.scale(
            scale: 1.0 + wob,
            child: _stackedText('BOOYAH!', 58 * s),
          );
        },
      ),
    );
  }

  Widget _stackedText(String text, double fontSize) {
    final style = TextStyle(
      fontSize: fontSize,
      fontWeight: FontWeight.w900,
      letterSpacing: 1,
      height: 1.0,
    );
    return Stack(
      children: [
        // deep drop shadow copies
        for (final o in const [Offset(5, 6), Offset(3, 4)])
          Transform.translate(
            offset: o,
            child: Text(
              text,
              style: style.copyWith(color: Colors.black.withValues(alpha: 0.55)),
            ),
          ),
        // thick black outline
        Text(
          text,
          style: style.copyWith(
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = fontSize * 0.11
              ..color = Colors.black,
          ),
        ),
        // gold gradient fill
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFFF3B0),
              Color(0xFFFFC93C),
              Color(0xFFE08A1E),
            ],
            stops: [0.0, 0.5, 1.0],
          ).createShader(bounds),
          child: Text(text, style: style.copyWith(color: Colors.white)),
        ),
      ],
    );
  }
}

/// Purple backdrop light rays + a faint stone-podium silhouette, evoking the
/// reference image's dark rock stage without needing a bitmap asset.
class _RaysPainter extends CustomPainter {
  const _RaysPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.5, size.height * 0.32);
    final rayPaint = Paint()..style = PaintingStyle.fill;
    const rayCount = 14;
    for (var i = 0; i < rayCount; i++) {
      final a0 = (2 * pi / rayCount) * i;
      final a1 = a0 + (pi / rayCount) * 0.6;
      final len = size.longestSide * 0.9;
      final p = Path()
        ..moveTo(center.dx, center.dy)
        ..lineTo(
          center.dx + cos(a0) * len,
          center.dy + sin(a0) * len,
        )
        ..lineTo(
          center.dx + cos(a1) * len,
          center.dy + sin(a1) * len,
        )
        ..close();
      rayPaint.color = Colors.white.withValues(alpha: i.isEven ? 0.035 : 0.015);
      canvas.drawPath(p, rayPaint);
    }

    // stone podium block, bottom-left — subtle, mostly hidden behind cards
    final podium = Path()
      ..moveTo(0, size.height * 0.62)
      ..lineTo(size.width * 0.30, size.height * 0.58)
      ..lineTo(size.width * 0.30, size.height * 1.05)
      ..lineTo(0, size.height * 1.05)
      ..close();
    canvas.drawPath(
      podium,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF6B5A46).withValues(alpha: 0.28),
            const Color(0xFF2E2416).withValues(alpha: 0.10),
          ],
        ).createShader(Offset.zero & size),
    );

    // vignette
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 1.0,
          colors: [Colors.transparent, Colors.black.withValues(alpha: 0.35)],
          stops: const [0.6, 1.0],
        ).createShader(Offset.zero & size),
    );
  }

  @override
  bool shouldRepaint(covariant _RaysPainter oldDelegate) => false;
}

/// Lightweight procedural confetti — no packages, no assets.
class _ConfettiPainter extends CustomPainter {
  _ConfettiPainter(this.t);

  /// 0..1 loop progress.
  final double t;

  static const int _count = 70;
  static final Random _rnd = Random(7);
  static final List<_Fleck> _flecks = List.generate(
    _count,
    (i) => _Fleck(
      x: _rnd.nextDouble(),
      phase: _rnd.nextDouble(),
      speed: 0.55 + _rnd.nextDouble() * 0.85,
      sway: 0.012 + _rnd.nextDouble() * 0.045,
      swaySpeed: 1.5 + _rnd.nextDouble() * 3.5,
      size: 4.0 + _rnd.nextDouble() * 6.0,
      spin: _rnd.nextDouble() * 6.0 - 3.0,
      color: _palette[i % _palette.length],
      round: _rnd.nextBool(),
    ),
  );

  static const List<Color> _palette = [
    Color(0xFFFFD447), // gold
    Color(0xFFFF5A6E), // red
    Color(0xFF4CE06B), // green
    Color(0xFF4FA8FF), // blue
    Color(0xFFB78CFF), // purple
    Colors.white,
  ];

  @override
  void paint(Canvas canvas, Size size) {
    for (final f in _flecks) {
      // vertical fall, wrapping around
      final prog = (t * f.speed + f.phase) % 1.0;
      final y = prog * (size.height + 60) - 30;
      final x =
          f.x * size.width +
          sin((prog * f.swaySpeed + f.phase) * 2 * pi) * size.width * f.sway;

      // fade out near the bottom
      final fade = prog > 0.85 ? (1 - prog) / 0.15 : 1.0;
      final paint = Paint()..color = f.color.withValues(alpha: 0.85 * fade);

      canvas.save();
      canvas.translate(x, y);
      canvas.rotate((prog * f.spin) * 2 * pi);
      if (f.round) {
        canvas.drawCircle(Offset.zero, f.size * 0.42, paint);
      } else {
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(
              center: Offset.zero,
              width: f.size,
              height: f.size * 0.55,
            ),
            Radius.circular(f.size * 0.16),
          ),
          paint,
        );
      }
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _ConfettiPainter old) => old.t != t;
}

class _Fleck {
  const _Fleck({
    required this.x,
    required this.phase,
    required this.speed,
    required this.sway,
    required this.swaySpeed,
    required this.size,
    required this.spin,
    required this.color,
    required this.round,
  });

  final double x;
  final double phase;
  final double speed;
  final double sway;
  final double swaySpeed;
  final double size;
  final double spin;
  final Color color;
  final bool round;
}
