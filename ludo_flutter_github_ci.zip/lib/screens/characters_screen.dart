import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/game_theme.dart';
import '../game/characters.dart' as roster;
import '../widgets/character_card_panel.dart';
import '../widgets/game_ui.dart';

/// ---------------------------------------------------------------------------
/// Update #2 (item 4) — Characters selection screen, completely separate from
/// the small in-lobby grid, matching the reference `Characters.png` layout:
/// a 2-column grid where EVERY card shows ONLY the character portrait, its
/// name, and a SELECT button — no number badge, no rarity tint, no other
/// text or labels, exactly as the user specified ("bas koi or other text
/// nahi"). Each card reuses the same [CharacterCardPanel] "player card"
/// look (item 6) that the lobby and victory screen also use, so the whole
/// app now speaks one visual language for character portraits.
/// ---------------------------------------------------------------------------
class CharactersScreen extends StatefulWidget {
  const CharactersScreen({super.key, required this.selected});

  final String selected;

  @override
  State<CharactersScreen> createState() => _CharactersScreenState();
}

class _CharactersScreenState extends State<CharactersScreen> {
  late String _selected = widget.selected;

  Future<void> _pick(String name) async {
    Sfx.instance.uiClick();
    setState(() => _selected = name);
    final p = await SharedPreferences.getInstance();
    await p.setString('character', name);
  }

  void _back() {
    Sfx.instance.uiClick();
    Navigator.of(context).pop(_selected);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        Navigator.of(context).pop(_selected);
      },
      child: Scaffold(
        backgroundColor: GameColors.bgVoid,
        body: DecoratedBox(
          decoration: const BoxDecoration(gradient: GameGradients.screen),
          child: Stack(
            children: [
              const Positioned.fill(
                child: IgnorePointer(
                  child: RepaintBoundary(
                    child: CustomPaint(painter: TexturePainter()),
                  ),
                ),
              ),
              SafeArea(
                child: LayoutBuilder(
                  builder: (context, cts) {
                    final w = cts.maxWidth;
                    final landscape = w > cts.maxHeight;
                    final scale = (cts.maxHeight / 460.0).clamp(0.6, 1.4);
                    final cols = landscape ? 5 : 3;

                    return Column(
                      children: [
                        _topBar(scale),
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(
                              14 * scale,
                              4 * scale,
                              14 * scale,
                              10 * scale,
                            ),
                            child: GridView.builder(
                              physics: const BouncingScrollPhysics(),
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: cols,
                                    crossAxisSpacing: 12 * scale,
                                    mainAxisSpacing: 14 * scale,
                                    childAspectRatio: 0.62,
                                  ),
                              itemCount: roster.Characters.count,
                              itemBuilder: (_, i) {
                                final c = roster.Characters.all[i];
                                final sel = c.name == _selected;
                                return _CharacterGridCard(
                                  character: c,
                                  fallbackSeed: i,
                                  selected: sel,
                                  scale: scale,
                                  onTap: () => _pick(c.name),
                                );
                              },
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topBar(double scale) {
    return Padding(
      padding: EdgeInsets.fromLTRB(10 * scale, 8 * scale, 10 * scale, 4 * scale),
      child: Row(
        children: [
          MetalIconButton(icon: Icons.arrow_back, size: 34 * scale, onTap: _back),
          Expanded(
            child: Center(
              child: Text(
                'CHARACTERS',
                style: GameTypography.heading(16 * scale),
              ),
            ),
          ),
          SizedBox(width: 34 * scale),
        ],
      ),
    );
  }
}

/// One reference-style card: portrait + name + SELECT, nothing else.
class _CharacterGridCard extends StatelessWidget {
  const _CharacterGridCard({
    required this.character,
    required this.fallbackSeed,
    required this.selected,
    required this.scale,
    required this.onTap,
  });

  final roster.GameCharacter character;
  final int fallbackSeed;
  final bool selected;
  final double scale;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = ShowcasePalette.forSeed(fallbackSeed);
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Expanded(
            child: LayoutBuilder(
              builder: (context, box) {
                // Fill exactly the space Expanded actually hands us — the
                // panel computes its own height from width/aspectRatio, so
                // feed it the real box's own ratio.
                return CharacterCardPanel(
                  character: character.name,
                  color: selected ? GameColors.gold : color,
                  width: box.maxWidth,
                  aspectRatio: box.maxWidth / box.maxHeight,
                  dark: selected,
                  glow: selected ? GameColors.gold : null,
                  fallbackSeed: fallbackSeed,
                  nameBelow: false,
                  name: null,
                );
              },
            ),
          ),
          SizedBox(height: 5 * scale),
          Text(
            character.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GameTypography.name(12.5 * scale),
          ),
          SizedBox(height: 4 * scale),
          GlossyButton(
            label: selected ? 'SELECTED' : 'SELECT',
            height: 22 * scale,
            fontSize: 9 * scale,
            gradient: selected ? GameGradients.play : GameGradients.idleButton,
            onTap: onTap,
          ),
        ],
      ),
    );
  }
}
