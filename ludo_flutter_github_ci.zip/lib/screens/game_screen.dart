import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/theme.dart';
import '../game/board_map.dart';
import '../game/engine.dart';
import '../game/game_speed.dart';
import '../game/models.dart';
import '../widgets/board_painter.dart';
import '../widgets/dice_widget.dart';
import '../widgets/player_card.dart';
import '../widgets/token_widget.dart';
import 'result_screen.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.config});
  final GameConfig config;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late final LudoEngine engine;
  late final AnimationController _glow;
  String? _toast;
  int _lastEventStamp = 0;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    // The lobby runs in landscape, but the ludo board itself is a square in a
    // portrait layout, so flip back for the duration of the match.
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    engine = LudoEngine(
      config: widget.config,
      // Route every engine event straight into the offline sound engine.
      onSound: Sfx.instance.play,
    );
    engine.addListener(_onEngine);
    _glow = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    WidgetsBinding.instance.addPostFrameCallback((_) => engine.start());
  }

  void _onEngine() {
    if (!mounted) return;
    // surface newest event as a toast
    if (engine.events.isNotEmpty) {
      final e = engine.events.last;
      if (e.stamp != _lastEventStamp) {
        _lastEventStamp = e.stamp;
        _toast = e.text;
        Future<void>.delayed(engine.speed.toastVisible, () {
          if (mounted && _toast == e.text) setState(() => _toast = null);
        });
      }
    }
    if (engine.finished && !_navigated) {
      _navigated = true;
      Future<void>.delayed(engine.speed.resultDelay, () {
        if (!mounted) return;
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (_) =>
                ResultScreen(rows: engine.results(), config: widget.config),
          ),
        );
      });
    }
    setState(() {});
  }

  @override
  void dispose() {
    engine.removeListener(_onEngine);
    engine.dispose();
    _glow.dispose();
    super.dispose();
  }

  /// Current pacing preset (can be changed mid-match from settings).
  SpeedPreset get _speed => engine.speedPreset;

  /// Pass & play (all friends on one phone) uses per-seat dice instead of the
  /// single shared roll button at the bottom of the screen.
  bool get _passAndPlay => widget.config.mode == GameMode.passAndPlay;

  /// May [p]'s own corner dice be tapped right now?
  bool _seatCanRoll(Player p) =>
      _passAndPlay &&
      !engine.finished &&
      !engine.paused &&
      engine.current.id == p.id &&
      engine.dice == null &&
      !engine.rolling &&
      !engine.moving;

  /// Base single-cell hop duration in ms, taken from the engine's speed
  /// preset so board animation and game pacing always stay in sync.
  double get _hopMs => 250 * _speed.factor;

  Future<void> _persistSpeed(SpeedPreset sp) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('speed', sp.index);
  }

  // ------------------------------------------------------------ interactions

  void _onTapToken(Player p, int tokenIndex) {
    if (!engine.myTurn || engine.dice == null) return;
    if (p.id != engine.current.id) return;
    if (!engine.movable.contains(tokenIndex)) return;
    HapticFeedback.selectionClick();
    Sfx.instance.tap();
    engine.moveToken(tokenIndex);
  }

  Future<bool> _confirmExit() async {
    final res = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.panelDark,
        title: const Text('Leave match?', style: AppText.h2),
        content: Text(
          widget.config.matchMode.isClassic
              ? 'If you leave now the match ends and your current progress '
                    'is treated as final.'
              : 'If you leave now your current score is treated as final.',
          style: AppText.body,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Keep playing'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.pRed),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Leave'),
          ),
        ],
      ),
    );
    return res ?? false;
  }

  // ------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await _confirmExit()) {
          if (!mounted) return;
          engine.forceFinish();
        }
      },
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: AppColors.screenBg),
          child: Stack(
            children: [
              // subtle darker purple diagonal pattern (reference video look)
              const Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(painter: _BackdropPainter()),
                ),
              ),
              SafeArea(
                child: LayoutBuilder(
                  builder: (context, cts) {
                    // Pass & play hangs a dice strip above and below the board, so
                    // the board has to shrink vertically to leave room for them.
                    // plateH = 4.0u * 0.62 = 2.48u, plus a 0.30u gap, top and bottom.
                    final outer = _passAndPlay
                        ? 0.445
                        : 0.0; // 2 * (3.04 + 0.30) / 15
                    final boardSize = min(
                      cts.maxWidth - 12,
                      cts.maxHeight * 0.62 / (1 + outer),
                    );
                    return Column(
                      children: [
                        _topBar(),
                        const Spacer(flex: 2),
                        _boardWithCornerDice(boardSize),
                        const Spacer(flex: 2),
                        _bottomBar(),
                        const SizedBox(height: 6),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ------------- top bar: settings, clock/mode -------------
  //
  // NOTE (update): the top-right "Your Score" purple box and the green
  // "OFFLINE" badge that used to sit under it have been removed per request
  // #5 — the live score is already shown inside each seat's own PlayerCard,
  // so this was pure duplication. A blank spacer of the same width as the
  // settings button keeps the clock/mode pill perfectly centered.

  Widget _topBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              _circleBtn(
                icon: Icons.settings,
                onTap: () async {
                  // Freeze match clock, turn clock, animations and the queued
                  // next-turn callbacks while the sheet is open…
                  engine.pause();
                  await _showSettings();
                  // …and always un-freeze afterwards, however the sheet was
                  // dismissed (Resume, back gesture or tap outside).
                  if (!mounted) return;
                  engine.resume();
                },
              ),
              const SizedBox(height: 4),
              const Text('Settings', style: AppText.small),
            ],
          ),
          Expanded(
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 9,
                ),
                decoration: BoxDecoration(
                  gradient: AppColors.purplePill,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: AppColors.stroke, width: 1.6),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      widget.config.timed
                          ? Icons.timer_outlined
                          : Icons.casino_outlined,
                      color: Colors.white,
                      size: 22,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      widget.config.timed ? engine.clockText : 'CLASSIC',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Balances the settings button on the left so the clock/mode pill
          // in the middle stays visually centered now that the score box is
          // gone.
          const SizedBox(width: 52),
        ],
      ),
    );
  }

  Widget _circleBtn({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: AppColors.purplePill,
          border: Border.all(color: AppColors.stroke, width: 1.6),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 26),
      ),
    );
  }

  // ---------------- board + player panels + tokens ----------------

  /// PASS & PLAY: the board plus one dice per friend sitting OUTSIDE the board,
  /// in that player's own screen corner (below/above their avatar) — exactly
  /// where Ludo King puts them. Bots mode returns the bare board unchanged.
  Widget _boardWithCornerDice(double size) {
    if (!_passAndPlay) return _boardArea(size);

    final u = size / 15.0;
    // The Ludo King plate is a wide two-segment strip, so it only needs
    // vertical room above and below the board — its width tucks in over the
    // board's own corner columns.
    final plateW = u * 4.9;
    final plateH = plateW * 0.62;
    final gap = u * 0.30;
    final pad = plateH + gap; // vertical room added above and below the board

    final occupied = {for (final p in engine.players) p.seat: p};

    return SizedBox(
      width: size,
      height: size + pad * 2,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // the board itself, sitting between the two dice rows
          Positioned(left: 0, top: pad, child: _boardArea(size)),

          // one dice per seated friend, outside the board in their own corner
          for (final seat in Seat.values)
            if (occupied[seat] != null)
              _cornerDice(occupied[seat]!, plateW, size, pad, gap),
        ],
      ),
    );
  }

  Widget _boardArea(double size) {
    final u = size / 15.0;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // static board
          SizedBox(
            width: size,
            height: size,
            child: const CustomPaint(painter: BoardPainter()),
          ),

          // player cards inside the 4 corner bases
          ..._seatPanels(size, u),

          // movable-cell hints
          ..._moveHints(size, u),

          // tokens
          ..._tokens(size, u),

          // event notification bar across the bottom of the board
          // (matches the reference video's kill/announcement strip)
          if (_toast != null)
            Positioned(
              left: 0,
              right: 0,
              bottom: -size * 0.055,
              child: IgnorePointer(
                child: Center(
                  child: _SlideInBar(
                    trigger: _toast!,
                    child: Container(
                      constraints: BoxConstraints(maxWidth: size * 1.02),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 9,
                      ),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            const Color(0xFF241546).withValues(alpha: 0.96),
                            const Color(0xFF3B1F63).withValues(alpha: 0.96),
                            const Color(0xFF241546).withValues(alpha: 0.96),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(11),
                        border: Border.all(
                          color: AppColors.glow.withValues(alpha: 0.65),
                          width: 1.4,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.45),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Text(
                        _toast!,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          height: 1.15,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  List<Widget> _seatPanels(double size, double u) {
    final widgets = <Widget>[];
    final occupied = {for (final p in engine.players) p.seat: p};

    for (final seat in Seat.values) {
      final color = seat.color;
      final origin = BoardMap.baseOrigin[color]!;
      final rect = Rect.fromLTWH(origin.c * u, origin.r * u, u * 6, u * 6);
      final p = occupied[seat];
      widgets.add(
        Positioned(
          left: rect.left,
          top: rect.top,
          width: rect.width,
          height: rect.height,
          child: p == null
              ? EmptySeatPanel(color: color, compact: size < 340)
              : PlayerCard(
                  player: p,
                  isTurn: engine.current.id == p.id && !engine.finished,
                  dice: engine.current.id == p.id ? engine.dice : null,
                  turnProgress:
                      engine.turnRemaining /
                      widget.config.turnSeconds.toDouble(),
                  compact: size < 340,
                  showScore: widget.config.timed,
                  // Pass & play draws a bigger dice in each seat's own outer
                  // board corner instead, so the panel badge is dropped.
                  // Bots mode is left exactly as it was.
                  showDice: !_passAndPlay,
                ),
        ),
      );
    }

    return widgets;
  }

  /// A single friend's dice, parked OUTSIDE the ludo board in that friend's own
  /// screen corner — below the avatar for the two bottom seats and above it for
  /// the two top seats, exactly like Ludo King. Every board colour gets its own
  /// tinted plate. PASS & PLAY only; bots mode is untouched.
  Widget _cornerDice(
    Player p,
    double plateW,
    double size,
    double pad,
    double gap,
  ) {
    final origin = BoardMap.baseOrigin[p.color]!;
    final live = _seatCanRoll(p);
    final isTurn = engine.current.id == p.id && !engine.finished;
    final rolling = engine.rolling && engine.current.id == p.id;
    final face = isTurn ? (engine.dice ?? p.lastDice) : p.lastDice;

    //   yellow -> above top-left      blue -> above top-right
    //   green  -> below bottom-left   red  -> below bottom-right
    final onLeft = origin.c == 0;
    final onTop = origin.r == 0;
    final plateH = plateW * 0.62;

    // Align each plate with its own base panel; the board spans [pad, pad+size]
    // vertically, so the top row sits just above it and the bottom row below.
    final left = onLeft ? 0.0 : size - plateW;
    final top = onTop ? pad - plateH - gap : pad + size + gap;

    return Positioned(
      left: left,
      top: top,
      width: plateW,
      height: plateH,
      child: GestureDetector(
        onTap: live
            ? () {
                HapticFeedback.mediumImpact();
                engine.rollDice();
              }
            : null,
        behavior: HitTestBehavior.opaque,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 220),
          scale: rolling ? 1.08 : (live ? 1.0 + 0.05 * _glow.value : 0.96),
          child: Transform.rotate(
            // a small wobble while the dice is tumbling
            angle: rolling ? sin(_glow.value * 2 * pi) * 0.10 : 0,
            child: CornerDicePlate(
              value: face,
              width: plateW,
              seatColor: p.color.main,
              seatDark: p.color.dark,
              // Keep the pin facing the board and the die facing the screen
              // edge, so all four plates mirror each other neatly.
              pinOnLeft: !onLeft,
              live: live,
              pulse: live ? _glow.value : 0.0,
              turnProgress: isTurn
                  ? engine.turnRemaining / widget.config.turnSeconds.toDouble()
                  : null,
            ),
          ),
        ),
      ),
    );
  }

  /// Target-cell rings + a floating badge above each movable pawn showing the
  /// rolled dice number (exactly like the reference gameplay video).
  List<Widget> _moveHints(double size, double u) {
    if (!engine.myTurn || engine.dice == null || engine.movable.isEmpty) {
      return const [];
    }
    final p = engine.current;
    final d = engine.dice!;
    final hints = <Widget>[];

    // 1) soft pulsing ring on every landing cell
    for (final idx in engine.movable) {
      final t = p.tokens[idx];
      // A closed classic token always lands on its own start square.
      final cell = t.open
          ? BoardMap.cellFor(p.color, t.pos + d)
          : BoardMap.cellFor(p.color, 0);
      final c = BoardMap.centerOf(cell, size);
      hints.add(
        Positioned(
          left: c.dx - u * 0.44,
          top: c.dy - u * 0.44,
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: _glow,
              builder: (_, __) => Container(
                width: u * 0.88,
                height: u * 0.88,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: p.color.main.withValues(
                    alpha: 0.14 + 0.16 * _glow.value,
                  ),
                  border: Border.all(
                    color: p.color.main.withValues(
                      alpha: 0.55 + 0.4 * _glow.value,
                    ),
                    width: u * 0.075,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    // 2) dice-number badge hovering over each pawn that can make that move
    final seen = <String>{};
    for (final idx in engine.movable) {
      final t = p.tokens[idx];
      final cell = t.open
          ? BoardMap.cellFor(p.color, t.pos)
          : BoardMap.yardSlot(p.color, t.index);
      final key = '${cell.r}_${cell.c}';
      if (!seen.add(key)) continue; // one badge per stack
      final c = BoardMap.centerOf(cell, size);
      hints.add(
        Positioned(
          left: c.dx - u * 0.40,
          top: c.dy - u * 1.42,
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: _glow,
              builder: (_, __) => Transform.translate(
                offset: Offset(0, -u * 0.10 * _glow.value),
                child: _MoveBadge(number: d, color: p.color, unit: u),
              ),
            ),
          ),
        ),
      );
    }
    return hints;
  }

  List<Widget> _tokens(double size, double u) {
    final widgets = <Widget>[];

    // Group tokens by grid cell, then merge same-colored tokens of the same
    // player into one pawn carrying a count badge (keeps the board readable).
    final Map<String, List<_TokenRef>> byCell = {};
    for (final p in engine.players) {
      for (final t in p.tokens) {
        // Classic mode: a token that has not been opened yet waits in its
        // own base yard instead of sitting on the start square.
        final cell = t.open
            ? BoardMap.cellFor(p.color, t.pos)
            : BoardMap.yardSlot(p.color, t.index);
        final key = '${cell.r}_${cell.c}';
        byCell.putIfAbsent(key, () => []).add(_TokenRef(p, t, cell));
      }
    }

    byCell.forEach((key, list) {
      // sub-group by owner so 4 tokens of one colour show as a single stack
      final Map<int, List<_TokenRef>> byOwner = {};
      for (final ref in list) {
        byOwner.putIfAbsent(ref.player.id, () => []).add(ref);
      }

      final groups = byOwner.values.toList();
      // Stacks belonging to whoever currently holds the turn (works for both
      // Bots and Play & Pass — "current" is simply whichever seat is active
      // right now) are collected separately and appended LAST below, so they
      // always paint on top of any other colour sharing this cell. Position
      // (dx/dy fan angle) still uses the original group index `g`, so the
      // layout doesn't visually shuffle when the turn changes — only the
      // paint order and size change.
      final below = <Widget>[];
      final onTop = <Widget>[];

      for (var g = 0; g < groups.length; g++) {
        final stack = groups[g];
        final p = stack.first.player;
        final base = BoardMap.centerOf(stack.first.cell, size);

        // fan out different players sharing one safe cell
        final n = groups.length;
        double dx = 0, dy = 0;
        if (n > 1) {
          final a = (2 * pi / n) * g - pi / 2;
          final r = u * (n == 2 ? 0.18 : 0.24);
          dx = cos(a) * r;
          dy = sin(a) * r;
        }

        // pick the token that can move (so tapping the stack always works)
        _TokenRef pickable = stack.first;
        for (final ref in stack) {
          if (engine.movable.contains(ref.token.index)) {
            pickable = ref;
            break;
          }
        }

        final canMove =
            engine.myTurn &&
            engine.dice != null &&
            engine.current.id == p.id &&
            engine.movable.contains(pickable.token.index);

        final animating =
            engine.current.id == p.id &&
            stack.any((r) => r.token.index == engine.animatingToken);

        // This stack belongs to whichever seat currently holds the turn —
        // give it a size boost and top z-order so it's always the easy,
        // obvious one to tap when several colours share a cell.
        final isCurrentTurnStack =
            !engine.finished && engine.current.id == p.id;

        final pawnW =
            u *
            (stack.first.token.finished ? 0.60 : 0.80) *
            (isCurrentTurnStack ? 1.22 : 1.0);

        // Slide duration follows the engine's humanized hop timing so the
        // pawn glides between cells instead of teleporting.
        final hopping =
            engine.hopToken != null &&
            engine.current.id == p.id &&
            stack.any((r) => r.token.index == engine.hopToken);

        final widget = AnimatedPositioned(
          key: ValueKey('stk_${p.id}_${key}_$g'),
          duration: Duration(
            milliseconds: (_hopMs * (hopping ? 0.86 : 0.5)).round(),
          ),
          curve: Curves.easeInOut,
          left: base.dx + dx - pawnW / 2,
          top: base.dy + dy - pawnW * 0.78,
          child: GestureDetector(
            onTap: canMove ? () => _onTapToken(p, pickable.token.index) : null,
            behavior: HitTestBehavior.opaque,
            child: AnimatedBuilder(
              animation: _glow,
              builder: (_, __) => _HopBounce(
                // re-trigger the little jump on every single-cell hop
                trigger: hopping ? engine.hopSeq : -1,
                height: pawnW * 0.26,
                duration: Duration(milliseconds: (_hopMs * 0.8).round()),
                child: Pawn(
                  color: p.color,
                  size: pawnW,
                  highlight: canMove || animating,
                  glowPhase: _glow.value,
                  count: stack.length,
                ),
              ),
            ),
          ),
        );

        if (isCurrentTurnStack) {
          onTop.add(widget);
        } else {
          below.add(widget);
        }
      }

      widgets.addAll(below);
      widgets.addAll(onTop);
    });

    return widgets;
  }

  // ---------------- bottom bar: roll dice + score sheet ----------------

  // NOTE (update): the bottom-right "Score" leaderboard button has been
  // removed per request #5 — it duplicated info already visible on every
  // seat's own PlayerCard. The hint text + roll button now simply center
  // in the full-width row.
  Widget _bottomBar() {
    final myTurn = engine.myTurn;
    // Pass & play gives every friend their own dice in their own board corner,
    // so there is no shared roll button and no name plate down here — just a
    // one-line hint telling whoever is holding the phone what to do.
    final pnp = _passAndPlay;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Column(
        children: [
          AnimatedOpacity(
            opacity: engine.finished ? 0 : 1,
            duration: const Duration(milliseconds: 200),
            child: Text(
              engine.finished
                  ? ''
                  : pnp
                  ? (engine.dice == null
                        ? '${engine.current.name} — tap your dice'
                        : '${engine.current.name} — pick a token')
                  : myTurn
                  ? (engine.dice == null
                        ? 'Your turn — tap the dice'
                        : 'Select a token to move')
                  : '${engine.current.name} is playing…',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
                color: (pnp || myTurn) ? AppColors.gold : Colors.white70,
              ),
            ),
          ),
          // Pass & play has a dice in every corner, so there is no
          // shared roll button and no name plate down here at all.
          if (!pnp) const SizedBox(height: 8),
          if (!pnp)
            RollDiceButton(
              value: engine.dice,
              enabled: myTurn && engine.dice == null && !engine.rolling,
              rolling: engine.rolling,
              turnProgress: engine.finished
                  ? 0
                  : engine.turnRemaining /
                        widget.config.turnSeconds.toDouble(),
              ringColor: engine.current.color.main,
              onTap: () {
                HapticFeedback.mediumImpact();
                engine.rollDice();
              },
              // sound is emitted by the engine itself (roll / six / etc.)
            ),
        ],
      ),
    );
  }

  Future<void> _showSettings() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 26),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Settings', style: AppText.h2),
            const SizedBox(height: 6),
            const Text('Game paused', style: AppText.small),
            const SizedBox(height: 16),
            const Text('Game speed', style: AppText.small),
            const SizedBox(height: 8),
            Row(
              children: SpeedPreset.values.map((sp) {
                final sel = _speed == sp;
                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      engine.setSpeed(sp);
                      _persistSpeed(sp);
                      Navigator.pop(context);
                    },
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        gradient: sel ? AppColors.purplePill : null,
                        color: sel
                            ? null
                            : Colors.black.withValues(alpha: 0.26),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: sel ? AppColors.glow : Colors.white12,
                          width: sel ? 1.6 : 1,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          sp.label,
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w800,
                            color: sel ? Colors.white : Colors.white60,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 8),
            _SoundSwitchTile(),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.info_outline, color: Colors.white70),
              title: Text(
                '${widget.config.matchMode.label} Rules',
                style: AppText.body,
              ),
              onTap: () {
                Navigator.pop(context);
                _showRules();
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.flag, color: AppColors.pRed),
              title: const Text('Resign match', style: AppText.body),
              onTap: () {
                Navigator.pop(context);
                engine.forceFinish();
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.play_arrow, color: AppColors.online),
              title: const Text('Resume', style: AppText.body),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  void _showRules() {
    final classic = widget.config.matchMode.isClassic;
    final text = classic
        ? '• Roll a 6 to bring a token out of your base yard.\n\n'
              '• Rolling a 6 grants you an extra turn.\n\n'
              '• Three 6s in a row: the roll is void and your turn is lost.\n\n'
              '• Land exactly on a rival token to send it back to its yard — '
              'that also earns you an extra turn.\n\n'
              '• Star (*) cells and the coloured start boxes are safe zones; '
              'nobody can be cut there.\n\n'
              '• BLOCK: 2, 3 or 4 tokens of the SAME colour standing on one '
              'cell protect each other — that stack can never be cut, '
              'anywhere on the board.\n\n'
              '• You need the exact count to enter HOME.\n\n'
              '• Miss 3 turns in a row and you are eliminated.\n\n'
              '• The first player to bring all 4 tokens HOME wins the match.'
        : '• The match lasts ${widget.config.matchSeconds ~/ 60} minutes — '
              'the highest score when the clock hits zero wins.\n\n'
              '• All 4 tokens start OPEN, so no 6 is needed to move out.\n\n'
              '• Every step forward scores 1 point.\n\n'
              '• Bringing a token HOME adds a +56 bonus.\n\n'
              '• Cut a rival token and ALL of its points transfer to you.\n\n'
              '• Star (*) cells and the coloured start boxes are safe zones; '
              'tokens there cannot be cut.\n\n'
              '• BLOCK: 2, 3 or 4 tokens of the SAME colour standing on one '
              'cell protect each other — that stack can never be cut, '
              'anywhere on the board.\n\n'
              '• Rolling a 6 or cutting a token grants an extra turn.\n\n'
              '• Three 6s in a row: the roll is void and your turn is lost.\n\n'
              '• Let the turn timer run out and the turn is missed. Three '
              'misses in a row eliminate you.';

    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.panelDark,
        title: Text(
          '${widget.config.matchMode.label} Rules',
          style: AppText.h2,
        ),
        content: SingleChildScrollView(child: Text(text, style: AppText.body)),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}

/// In-match sound on/off row (kept stateful so the switch reacts instantly
/// without rebuilding the whole settings sheet).
class _SoundSwitchTile extends StatefulWidget {
  @override
  State<_SoundSwitchTile> createState() => _SoundSwitchTileState();
}

class _SoundSwitchTileState extends State<_SoundSwitchTile> {
  @override
  Widget build(BuildContext context) {
    final on = Sfx.instance.enabled;
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      value: on,
      activeThumbColor: AppColors.online,
      secondary: Icon(
        on ? Icons.volume_up_rounded : Icons.volume_off_rounded,
        color: on ? AppColors.online : Colors.white38,
      ),
      title: const Text('Sound effects', style: AppText.body),
      subtitle: Text(
        on ? 'Dice, hops, cuts & fanfare' : 'Muted',
        style: AppText.small,
      ),
      onChanged: (v) async {
        await Sfx.instance.setEnabled(v);
        if (!mounted) return;
        setState(() {});
        if (v) Sfx.instance.tap();
      },
    );
  }
}

class _TokenRef {
  final Player player;
  final Token token;
  final Cell cell;
  _TokenRef(this.player, this.token, this.cell);
}

/// Small floating pill showing the rolled dice number above a movable pawn.
class _MoveBadge extends StatelessWidget {
  const _MoveBadge({
    required this.number,
    required this.color,
    required this.unit,
  });

  final int number;
  final PColor color;
  final double unit;

  @override
  Widget build(BuildContext context) {
    final d = unit * 0.80;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: d,
          height: d,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color.lerp(color.main, Colors.white, 0.30)!, color.dark],
            ),
            border: Border.all(color: Colors.white, width: d * 0.10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.4),
                blurRadius: d * 0.22,
                offset: Offset(0, d * 0.08),
              ),
            ],
          ),
          child: Text(
            '$number',
            style: TextStyle(
              fontSize: d * 0.52,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              height: 1,
            ),
          ),
        ),
        // little pointer tail toward the pawn
        CustomPaint(
          size: Size(d * 0.42, d * 0.26),
          painter: _TailPainter(color.dark),
        ),
      ],
    );
  }
}

/// Fades + slides the notification bar in whenever [trigger] changes.
class _SlideInBar extends StatefulWidget {
  const _SlideInBar({required this.trigger, required this.child});
  final String trigger;
  final Widget child;

  @override
  State<_SlideInBar> createState() => _SlideInBarState();
}

class _SlideInBarState extends State<_SlideInBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 320),
  )..forward();

  @override
  void didUpdateWidget(_SlideInBar old) {
    super.didUpdateWidget(old);
    if (old.trigger != widget.trigger) _c.forward(from: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final e = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);
    return AnimatedBuilder(
      animation: e,
      builder: (context, child) => Opacity(
        opacity: e.value,
        child: Transform.translate(
          offset: Offset(0, (1 - e.value) * 14),
          child: child,
        ),
      ),
      child: widget.child,
    );
  }
}

class _TailPainter extends CustomPainter {
  _TailPainter(this.color);
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _TailPainter old) => old.color != color;
}

/// Lifts the pawn in a small arc every time [trigger] changes, so a multi-cell
/// move reads as a sequence of real hops instead of one long slide.
class _HopBounce extends StatefulWidget {
  const _HopBounce({
    required this.trigger,
    required this.height,
    required this.duration,
    required this.child,
  });

  final int trigger;
  final double height;
  final Duration duration;
  final Widget child;

  @override
  State<_HopBounce> createState() => _HopBounceState();
}

class _HopBounceState extends State<_HopBounce>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: widget.duration,
  );

  @override
  void didUpdateWidget(_HopBounce old) {
    super.didUpdateWidget(old);
    if (widget.trigger != old.trigger && widget.trigger >= 0) {
      _c
        ..duration = widget.duration
        ..forward(from: 0);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) {
        // sin arc: 0 -> up -> 0
        final lift = sin(_c.value * pi) * widget.height;
        final squash = 1.0 - sin(_c.value * pi) * 0.06;
        return Transform.translate(
          offset: Offset(0, -lift),
          child: Transform.scale(
            scaleY: squash,
            alignment: Alignment.bottomCenter,
            child: child,
          ),
        );
      },
      child: widget.child,
    );
  }
}

/// Very subtle diagonal stripe + vignette pattern behind the whole game.
class _BackdropPainter extends CustomPainter {
  const _BackdropPainter();

  @override
  void paint(Canvas canvas, Size size) {
    // diagonal stripes
    final stripe = Paint()
      ..color = Colors.white.withValues(alpha: 0.016)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 12;
    const gap = 34.0;
    for (double x = -size.height; x < size.width + size.height; x += gap) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x + size.height, size.height),
        stripe,
      );
    }

    // corner vignette so the board stays the visual focus
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 0.95,
          colors: [Colors.transparent, Colors.black.withValues(alpha: 0.30)],
          stops: const [0.55, 1.0],
        ).createShader(Offset.zero & size),
    );
  }

  @override
  bool shouldRepaint(covariant _BackdropPainter old) => false;
}
