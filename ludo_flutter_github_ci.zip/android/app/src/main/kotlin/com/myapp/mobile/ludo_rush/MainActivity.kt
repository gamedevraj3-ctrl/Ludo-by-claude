package com.myapp.mobile.ludo_rush

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
