#!/usr/bin/env python3
"""
Generates all Ludo Rush sound effects as small mono 22.05kHz WAV files.

Everything is synthesised from scratch with the Python standard library only,
so the game ships 100% offline with no downloaded/licensed audio.
"""
import math
import os
import struct
import wave

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sfx")


# ----------------------------------------------------------------- helpers
def env(i, n, attack=0.01, release=0.35):
    """Simple attack/decay envelope, returns 0..1."""
    a = max(1, int(n * attack))
    r = max(1, int(n * release))
    if i < a:
        return i / a
    if i > n - r:
        return max(0.0, (n - i) / r)
    return 1.0


def tone(freq, dur, vol=0.5, wave_type="sine", attack=0.01, release=0.35,
         freq_end=None, vibrato=0.0):
    """Single oscillator with optional linear pitch glide."""
    n = int(SR * dur)
    out = []
    phase = 0.0
    for i in range(n):
        t = i / SR
        f = freq if freq_end is None else freq + (freq_end - freq) * (i / n)
        if vibrato:
            f *= 1.0 + vibrato * math.sin(2 * math.pi * 6.0 * t)
        phase += 2 * math.pi * f / SR
        if wave_type == "sine":
            s = math.sin(phase)
        elif wave_type == "tri":
            s = 2 / math.pi * math.asin(math.sin(phase))
        elif wave_type == "square":
            s = 1.0 if math.sin(phase) > 0 else -1.0
        else:  # saw
            s = 2 * ((phase / (2 * math.pi)) % 1.0) - 1.0
        out.append(s * vol * env(i, n, attack, release))
    return out


def noise(dur, vol=0.5, attack=0.005, release=0.5, lp=0.25):
    """Low-pass filtered pseudo-random noise (deterministic LCG)."""
    n = int(SR * dur)
    out = []
    seed = 12345
    prev = 0.0
    for i in range(n):
        seed = (1103515245 * seed + 12345) & 0x7FFFFFFF
        r = (seed / 0x3FFFFFFF) - 1.0
        prev += lp * (r - prev)          # one-pole low pass
        out.append(prev * vol * env(i, n, attack, release))
    return out


def mix(*layers):
    n = max(len(x) for x in layers)
    out = [0.0] * n
    for layer in layers:
        for i, v in enumerate(layer):
            out[i] += v
    return out


def seq(*parts):
    out = []
    for p in parts:
        out.extend(p)
    return out


def silence(dur):
    return [0.0] * int(SR * dur)


def pad(layer, dur):
    n = int(SR * dur)
    return layer + [0.0] * max(0, n - len(layer))


def save(name, samples):
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, name + ".wav")
    # normalise with headroom, then soft clip
    peak = max(1e-6, max(abs(s) for s in samples))
    gain = 0.82 / peak
    frames = bytearray()
    for s in samples:
        v = s * gain
        v = math.tanh(v * 1.15)          # gentle saturation, no harsh clipping
        frames += struct.pack("<h", int(max(-1.0, min(1.0, v)) * 32767))
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(bytes(frames))
    kb = os.path.getsize(path) / 1024
    print(f"  {name+'.wav':<18} {kb:6.1f} KB  {len(samples)/SR:.2f}s")


# ----------------------------------------------------------------- effects
def sfx_dice_roll():
    """Dice tumbling in a cup then landing: rattle + wooden knocks."""
    rattle = noise(0.30, vol=0.42, attack=0.02, release=0.55, lp=0.55)
    knocks = []
    for k, (at, f) in enumerate([(0.05, 320), (0.13, 280), (0.22, 240)]):
        click = mix(
            tone(f, 0.05, vol=0.34, wave_type="tri", attack=0.002, release=0.85),
            noise(0.05, vol=0.20, attack=0.002, release=0.85, lp=0.7),
        )
        knocks.append(pad(silence(at) + click, 0.36))
    land = pad(silence(0.30) + mix(
        tone(180, 0.14, vol=0.50, wave_type="tri", attack=0.002, release=0.75),
        noise(0.10, vol=0.22, attack=0.002, release=0.8, lp=0.5),
    ), 0.46)
    return mix(pad(rattle, 0.46), *knocks, land)


def sfx_dice_six():
    """Dice roll plus a bright rising sparkle for the lucky 6."""
    base = sfx_dice_roll()
    spark = pad(silence(0.30) + seq(
        tone(880, 0.07, vol=0.28, wave_type="sine", release=0.6),
        tone(1174, 0.07, vol=0.28, wave_type="sine", release=0.6),
        tone(1568, 0.16, vol=0.30, wave_type="sine", release=0.7),
    ), 0.66)
    return mix(pad(base, 0.66), spark)


def sfx_hop():
    """Short bright blip for each single-cell pawn hop."""
    return mix(
        tone(660, 0.055, vol=0.34, wave_type="sine", freq_end=880,
             attack=0.004, release=0.7),
        tone(1320, 0.04, vol=0.10, wave_type="sine", attack=0.004, release=0.8),
    )


def sfx_token_open():
    """Cheerful two-note pop when a token leaves the yard (classic mode)."""
    return seq(
        tone(523, 0.09, vol=0.34, wave_type="tri", release=0.5),
        tone(784, 0.16, vol=0.36, wave_type="tri", release=0.65),
    )


def sfx_cut():
    """Impact + descending 'whoosh' as the victim token is sent back."""
    hit = mix(
        tone(150, 0.16, vol=0.55, wave_type="tri", freq_end=70,
             attack=0.002, release=0.7),
        noise(0.14, vol=0.42, attack=0.002, release=0.7, lp=0.6),
    )
    fall = pad(silence(0.10) + tone(700, 0.34, vol=0.30, wave_type="saw",
                                    freq_end=180, attack=0.01, release=0.6), 0.48)
    return mix(pad(hit, 0.48), fall)


def sfx_home():
    """Warm rising arpeggio when a token reaches HOME."""
    return seq(
        tone(523, 0.10, vol=0.30, wave_type="tri", release=0.45),
        tone(659, 0.10, vol=0.30, wave_type="tri", release=0.45),
        tone(784, 0.10, vol=0.32, wave_type="tri", release=0.45),
        mix(
            tone(1046, 0.34, vol=0.34, wave_type="tri", release=0.6),
            tone(1568, 0.30, vol=0.14, wave_type="sine", release=0.7),
        ),
    )


def sfx_extra_turn():
    """Quick friendly 'ding-ding' for an extra chance."""
    return seq(
        tone(988, 0.08, vol=0.28, wave_type="sine", release=0.6),
        silence(0.03),
        tone(1318, 0.16, vol=0.30, wave_type="sine", release=0.7),
    )


def sfx_no_move():
    """Soft muted thud — nothing could move."""
    return mix(
        tone(220, 0.16, vol=0.30, wave_type="tri", freq_end=170,
             attack=0.01, release=0.7),
        noise(0.10, vol=0.10, attack=0.01, release=0.8, lp=0.3),
    )


def sfx_miss():
    """Descending two-note 'aww' for a missed turn."""
    return seq(
        tone(440, 0.13, vol=0.30, wave_type="tri", release=0.5),
        tone(330, 0.24, vol=0.30, wave_type="tri", release=0.65),
    )


def sfx_forfeit():
    """Buzzy warning for three sixes in a row (turn voided)."""
    return mix(
        tone(200, 0.34, vol=0.34, wave_type="square", freq_end=140,
             attack=0.01, release=0.5, vibrato=0.05),
        noise(0.30, vol=0.14, attack=0.01, release=0.6, lp=0.4),
    )


def sfx_win():
    """Triumphant fanfare."""
    def chord(root, dur, vol=0.26):
        return mix(
            tone(root, dur, vol=vol, wave_type="tri", release=0.4),
            tone(root * 1.26, dur, vol=vol * 0.7, wave_type="tri", release=0.4),
            tone(root * 1.5, dur, vol=vol * 0.7, wave_type="tri", release=0.4),
        )
    return seq(
        chord(523, 0.16),
        chord(659, 0.16),
        chord(784, 0.16),
        mix(
            chord(1046, 0.60, vol=0.30),
            # kept quiet and rolled off — a loud 2kHz sine is piercing on
            # phone speakers
            tone(2093, 0.40, vol=0.035, wave_type="sine", release=0.85),
        ),
    )


def sfx_lose():
    """Gentle descending phrase — not harsh, just 'better luck next time'."""
    return seq(
        tone(523, 0.16, vol=0.26, wave_type="tri", release=0.45),
        tone(440, 0.16, vol=0.26, wave_type="tri", release=0.45),
        tone(349, 0.18, vol=0.26, wave_type="tri", release=0.45),
        tone(262, 0.46, vol=0.28, wave_type="tri", release=0.6),
    )


def sfx_match_start():
    """Whistle-style kickoff."""
    return mix(
        tone(700, 0.34, vol=0.30, wave_type="sine", freq_end=1050,
             attack=0.03, release=0.4, vibrato=0.03),
        pad(silence(0.28) + tone(1400, 0.18, vol=0.16, wave_type="sine",
                                 release=0.7), 0.46),
    )


def sfx_tap():
    """UI click."""
    return mix(
        tone(1200, 0.032, vol=0.26, wave_type="sine", attack=0.002, release=0.8),
        noise(0.022, vol=0.10, attack=0.002, release=0.85, lp=0.8),
    )


EFFECTS = {
    "dice_roll": sfx_dice_roll,
    "dice_six": sfx_dice_six,
    "hop": sfx_hop,
    "token_open": sfx_token_open,
    "cut": sfx_cut,
    "home": sfx_home,
    "extra_turn": sfx_extra_turn,
    "no_move": sfx_no_move,
    "miss": sfx_miss,
    "forfeit": sfx_forfeit,
    "win": sfx_win,
    "lose": sfx_lose,
    "match_start": sfx_match_start,
    "tap": sfx_tap,
}

if __name__ == "__main__":
    print(f"Generating {len(EFFECTS)} sound effects at {SR} Hz mono ->")
    total = 0
    for name, fn in EFFECTS.items():
        save(name, fn())
        total += os.path.getsize(os.path.join(OUT, name + ".wav"))
    print(f"\nTotal: {total/1024:.1f} KB")
