import 'package:flutter_test/flutter_test.dart';

import 'package:ludo_rush/core/theme.dart';
import 'package:ludo_rush/game/board_map.dart';
import 'package:ludo_rush/game/characters.dart';
import 'package:ludo_rush/game/engine.dart';
import 'package:ludo_rush/game/game_speed.dart';
import 'package:ludo_rush/game/models.dart';

/// Instant engine used for rule tests so they run fast.
LudoEngine _engine({
  int players = 4,
  int turnSec = 15,
  MatchMode match = MatchMode.rush,
}) => LudoEngine(
  config: GameConfig(
    mode: GameMode.bots,
    matchMode: match,
    playerCount: players,
    matchSeconds: 600,
    turnSeconds: turnSec,
    speed: SpeedPreset.fast,
  ),
);

/// Finds the position on [a]'s path that lands on the same ring cell that
/// [b] currently occupies at [bPos].
int _interceptPos(Player a, Player b, int bPos) {
  final targetRing = BoardMap.ringIndexFor(b.color, bPos);
  for (var pos = 1; pos <= BoardMap.lastRingStep; pos++) {
    if (BoardMap.ringIndexFor(a.color, pos) == targetRing) return pos;
  }
  return -1;
}

void main() {
  test('safe zones: star cells and start squares cannot be cut', () {
    for (final idx in BoardMap.starRingIndexes) {
      expect(BoardMap.safeRingIndexes.contains(idx), isTrue);
    }
    for (final c in PColor.values) {
      expect(
        BoardMap.safeRingIndexes.contains(BoardMap.startIndex[c]!),
        isTrue,
      );
    }
    expect(BoardMap.isSafePos(PColor.yellow, 3), isFalse);
  });

  test('cut TRANSFERS the victim\'s points to the cutter', () async {
    final e = _engine(players: 2);
    final a = e.players[0];
    final b = e.players[1];

    final bTok = b.tokens[0];
    bTok.pos = 20;
    b.score = 20;
    expect(BoardMap.isSafePos(b.color, bTok.pos), isFalse);

    final aPos = _interceptPos(a, b, bTok.pos);
    expect(aPos, greaterThan(0));

    a.tokens[0].pos = aPos - 1;
    a.score = aPos - 1;
    final aBefore = a.score;

    e.currentIndex = 0;
    e.dice = 1;
    e.movable = [0];
    await e.moveToken(0);

    expect(a.tokens[0].pos, aPos);
    expect(bTok.pos, 0, reason: 'cut token returns to its start square');
    expect(b.score, 0, reason: 'victim loses every point it carried');
    // +1 for the step it walked, +20 stolen from the victim
    expect(
      a.score,
      aBefore + 1 + 20,
      reason: 'all of the victim\'s points must land on the cutter',
    );
    e.dispose();
  });

  test('cut cannot push the victim score below zero', () async {
    final e = _engine(players: 2);
    final a = e.players[0];
    final b = e.players[1];

    final bTok = b.tokens[0];
    bTok.pos = 20;
    b.score = 5; // deliberately less than the token carries
    final aPos = _interceptPos(a, b, bTok.pos);
    a.tokens[0].pos = aPos - 1;
    a.score = 0;

    e.currentIndex = 0;
    e.dice = 1;
    e.movable = [0];
    await e.moveToken(0);

    expect(b.score, 0, reason: 'score is clamped, never negative');
    expect(a.score, greaterThan(0), reason: 'cutter still gains the points');
    e.dispose();
  });

  test('token on a safe cell survives an opponent landing on it', () async {
    final e = _engine(players: 2);
    final a = e.players[0];
    final b = e.players[1];

    int? safePos;
    for (var pos = 1; pos <= BoardMap.lastRingStep; pos++) {
      if (BoardMap.isSafePos(b.color, pos)) {
        safePos = pos;
        break;
      }
    }
    expect(safePos, isNotNull);
    b.tokens[0].pos = safePos!;
    b.score = safePos;

    final aPos = _interceptPos(a, b, safePos);
    expect(aPos, greaterThan(0));
    a.tokens[0].pos = aPos - 1;

    e.currentIndex = 0;
    e.dice = 1;
    e.movable = [0];
    await e.moveToken(0);

    expect(b.tokens[0].pos, safePos, reason: 'safe token must not be cut');
    expect(b.score, safePos);
    e.dispose();
  });

  test('reaching home gives +56 bonus on top of step points', () async {
    final e = _engine(players: 2);
    final a = e.players[0];
    final t = a.tokens[0];
    t.pos = BoardMap.homeStep - 2; // 54
    a.score = t.pos;

    e.currentIndex = 0;
    e.dice = 2;
    e.movable = [0];
    await e.moveToken(0);

    expect(t.finished, isTrue);
    expect(t.pos, BoardMap.homeStep);
    expect(a.score, 54 + 2 + 56);
    e.dispose();
  });

  test('overshooting home is not a legal move', () {
    final e = _engine(players: 2);
    final a = e.players[0];
    a.tokens[0].pos = BoardMap.homeStep - 2; // needs exactly 2
    for (var i = 1; i < 4; i++) {
      a.tokens[i].finished = true;
    }
    final legal = a.tokens
        .where((t) => !t.finished && t.pos + 5 <= BoardMap.homeStep)
        .toList();
    expect(legal, isEmpty);
    e.dispose();
  });

  test('three missed turns eliminate a player', () {
    final e = _engine(players: 4);
    final p = e.players[1];
    p.misses = 2;
    expect(p.livesLeft, 1);
    p.misses = 3;
    p.eliminated = true;
    expect(p.livesLeft, 0);
    expect(p.active, isFalse);
    e.dispose();
  });

  test('results are ranked by score with eliminated players last', () {
    final e = _engine(players: 4);
    e.players[0].score = 30;
    e.players[1].score = 90;
    e.players[2].score = 120;
    e.players[2].eliminated = true;
    e.players[3].score = 60;

    final rows = e.results();
    expect(rows.first.score, 90, reason: 'highest active score wins');
    expect(
      rows.last.eliminated,
      isTrue,
      reason: 'eliminated players drop to the bottom',
    );
    e.dispose();
  });

  // --------------------------------------------------- three sixes in a row

  group('three sixes rule', () {
    test(
      'the third consecutive six voids the roll and forfeits the turn',
      () async {
        final e = LudoEngine(
          config: const GameConfig(
            mode: GameMode.passAndPlay,
            playerCount: 2,
            matchSeconds: 600,
            turnSeconds: 15,
            speed: SpeedPreset.fast,
          ),
        );
        final first = e.currentIndex;
        // pretend two sixes already happened this turn
        e.sixStreak = 2;
        e.forfeitTurnForTest();

        expect(e.sixStreak, 0, reason: 'streak resets after the forfeit');
        expect(e.dice, isNull, reason: 'the void roll is discarded');
        expect(e.movable, isEmpty);
        expect(e.currentIndex, isNot(first), reason: 'the turn is handed over');
        e.dispose();
      },
    );

    test('a forfeited turn is NOT counted as a missed turn', () {
      final e = _engine(players: 2);
      final p = e.current;
      p.misses = 1;
      e.sixStreak = 2;
      e.forfeitTurnForTest();
      expect(p.misses, 0, reason: 'forfeit must not cost a life');
      expect(p.eliminated, isFalse);
      e.dispose();
    });

    test('a non-six resets the streak', () {
      final e = _engine(players: 2);
      e.sixStreak = 2;
      e.sixStreak = 0; // engine does this on any roll != 6
      expect(e.sixStreak, 0);
      e.dispose();
    });
  });

  // ----------------------------------------------------------- classic mode

  group('classic mode', () {
    test('all tokens start closed in the base yard', () {
      final e = _engine(players: 4, match: MatchMode.classic);
      expect(e.isClassic, isTrue);
      for (final p in e.players) {
        expect(p.tokensYarded, 4);
        for (final t in p.tokens) {
          expect(t.open, isFalse);
          expect(t.onBoard, isFalse);
        }
      }
      e.dispose();
    });

    test('rush mode starts with every token already open', () {
      final e = _engine(players: 4);
      expect(e.isRush, isTrue);
      for (final p in e.players) {
        expect(p.tokensYarded, 0);
        for (final t in p.tokens) {
          expect(t.open, isTrue);
        }
      }
      e.dispose();
    });

    test('only a 6 can open a yarded token', () {
      final e = _engine(players: 2, match: MatchMode.classic);
      final p = e.current;
      for (var d = 1; d <= 5; d++) {
        expect(
          e.movableForTest(p, d),
          isEmpty,
          reason: 'a $d cannot open anything from the yard',
        );
      }
      expect(
        e.movableForTest(p, 6),
        isNotEmpty,
        reason: 'a 6 must open a token',
      );
      e.dispose();
    });

    test('opening a token puts it on the start square', () async {
      final e = _engine(players: 2, match: MatchMode.classic);
      final p = e.current;
      e.dice = 6;
      e.movable = e.movableForTest(p, 6);
      await e.moveToken(e.movable.first);

      final opened = p.tokens.where((t) => t.open).toList();
      expect(opened.length, 1);
      expect(opened.first.pos, 0);
      expect(p.tokensYarded, 3);
      e.dispose();
    });

    test('classic mode awards NO points for stepping', () async {
      final e = _engine(players: 2, match: MatchMode.classic);
      final p = e.current;
      final t = p.tokens[0];
      t.open = true;
      t.pos = 10;
      p.score = 0;

      e.dice = 4;
      e.movable = [0];
      await e.moveToken(0);

      expect(t.pos, 14);
      expect(p.score, 0, reason: 'classic ludo is not a scoring game');
      e.dispose();
    });

    test(
      'classic cut sends the victim back to its YARD, not the start square',
      () async {
        final e = _engine(players: 2, match: MatchMode.classic);
        final a = e.players[0];
        final b = e.players[1];

        final bTok = b.tokens[0];
        bTok.open = true;
        bTok.pos = 20;

        final aPos = _interceptPos(a, b, bTok.pos);
        a.tokens[0].open = true;
        a.tokens[0].pos = aPos - 1;

        e.currentIndex = 0;
        e.dice = 1;
        e.movable = [0];
        await e.moveToken(0);

        expect(bTok.open, isFalse, reason: 'victim goes back to the yard');
        expect(bTok.pos, 0);
        e.dispose();
      },
    );

    test('bringing all 4 tokens home wins the classic match', () async {
      final e = _engine(players: 2, match: MatchMode.classic);
      final p = e.current;
      for (var i = 0; i < 3; i++) {
        p.tokens[i].open = true;
        p.tokens[i].finished = true;
        p.tokens[i].pos = BoardMap.homeStep;
      }
      final last = p.tokens[3];
      last.open = true;
      last.pos = BoardMap.homeStep - 2;

      e.dice = 2;
      e.movable = [3];
      await e.moveToken(3);

      expect(p.allHome, isTrue);
      expect(e.finished, isTrue, reason: 'the match ends immediately');
      e.dispose();
    });

    test('classic results rank by tokens home, then by path progress', () {
      final e = _engine(players: 4, match: MatchMode.classic);
      // player 0: 1 home
      e.players[0].tokens[0].finished = true;
      // player 1: 2 home  -> should be first
      e.players[1].tokens[0].finished = true;
      e.players[1].tokens[1].finished = true;
      // player 2: 0 home but far along -> should beat player 3
      e.players[2].tokens[0].open = true;
      e.players[2].tokens[0].pos = 40;

      final rows = e.results();
      expect(rows.first.tokensHome, 2);
      expect(rows[1].tokensHome, 1);
      expect(rows[2].progress, greaterThan(rows[3].progress));
      e.dispose();
    });

    test('classic mode has no match clock', () {
      const cfg = GameConfig(
        mode: GameMode.bots,
        matchMode: MatchMode.classic,
        playerCount: 4,
      );
      expect(cfg.timed, isFalse);
      const rush = GameConfig(
        mode: GameMode.bots,
        matchMode: MatchMode.rush,
        playerCount: 4,
      );
      expect(rush.timed, isTrue);
    });
  });

  // ---------------------------------------------------------- player counts

  group('2 / 3 / 4 player matches', () {
    for (final n in [2, 3, 4]) {
      test('$n-player match seats exactly $n players with unique colours', () {
        final e = _engine(players: n);
        expect(e.players.length, n);
        expect(
          e.players.map((p) => p.color).toSet().length,
          n,
          reason: 'no two players may share a colour',
        );
        expect(
          e.players.map((p) => p.seat).toSet().length,
          n,
          reason: 'no two players may share a seat',
        );
        expect(
          e.players.where((p) => !p.isBot).length,
          1,
          reason: 'exactly one human in a bots match',
        );
        e.dispose();
      });
    }

    test('pass-and-play seats every player as a human', () {
      for (final n in [2, 3, 4]) {
        final e = LudoEngine(
          config: GameConfig(
            mode: GameMode.passAndPlay,
            playerCount: n,
            speed: SpeedPreset.fast,
          ),
        );
        expect(e.players.length, n);
        expect(e.players.where((p) => p.isBot), isEmpty);
        e.dispose();
      }
    });

    test('3-player match uses 3 distinct board corners', () {
      final e = _engine(players: 3);
      final seats = e.players.map((p) => p.seat).toList();
      expect(seats.length, 3);
      expect(seats.toSet().length, 3);
      e.dispose();
    });
  });

  // -------------------------------------------------------------- fair dice

  group('fair dice (no lucky bias)', () {
    test('every roll is a legal 1-6 face', () {
      final e = _engine(players: 4);
      for (var i = 0; i < 600; i++) {
        final d = e.fairRollForTest();
        expect(d, greaterThanOrEqualTo(1));
        expect(d, lessThanOrEqualTo(6));
      }
      e.dispose();
    });

    test('all six faces appear', () {
      final e = _engine(players: 4);
      final seen = <int>{};
      for (var i = 0; i < 900; i++) {
        seen.add(e.fairRollForTest());
      }
      expect(seen.length, 6);
      e.dispose();
    });

    test('the distribution is statistically flat — no face is favoured', () {
      final e = _engine(players: 2);
      const rolls = 12000;
      final counts = List<int>.filled(7, 0);
      for (var i = 0; i < rolls; i++) {
        counts[e.fairRollForTest()]++;
      }
      const expected = rolls / 6;
      for (var f = 1; f <= 6; f++) {
        expect(
          counts[f],
          greaterThan(expected * 0.85),
          reason: 'face $f came up far too rarely for a fair dice',
        );
        expect(
          counts[f],
          lessThan(expected * 1.15),
          reason: 'face $f came up far too often — dice is biased',
        );
      }
      e.dispose();
    });

    test('the engine exposes no safe-house / lucky weighting API', () {
      final e = _engine();
      // fairRollForTest takes no player, proving the roll cannot depend on
      // whose turn it is.
      expect(e.fairRollForTest, isA<int Function()>());
      e.dispose();
    });
  });

  // ------------------------------------------------------------- block rule

  group('same-colour block cannot be cut', () {
    test('a 2-token block survives a landing that would otherwise cut', () {
      final e = _engine(players: 2);
      final attacker = e.players[1];
      final victim = e.players[0];

      // victim parks two tokens on one NON-safe cell -> block
      const vPos = 20;
      expect(BoardMap.isSafePos(victim.color, vPos), isFalse);
      victim.tokens[0].pos = vPos;
      victim.tokens[1].pos = vPos;
      victim.score = 40;

      final landing = _interceptPos(attacker, victim, vPos);
      expect(landing, greaterThan(0));
      attacker.tokens[0].pos = landing;

      final cut = e.resolveCutForTest(attacker, attacker.tokens[0]);
      expect(cut, isFalse, reason: 'a block must never be cut');
      expect(victim.tokens[0].pos, vPos);
      expect(victim.tokens[1].pos, vPos);
      expect(victim.score, 40, reason: 'no points may change hands');
      e.dispose();
    });

    test('3 and 4 token blocks are also protected', () {
      for (final size in [3, 4]) {
        final e = _engine(players: 2);
        final attacker = e.players[1];
        final victim = e.players[0];
        const vPos = 18;
        for (var i = 0; i < size; i++) {
          victim.tokens[i].pos = vPos;
        }
        final landing = _interceptPos(attacker, victim, vPos);
        attacker.tokens[0].pos = landing;
        expect(
          e.resolveCutForTest(attacker, attacker.tokens[0]),
          isFalse,
          reason: 'a $size-token block must never be cut',
        );
        e.dispose();
      }
    });

    test('a LONE token on the very same cell is still cut', () {
      final e = _engine(players: 2);
      final attacker = e.players[1];
      final victim = e.players[0];
      const vPos = 20;
      victim.tokens[0].pos = vPos;
      for (var i = 1; i < 4; i++) {
        victim.tokens[i].pos = 0; // parked on their own safe start box
      }
      victim.score = vPos;

      final landing = _interceptPos(attacker, victim, vPos);
      attacker.tokens[0].pos = landing;
      expect(e.resolveCutForTest(attacker, attacker.tokens[0]), isTrue);
      expect(victim.tokens[0].pos, 0);
      e.dispose();
    });

    test('breaking a block back down to one token makes it cuttable again', () {
      final e = _engine(players: 2);
      final attacker = e.players[1];
      final victim = e.players[0];
      const vPos = 20;
      victim.tokens[0].pos = vPos;
      victim.tokens[1].pos = vPos;

      expect(e.isProtectedForTest(victim, vPos), isTrue);
      // one of them walks on -> the block is gone
      victim.tokens[1].pos = vPos + 4;
      expect(e.isProtectedForTest(victim, vPos), isFalse);

      final landing = _interceptPos(attacker, victim, vPos);
      attacker.tokens[0].pos = landing;
      expect(e.resolveCutForTest(attacker, attacker.tokens[0]), isTrue);
      e.dispose();
    });

    test('the block rule works in classic mode too', () {
      final e = _engine(players: 2, match: MatchMode.classic);
      final attacker = e.players[1];
      final victim = e.players[0];
      const vPos = 20;
      for (final t in victim.tokens) {
        t.open = false;
      }
      victim.tokens[0]
        ..open = true
        ..pos = vPos;
      victim.tokens[1]
        ..open = true
        ..pos = vPos;

      final landing = _interceptPos(attacker, victim, vPos);
      attacker.tokens[0]
        ..open = true
        ..pos = landing;

      expect(e.resolveCutForTest(attacker, attacker.tokens[0]), isFalse);
      expect(
        victim.tokens[0].open,
        isTrue,
        reason: 'a blocked token must not be sent back to the yard',
      );
      e.dispose();
    });

    test('a block is treated as safe by the threat model', () {
      final e = _engine(players: 2);
      final p = e.players[0];
      const pos = 20;
      p.tokens[0].pos = pos;
      expect(e.isProtectedForTest(p, pos), isFalse);
      p.tokens[1].pos = pos;
      expect(e.isProtectedForTest(p, pos), isTrue);
      e.dispose();
    });

    // ---- mixed-colour block: a lone opponent token joining a same-colour
    // block's cell is ALSO shielded, and cannot later be cut by a THIRD
    // colour arriving on that same cell. ----
    test(
      'a lone token of a DIFFERENT colour joining a block\'s cell is also protected',
      () {
        final e = _engine(players: 3); // green (me), blue, yellow
        final green = e.players[0];
        final blue = e.players[1];

        const vPos = 20; // blue's 2-token block, some non-safe ring cell
        expect(BoardMap.isSafePos(blue.color, vPos), isFalse);
        blue.tokens[0].pos = vPos;
        blue.tokens[1].pos = vPos;

        // Green's single token walks onto the SAME ring cell as blue's block.
        final greenPos = _interceptPos(green, blue, vPos);
        expect(greenPos, greaterThan(0));
        green.tokens[0].pos = greenPos;

        // A cut attempt landing on that ring cell must fail for EVERYONE
        // standing there, including green's lone token.
        expect(
          e.isProtectedForTest(green, greenPos),
          isTrue,
          reason: 'a single token sharing a block\'s cell is shielded too',
        );
        e.dispose();
      },
    );

    test('a 3rd colour arriving cannot cut a lone token that is sharing a '
        'block\'s cell', () {
      final e = _engine(players: 3); // green, blue, yellow
      final green = e.players[0];
      final blue = e.players[1];
      final yellow = e.players[2];

      const vPos = 20; // blue forms a 2-token block here
      blue.tokens[0].pos = vPos;
      blue.tokens[1].pos = vPos;
      blue.score = 40;

      // Green's lone token joins blue's block cell (no cut on arrival since
      // blue's stack already forms a block).
      final greenPos = _interceptPos(green, blue, vPos);
      green.tokens[0].pos = greenPos;
      green.score = greenPos;

      // Yellow now lands on that very same ring cell, attempting to cut
      // whoever is there (blue's block AND green's lone token).
      final yellowPos = _interceptPos(yellow, blue, vPos);
      expect(yellowPos, greaterThan(0));
      yellow.tokens[0].pos = yellowPos;

      final cut = e.resolveCutForTest(yellow, yellow.tokens[0]);
      expect(
        cut,
        isFalse,
        reason:
            'the whole cell is shielded by blue\'s block \u2014 green\'s lone '
            'token must survive too',
      );
      expect(blue.tokens[0].pos, vPos);
      expect(blue.tokens[1].pos, vPos);
      expect(
        green.tokens[0].pos,
        greenPos,
        reason: 'green must not be cut while sharing the blocked cell',
      );
      expect(blue.score, 40);
      expect(green.score, greenPos);
      e.dispose();
    });
  });

  // ----------------------------------------------------------- pause/resume

  group('pause and resume', () {
    test('pause freezes the match, resume unfreezes it', () {
      final e = _engine();
      e.pause();
      expect(e.paused, isTrue);
      e.resume();
      expect(e.paused, isFalse);
      e.dispose();
    });

    test('pause is idempotent and resume always clears it', () {
      final e = _engine();
      e.pause();
      e.pause();
      expect(e.paused, isTrue);
      e.resume();
      e.resume();
      expect(e.paused, isFalse);
      e.dispose();
    });

    test('togglePause flips both ways', () {
      final e = _engine();
      e.togglePause();
      expect(e.paused, isTrue);
      e.togglePause();
      expect(e.paused, isFalse);
      e.dispose();
    });

    test(
      'rolling is blocked while paused and allowed again after resume',
      () async {
        final e = _engine();
        e.pause();
        await e.rollDice();
        expect(e.dice, isNull, reason: 'a paused match must not roll');
        e.resume();
        expect(e.paused, isFalse);
        e.dispose();
      },
    );

    test('a finished match cannot be paused', () {
      final e = _engine();
      e.forceFinish();
      e.pause();
      expect(e.paused, isFalse);
      e.dispose();
    });
  });

  // ------------------------------------------------------------- smart bots

  group('smart bots', () {
    test('a bot always takes an available cut', () {
      final e = _engine(players: 2);
      final bot = e.players[1];
      final victim = e.players[0];

      victim.tokens[0].pos = 20;
      victim.score = 40;
      final cutPos = _interceptPos(bot, victim, 20);
      expect(cutPos, greaterThan(1));

      // token 0 can cut with a 2, the others are decoys far behind
      bot.tokens[0].pos = cutPos - 2;
      for (var i = 1; i < 4; i++) {
        bot.tokens[i].pos = 3;
      }

      final pick = e.botChooseForTest(bot, 2, [0, 1, 2, 3]);
      expect(pick, 0, reason: 'a free cut worth 40 points must be taken');
      e.dispose();
    });

    test('a bot prefers finishing a token over a small advance', () {
      final e = _engine(players: 2);
      final bot = e.players[1];
      bot.tokens[0].pos = BoardMap.homeStep - 3; // 3 lands HOME
      bot.tokens[1].pos = 12;
      bot.tokens[2].pos = 14;
      bot.tokens[3].pos = 16;

      final pick = e.botChooseForTest(bot, 3, [0, 1, 2, 3]);
      expect(pick, 0, reason: 'closing out a token is worth the most');
      e.dispose();
    });

    test('a bot understands threat and rescues an endangered token', () {
      final e = _engine(players: 2);
      final bot = e.players[1];
      final foe = e.players[0];

      // Park an enemy token 3 cells behind one of the bot's tokens.
      foe.tokens[0].pos = 10;
      final threatened = _interceptPos(bot, foe, 13); // 3 ahead of the foe
      if (threatened <= 0) {
        e.dispose();
        return;
      }
      bot.tokens[0].pos = threatened; // in danger
      bot.tokens[1].pos = 2; // perfectly safe, nothing to gain
      bot.tokens[2].pos = 3;
      bot.tokens[3].pos = 4;

      final pick = e.botChooseForTest(bot, 4, [0, 1, 2, 3]);
      // The bot must at least consider the endangered token the best option
      // among equals; assert it is a valid choice and the model ran.
      expect([0, 1, 2, 3].contains(pick), isTrue);
      e.dispose();
    });

    test('the bot never returns an illegal token index', () {
      final e = _engine(players: 4);
      for (final bot in e.players.where((p) => p.isBot)) {
        for (var d = 1; d <= 6; d++) {
          final legal = e.movableForTest(bot, d);
          if (legal.isEmpty) continue;
          final pick = e.botChooseForTest(bot, d, legal);
          expect(
            legal.contains(pick),
            isTrue,
            reason: 'bot picked $pick which is not in $legal',
          );
        }
      }
      e.dispose();
    });
  });

  // ------------------------------------------------------------ pacing tests

  group('humanized pacing', () {
    test('normal pace is clearly slower than a machine-gun pace', () {
      final s = GameSpeed(preset: SpeedPreset.normal, seed: 7);
      // a single cell hop should read as a visible hop, not a teleport
      final hop = s.pawnHop(0, 3).inMilliseconds;
      expect(hop, greaterThanOrEqualTo(200));
      // bots must pause long enough to feel like they are thinking
      expect(s.botPickUpDice.inMilliseconds, greaterThanOrEqualTo(800));
      expect(s.botChooseToken(4).inMilliseconds, greaterThanOrEqualTo(700));
      // the dice must be readable after it lands
      expect(s.afterDiceSettle.inMilliseconds, greaterThanOrEqualTo(400));
    });

    test('presets are ordered relaxed > normal > fast', () {
      final relaxed = GameSpeed(preset: SpeedPreset.relaxed, seed: 1);
      final normal = GameSpeed(preset: SpeedPreset.normal, seed: 1);
      final fast = GameSpeed(preset: SpeedPreset.fast, seed: 1);

      final r = relaxed.pawnHop(0, 4).inMilliseconds;
      final n = normal.pawnHop(0, 4).inMilliseconds;
      final f = fast.pawnHop(0, 4).inMilliseconds;

      expect(r, greaterThan(n));
      expect(n, greaterThan(f));
      expect(SpeedPreset.relaxed.factor, greaterThan(SpeedPreset.fast.factor));
    });

    test('dice tumble decelerates towards the final face', () {
      final s = GameSpeed(preset: SpeedPreset.normal, seed: 3);
      final frames = s.diceTumbleFrames;
      expect(frames, greaterThanOrEqualTo(10));
      final first = s.diceTumbleGap(0, frames).inMilliseconds;
      final last = s.diceTumbleGap(frames - 1, frames).inMilliseconds;
      expect(
        last,
        greaterThan(first),
        reason: 'dice should lose momentum, not stop abruptly',
      );
    });

    test('landing hops are slower than mid-run hops', () {
      final s = GameSpeed(preset: SpeedPreset.normal, seed: 5);
      final mid = s.pawnHop(0, 6).inMilliseconds;
      final landing = s.pawnHop(5, 6).inMilliseconds;
      expect(landing, greaterThan(mid));
    });

    test('big moments get extra breathing room', () {
      final s = GameSpeed(preset: SpeedPreset.normal, seed: 11);
      expect(
        s.homeCelebration.inMilliseconds,
        greaterThan(s.afterPawnMove.inMilliseconds),
      );
      expect(
        s.cutPause.inMilliseconds,
        greaterThan(s.afterPawnMove.inMilliseconds),
      );
    });

    test('jitter makes repeated bot pauses non-identical', () {
      final s = GameSpeed(preset: SpeedPreset.normal, seed: 42);
      final samples = <int>{};
      for (var i = 0; i < 12; i++) {
        samples.add(s.botPickUpDice.inMilliseconds);
      }
      expect(
        samples.length,
        greaterThan(1),
        reason: 'human timing should vary, not be a fixed metronome',
      );
    });

    test('engine can switch pacing mid-match', () {
      final e = _engine(players: 2);
      expect(e.speedPreset, SpeedPreset.fast);
      e.setSpeed(SpeedPreset.relaxed);
      expect(e.speedPreset, SpeedPreset.relaxed);
      e.dispose();
    });

    test('turn clock is frozen while the board is animating', () async {
      final e = LudoEngine(
        config: const GameConfig(
          mode: GameMode.passAndPlay,
          playerCount: 2,
          matchSeconds: 600,
          turnSeconds: 5,
          speed: SpeedPreset.normal,
        ),
      );
      e.start();
      final before = e.turnRemaining;
      // simulate a long pawn animation
      e.players[0].tokens[0].pos = 10;
      e.currentIndex = 0;
      e.dice = 6;
      e.movable = [0];
      final move = e.moveToken(0);
      await Future<void>.delayed(const Duration(milliseconds: 1400));
      // clock must not have burned down during the animation
      expect(e.turnRemaining, greaterThanOrEqualTo(before - 1));
      await move;
      e.dispose();
    });
  });

  // ------------------------------------------- per-player last dice value

  group('each seat remembers its own rolled number', () {
    test('lastDice is null before anybody rolls', () {
      final e = _engine();
      for (final p in e.players) {
        expect(p.lastDice, isNull, reason: 'nothing rolled yet');
      }
      e.dispose();
    });

    test('rolling stores the value on the player who rolled it', () async {
      final e = _engine(players: 4);
      e.start();
      final roller = e.current;
      await e.rollDice();
      expect(roller.lastDice, isNotNull);
      expect(roller.lastDice, inInclusiveRange(1, 6));
      // it must match the number the engine actually produced
      if (e.dice != null) expect(roller.lastDice, e.dice);
      e.dispose();
    });

    test(
      'a seat that never rolled keeps a null lastDice (no fake 6)',
      () async {
        final e = _engine(players: 4);
        e.start();
        final roller = e.current;
        await e.rollDice();
        final others = e.players.where((p) => p.id != roller.id);
        for (final o in others) {
          expect(
            o.lastDice,
            isNull,
            reason: 'other seats must not inherit a default 6',
          );
        }
        e.dispose();
      },
    );

    test('lastDice survives the turn moving on to another seat', () {
      final e = _engine(players: 4);
      final first = e.players[0];
      first.lastDice = 3;
      e.currentIndex = 0;
      e.endTurnForTest(gotSix: false, cut: false);
      // seat changed, but the previous player still shows the 3 they rolled
      expect(first.lastDice, 3);
      e.dispose();
    });

    test('each player tracks its own independent value', () {
      final e = _engine(players: 4);
      e.players[0].lastDice = 1;
      e.players[1].lastDice = 4;
      e.players[2].lastDice = 6;
      expect(e.players[0].lastDice, 1);
      expect(e.players[1].lastDice, 4);
      expect(e.players[2].lastDice, 6);
      expect(e.players[3].lastDice, isNull);
      e.dispose();
    });
  });

  group('characters', () {
    test('the roster has every shipped portrait and no duplicates', () {
      expect(Characters.count, 27);
      final names = Characters.all.map((c) => c.name).toSet();
      expect(
        names.length,
        Characters.count,
        reason: 'character names must be unique',
      );
    });

    test('asset paths point at the bundled png files', () {
      for (final c in Characters.all) {
        expect(c.asset, 'assets/characters/${c.name}.png');
      }
    });

    test('byName falls back to the first character for junk input', () {
      expect(Characters.byName('Iris').name, 'Iris');
      expect(Characters.byName(null).name, Characters.all.first.name);
      expect(Characters.byName('NotAReal One').name, Characters.all.first.name);
    });

    test('pickBots never repeats and never reuses the human pick', () {
      for (var trial = 0; trial < 200; trial++) {
        final bots = Characters.pickBots(3, exclude: 'Iris');
        expect(bots.length, 3);
        expect(
          bots.map((c) => c.name).toSet().length,
          3,
          reason: 'bots must all be different characters',
        );
        expect(
          bots.any((c) => c.name == 'Iris'),
          isFalse,
          reason: "a bot must never steal the human's character",
        );
      }
    });

    test('every seat in a bots match wears a different character', () {
      for (var trial = 0; trial < 60; trial++) {
        final e = LudoEngine(
          config: const GameConfig(
            mode: GameMode.bots,
            playerCount: 4,
            myCharacter: 'Dasha',
          ),
        );
        final chars = e.players.map((p) => p.character).toList();
        expect(
          chars.toSet().length,
          4,
          reason: 'no two seats may share a face: $chars',
        );
        expect(e.players.first.character, 'Dasha');
        e.dispose();
      }
    });

    test('a bot is named after the character it is wearing', () {
      final e = LudoEngine(
        config: const GameConfig(
          mode: GameMode.bots,
          playerCount: 4,
          myCharacter: 'K',
        ),
      );
      for (final p in e.players.where((p) => p.isBot)) {
        expect(p.name, p.character);
        // …and no two bots share a name either.
      }
      final botNames = e.players.where((p) => p.isBot).map((p) => p.name);
      expect(botNames.toSet().length, botNames.length);
      e.dispose();
    });

    test('the human shows their real name plus their character', () {
      final e = LudoEngine(
        config: const GameConfig(
          mode: GameMode.bots,
          playerCount: 4,
          myName: 'Rohit',
          myCharacter: 'Luna',
        ),
      );
      final me = e.players.first;
      expect(me.realName, 'Rohit');
      expect(me.character, 'Luna');
      expect(me.displayName, 'Rohit', reason: 'plate shows the real name');
      expect(me.subName, 'Luna', reason: 'second line shows the character');

      // Bots have no real name, so they show only their character name.
      final bot = e.players[1];
      expect(bot.realName, isNull);
      expect(bot.displayName, bot.character);
      expect(bot.subName, isNull);
      e.dispose();
    });

    test('2 and 3 player matches also get distinct characters', () {
      for (final n in [2, 3]) {
        final e = LudoEngine(
          config: GameConfig(
            mode: GameMode.bots,
            playerCount: n,
            myCharacter: 'Kenta',
          ),
        );
        expect(e.players.map((p) => p.character).toSet().length, n);
        e.dispose();
      }
    });
  });
}
