import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ludo_rush/screens/login_screen.dart';
import 'package:ludo_rush/screens/splash_screen.dart';

import 'package:ludo_rush/core/theme.dart';
import 'package:ludo_rush/game/board_map.dart';
import 'package:ludo_rush/game/engine.dart';
import 'package:ludo_rush/game/models.dart';

void main() {
  test('board ring has 52 cells and unique positions', () {
    expect(BoardMap.ring.length, 52);
    final keys = BoardMap.ring.map((c) => '${c.r}_${c.c}').toSet();
    expect(keys.length, 52);
  });

  test('every color travels 57 positions and lands on its home', () {
    for (final c in PColor.values) {
      final cell = BoardMap.cellFor(c, BoardMap.homeStep);
      expect(cell, BoardMap.homeCenter[c]);
      expect(BoardMap.isSafePos(c, 0), isTrue); // start square is safe
      expect(BoardMap.isSafePos(c, 55), isTrue); // home column is safe
    }
  });

  test('start squares map to correct ring index', () {
    expect(BoardMap.ringIndexFor(PColor.yellow, 0), 0);
    expect(BoardMap.ringIndexFor(PColor.blue, 0), 13);
    expect(BoardMap.ringIndexFor(PColor.red, 0), 26);
    expect(BoardMap.ringIndexFor(PColor.green, 0), 39);
  });

  test('engine sets up players offline with tokens already open', () {
    final e = LudoEngine(
      config: const GameConfig(mode: GameMode.bots, playerCount: 4),
    );
    expect(e.players.length, 4);
    expect(e.players.first.isBot, isFalse);
    for (final p in e.players) {
      expect(p.tokens.length, 4);
      for (final t in p.tokens) {
        expect(t.pos, 0); // open at start square, no 6 needed
        expect(t.finished, isFalse);
      }
      expect(p.score, 0);
      expect(p.livesLeft, 3);
    }
    e.dispose();
  });

  test('home bonus is 56 and step scoring is 1 per cell', () {
    final e = LudoEngine(
      config: const GameConfig(mode: GameMode.bots, playerCount: 2),
    );
    final p = e.players.first;
    final t = p.tokens.first;
    t.pos = BoardMap.homeStep - 1;
    expect(t.carried, BoardMap.homeStep - 1);
    t.finished = true;
    expect(t.carried, 0); // finished tokens can't be cut
    e.dispose();
  });

  test('yard slots stay inside their own base panel and never overlap', () {
    for (final c in PColor.values) {
      final o = BoardMap.baseOrigin[c]!;
      final seen = <String>{};
      for (var i = 0; i < 4; i++) {
        final s = BoardMap.yardSlot(c, i);
        expect(s.r, greaterThanOrEqualTo(o.r));
        expect(s.r, lessThan(o.r + 6));
        expect(s.c, greaterThanOrEqualTo(o.c));
        expect(s.c, lessThan(o.c + 6));
        expect(
          seen.add('${s.r}_${s.c}'),
          isTrue,
          reason: 'yard slots must not collide',
        );
      }
    }
  });

  test('GameConfig no longer exposes any currency and defaults to rush', () {
    const cfg = GameConfig(mode: GameMode.bots, playerCount: 4);
    expect(cfg.matchMode, MatchMode.rush);
    expect(cfg.timed, isTrue);
    expect(cfg.matchSeconds, 360); // 6 minutes
    expect(cfg.botLevel, 3);
  });

  test('match mode labels and taglines are English and distinct', () {
    expect(MatchMode.classic.label, 'Classic Ludo');
    expect(MatchMode.rush.label, 'Rush Ludo');
    expect(MatchMode.classic.tagline, isNot(MatchMode.rush.tagline));
    for (final m in MatchMode.values) {
      // no Devanagari characters may leak into the user-facing strings
      expect(RegExp(r'[\u0900-\u097F]').hasMatch(m.label), isFalse);
      expect(RegExp(r'[\u0900-\u097F]').hasMatch(m.tagline), isFalse);
    }
  });

  test('every sound cue has a bundled asset file mapped', () {
    // GameSfx is the contract between the engine and the audio service —
    // a missing mapping would silently swallow an effect.
    expect(GameSfx.values.length, 14);
    for (final s in GameSfx.values) {
      expect(s.name.isNotEmpty, isTrue);
    }
  });

  group('boot flow: splash -> login -> lobby', () {
    testWidgets('login screen offers Facebook, Guest and More', (t) async {
      await t.pumpWidget(const MaterialApp(home: LoginScreen()));
      await t.pump();

      expect(find.text('Sign in with Facebook'), findsOneWidget);
      expect(find.text('or'), findsOneWidget);
      expect(find.text('Guest'), findsOneWidget);
      expect(find.text('More'), findsOneWidget);
    });

    testWidgets('tapping Guest leaves the login screen', (t) async {
      await t.pumpWidget(const MaterialApp(home: LoginScreen()));
      await t.pump();

      await t.tap(find.text('Guest'));
      await t.pump();
      await t.pump(const Duration(milliseconds: 600));

      // We navigated away — the sign-in bar is gone.
      expect(find.text('Sign in with Facebook'), findsNothing);
    });

    testWidgets('Facebook and More do nothing at all', (t) async {
      await t.pumpWidget(const MaterialApp(home: LoginScreen()));
      await t.pump();

      await t.tap(find.text('Sign in with Facebook'));
      await t.pump(const Duration(milliseconds: 600));
      expect(
        find.text('Sign in with Facebook'),
        findsOneWidget,
        reason: 'Facebook must not navigate anywhere',
      );

      await t.tap(find.text('More'));
      await t.pump(const Duration(milliseconds: 600));
      expect(
        find.text('More'),
        findsOneWidget,
        reason: 'More must not navigate anywhere',
      );
    });

    testWidgets('splash shows the RESOURCE LOADING caption', (t) async {
      await t.pumpWidget(const MaterialApp(home: SplashScreen()));
      await t.pump();

      expect(find.text('RESOURCE LOADING, PLEASE WAIT'), findsOneWidget);

      // Let the fake loader run for a while and confirm the bar is actually
      // filling rather than sitting frozen at zero.
      for (var i = 0; i < 40; i++) {
        await t.pump(const Duration(milliseconds: 100));
      }
      expect(
        find.text('0%'),
        findsNothing,
        reason: 'the progress bar should have advanced past zero',
      );

      // The loader now runs for the full ~10 seconds (see splash_screen.dart)
      // so drain the rest of it before tearing the screen down — otherwise a
      // pending Future.delayed timer trips the test framework's ticker/timer
      // leak check.
      for (var i = 0; i < 65; i++) {
        await t.pump(const Duration(milliseconds: 100));
      }

      // Tear the screen down so its repeating controllers are disposed and the
      // ticker-leak check passes. (The real navigation to the login screen is
      // driven by platform-channel calls that do not resolve under test.)
      await t.pumpWidget(const SizedBox.shrink());
      await t.pump();
    });
  });
}
